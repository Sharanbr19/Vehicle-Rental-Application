// import React, { useState, useEffect } from "react";
// import {
//   BrowserRouter as Router,
//   Routes,
//   Route,
//   Navigate,
// } from "react-router-dom";
// import { useCookies } from "react-cookie";
// import { ToastContainer } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";
// import Registration from "./pages/Registration";
// import Login from "./pages/Login";
// import AdminDashboard from "./pages/AdminDashboard";
// import CustomerDashboard from "./pages/CustomerDashboard";
// import Home from "./pages/Home";
// import Header from "./components/common/Header";
// import PageNotFound from "./pages/PageNotFound";
// import AboutUs from "./pages/AboutUs";
// import ContactUs from "./pages/ContactUs";
// import Policies from "./pages/Policies";
// import BookVehicle from "./pages/BookVehicle"; // Import the BookVehicle component
// import ConfirmBooking from "./pages/ConfirmBooking";
// import Footer from "./components/common/Footer";

// function App() {
//   const [cookies] = useCookies(["user", "role"]);
//   const [isAuthenticated, setIsAuthenticated] = useState(!!cookies.user);
//   const [userRole, setUserRole] = useState(cookies.role || null);

//   useEffect(() => {
//     setIsAuthenticated(!!cookies.user);
//     setUserRole(cookies.role || null);
//   }, [cookies]);

//   return (
//     <Router>
//       <Header
//         isAuthenticated={isAuthenticated}
//         setIsAuthenticated={setIsAuthenticated}
//         userRole={userRole}
//         setUserRole={setUserRole}
//       />
//       <ToastContainer
//         position="top-right"
//         autoClose={5000}
//         hideProgressBar={false}
//         newestOnTop={false}
//         closeOnClick
//         rtl={false}
//         pauseOnFocusLoss
//         draggable
//         pauseOnHover
//       />
//       <Routes>
//         <Route path="/" element={<Home />} />
//         <Route path="/about" element={<AboutUs />} />
//         <Route path="/contact" element={<ContactUs />} />
//         <Route path="/registration" element={<Registration />} />
//         <Route path="/policies" element={<Policies />} />
//         <Route
//           path="/login"
//           element={
//             isAuthenticated ? (
//               <Navigate to={userRole === "ADMIN" ? "/admin" : "/customer"} />
//             ) : (
//               <Login />
//             )
//           }
//         />
//         <Route
//           path="/admin"
//           element={
//             isAuthenticated && userRole === "ADMIN" ? (
//               <AdminDashboard />
//             ) : (
//               <Navigate to="/login" />
//             )
//           }
//         />
//         <Route
//           path="/customer"
//           element={
//             isAuthenticated && userRole === "CUSTOMER" ? (
//               <CustomerDashboard />
//             ) : (
//               <Navigate to="/login" />
//             )
//           }
//         />
//         <Route path="/book/:vehicleId" element={<BookVehicle />} />
//         <Route path="/confirm-booking" element={<ConfirmBooking />} />
//         <Route path="*" element={<PageNotFound />} />
//       </Routes>
//     <Footer/>
//     </Router>
//   );
// }

// export default App;
import React, { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import { useCookies } from "react-cookie";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Registration from "./pages/Registration";
import Login from "./pages/Login";
import AdminDashboard from "./pages/AdminDashboard";
import CustomerDashboard from "./pages/CustomerDashboard";
import Home from "./pages/Home";
import Header from "./components/common/Header";
import PageNotFound from "./pages/PageNotFound";
import AboutUs from "./pages/AboutUs";
import ContactUs from "./pages/ContactUs";
import Policies from "./pages/Policies";
import BookVehicle from "./pages/BookVehicle";
import ConfirmBooking from "./pages/ConfirmBooking";
import Footer from "./components/common/Footer";
import CryptoJS from "crypto-js"; 
import FeaturedVehicles from "./components/home/FeaturedVehicles";
const SECRET_KEY = "DbrTCGPmwy6YM/wK9zeZuJn289w/5PqtYF4arUAE2dUuP5vlFIpFEl31ks6o7WEf+fOqecX8cJHf2Yt/TWzUocD+ivaEh1bFC+J3YHP7sJHUmIjiuqKUujlgKlpD8XxKzVU0+vihkMQgLO0FbsxFYHLSR3X4oWu6RDHpFzRE+zfVYQlksLiBQJkn55NkbcPQKxzBpT6EeHbT3E7VLvUFpjQCWpEQ/oYFCUFx4WzXxZZt00Y0LT+0GJ5ajnJcAesoSNrZOcZx+Yb5gFq1YDB9l80gKQahTwIUfWa0rsPwk28=";

function App() {
  const [cookies] = useCookies(["user", "role"]);
  const [isAuthenticated, setIsAuthenticated] = useState(!!cookies.user);
  const [userRole, setUserRole] = useState(cookies.role || null);

  const decryptData = (encryptedData) => {
    const bytes = CryptoJS.AES.decrypt(encryptedData, SECRET_KEY);
    return bytes.toString(CryptoJS.enc.Utf8);
  };

  useEffect(() => {
    setIsAuthenticated(!!cookies.user);
    if (cookies.role) {
      const decryptedRole = decryptData(cookies.role);
      setUserRole(decryptedRole);
    }
  }, [cookies]);

  return (
    <Router>
      <Header
        isAuthenticated={isAuthenticated}
        setIsAuthenticated={setIsAuthenticated}
        userRole={userRole}
        setUserRole={setUserRole}
      />
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/contact" element={<ContactUs />} />
        <Route path="/registration" element={<Registration />} />
        <Route path="/policies" element={<Policies />} />
        <Route path="/featured-vehicles" element={<FeaturedVehicles />} />
        <Route
          path="/login"
          element={
            isAuthenticated ? (
              <Navigate to={userRole === "ADMIN" ? "/admin" : "/customer"} />
            ) : (
              <Login />
            )
          }
        />
        <Route
          path="/admin"
          element={
            isAuthenticated && userRole === "ADMIN" ? (
              <AdminDashboard />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/customer"
          element={
            isAuthenticated && userRole === "CUSTOMER" ? (
              <CustomerDashboard />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route path="/book/:vehicleId" element={<BookVehicle />} />
        <Route path="/confirm-booking" element={<ConfirmBooking />} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;
