import React, { useEffect, useState } from "react";
import {
  getBookingByCustomerId,
  getUserByEmail,
  getVehicleById,
  createReview,
  getReviewsByCustomerId,
  getDriverById,
} from "../../api/auth";
import { useNavigate } from "react-router-dom";
import Modal from "../../components/Modal";
import Cookies from "js-cookie";
import { toast } from "react-toastify";
import { FaUser, FaCar } from "react-icons/fa";

const BookingHistory = () => {
  const [bookings, setBookings] = useState([]);
  const [filteredBookings, setFilteredBookings] = useState([]);
  const [selectedTab, setSelectedTab] = useState("ALL");
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [selectedDriver, setSelectedDriver] = useState(null);
  const [isVehicleModalOpen, setIsVehicleModalOpen] = useState(false);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [selectedVehicleId, setSelectedVehicleId] = useState(null);
  const [customerId, setCustomerId] = useState("");
  const [reviewedVehicleIds, setReviewedVehicleIds] = useState([]);
  const [isDriverModalOpen, setIsDriverModalOpen] = useState(false);
  const navigate = useNavigate(); 
  const email = Cookies.get("email");
  const token = Cookies.get("user");
  const currentDate = new Date();

  useEffect(() => {
    if (email && token) {
      fetchUserByEmail();
    }
  }, [email, token]);

  const fetchUserByEmail = async () => {
    try {
      const response = await getUserByEmail(email, token);
      setCustomerId(response?.userId);
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };

  useEffect(() => {
    if (customerId && token) {
      fetchBookingsByCustomerId();
      fetchCustomerReviews(); 
    }
  }, [customerId, token]);

  const fetchBookingsByCustomerId = async () => {
    try {
      const response = await getBookingByCustomerId(customerId, token);
      const sortedBookings = response.sort((a, b) => b.bookingId - a.bookingId);
      setBookings(sortedBookings);
      setFilteredBookings(sortedBookings);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      setBookings([]);
      setFilteredBookings([]);
    }
  };

  const fetchCustomerReviews = async () => {
    try {
      const reviews = await getReviewsByCustomerId(customerId, token);
      const reviewedIds = reviews.map((review) => review.vehicleId);
      setReviewedVehicleIds(reviewedIds);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      setReviewedVehicleIds([]);
    }
  };

  const handleVehicleClick = async (vehicleId) => {
    try {
      const response = await getVehicleById(vehicleId, token);
      setSelectedVehicle(response);
      setIsVehicleModalOpen(true);
    } catch (error) {
      console.error("Error fetching vehicle details:", error);
    }
  };

  const handleDriverClick = async (driverId) => {
    if (!driverId) {
      setSelectedDriver(null);
      setIsDriverModalOpen(true);
      return;
    }
    try {
      const response = await getDriverById(driverId, token);
      setSelectedDriver(response);
      setIsDriverModalOpen(true);
    } catch (error) {
      console.error("Error fetching driver details:", error);
    }
  };

  const filterBookings = (tab) => {
    setSelectedTab(tab);
    let filtered = [];
    switch (tab) {
      case "UPCOMING":
        filtered = bookings.filter(
          (b) => new Date(b.fromDate) >= currentDate && b.status === "CONFIRMED"
        );
        break;
      case "COMPLETED":
        filtered = bookings.filter(
          (b) => new Date(b.toDate) < currentDate && b.status === "CONFIRMED"
        );
        break;
      case "PENDING":
        filtered = bookings.filter((b) => b.status === "PENDING");
        break;
      case "CANCELLED":
        filtered = bookings.filter((b) => b.status === "CANCELLED");
        break;
      default:
        filtered = bookings;
    }
    setFilteredBookings(filtered.sort((a, b) => b.bookingId - a.bookingId));
  };

  const handleAddReviewClick = (vehicleId) => {
    setSelectedVehicleId(vehicleId);
    setIsReviewModalOpen(true);
  };

  const handleReviewSubmit = async () => {
    if (rating && comment && selectedVehicleId) {
      const reviewData = {
        rating: rating.toString(),
        comment: comment,
        customerId: customerId,
        vehicleId: selectedVehicleId,
      };

      try {
        await createReview(reviewData, token);
        setIsReviewModalOpen(false);
        setRating(0);
        setComment("");
        toast.success("Review added successfully!");
        setReviewedVehicleIds((prev) => [...prev, selectedVehicleId]);
      } catch (error) {
        console.error("Review already added for the vehicle:", error);
        toast.error(
          "Review already added for the vehicle! You can edit your review in the reviews section."
        );
      }
    } else {
      toast.error("Please provide both rating and comment!");
    }
  };

  const handleMakePayment = (bookingData) => {
    navigate("/confirm-booking", { state: { bookingData } });
  };

  return (
    <div>
      <div className="bg-gray-200 p-2 flex flex-wrap justify-center gap-10 mb-6">
        {["ALL BOOKINGS", "PENDING", "UPCOMING", "COMPLETED", "CANCELLED"].map(
          (tab) => (
            <button
              key={tab}
              className={`p-2 w-full sm:w-40 rounded-md text-center ${
                selectedTab === tab
                  ? "bg-gray-200 text-orange-500 font-semibold"
                  : "bg-gray-200 text-black"
              }`}
              onClick={() => filterBookings(tab)}
            >
              {tab.replace("_", " ")}
            </button>
          )
        )}
      </div>

      <div className="sm:p-6 pt-4">
        <table className="min-w-full border-collapse border border-gray-300">
          <thead>
            <tr className="bg-gray-200">
              <th className="border p-2">Location</th>
              <th className="border p-2">From Date</th>
              <th className="border p-2">To Date</th>
              <th className="border p-2">Total Cost</th>
              <th className="border p-2">Vehicle</th>
              <th className="border p-2">Driver</th>
              <th className="border p-2">Status</th>
              <th className="border p-2"></th>
            </tr>
          </thead>
          <tbody>
            {filteredBookings.length > 0 ? (
              filteredBookings.map((booking) => (
                <tr key={booking.bookingId} className="text-center border">
                  <td className="border p-2">{booking.location}</td>
                  <td className="border p-2">{booking.fromDate}</td>
                  <td className="border p-2">{booking.toDate}</td>
                  <td className="border p-2">₹{booking.totalCost}</td>
                  <td className="border p-2 pl-10">
                    <FaCar
                      className="text-orange-500 cursor-pointer"
                      onClick={() => handleVehicleClick(booking.vehicleId)}
                    />
                  </td>
                  <td className="border p-2 pl-8">
                    <FaUser
                      className="text-blue-500 cursor-pointer"
                      onClick={() => handleDriverClick(booking.driverId)}
                    />
                  </td>
                  <td
                    className={`border p-2 font-bold ${
                      booking.status === "CONFIRMED"
                        ? "text-green-500"
                        : booking.status === "PENDING"
                        ? "text-yellow-500"
                        : "text-red-500"
                    }`}
                  >
                    {booking.status}
                  </td>
                  <td className="border p-2">
                    {booking.status === "PENDING" && (
                      <button
                        className="w-full bg-green-500 text-white px-4 py-1 rounded"
                        onClick={() => handleMakePayment(booking)}
                      >
                        Make Payment
                      </button>
                    )}
                    {booking.status === "CONFIRMED" &&
                      new Date(booking.toDate) < currentDate &&
                      !reviewedVehicleIds.includes(booking.vehicleId) && (
                        <button
                          className="w-full bg-blue-500 text-white px-4 py-1 rounded"
                          onClick={() =>
                            handleAddReviewClick(booking.vehicleId)
                          }
                        >
                          Add Review
                        </button>
                      )}{" "}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="8" className="text-center p-4 text-gray-400">
                  No bookings found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {isVehicleModalOpen && selectedVehicle && (
        <Modal
          title="Vehicle Details"
          onClose={() => setIsVehicleModalOpen(false)}
        >
          <img
            src={selectedVehicle.vehicleImageURL}
            alt={selectedVehicle.modelName}
            className="w-full h-40 object-cover rounded-lg"
          />
          <p className="mt-4">
            <strong className="pr-16 mr-4">Model Name:</strong>{" "}
            {selectedVehicle.modelName}
          </p>
          <p>
            <strong className="pr-24 mr-3">Category:</strong>{" "}
            {selectedVehicle.categoryType}
          </p>
          <p>
            <strong className="pr-24 mr-2">Fuel Type:</strong>{" "}
            {selectedVehicle.fuelType}
          </p>
          <p>
            <strong className="pr-24 mr-4">Mileage:</strong>{" "}
            {selectedVehicle.mileage}km/litres
          </p>
          <p>
            <strong className="pr-4">Registration Number:</strong>{" "}
            {selectedVehicle.registrationNumber}
          </p>
          <p>
            <strong className="pr-9">Insurance Number:</strong>{" "}
            {selectedVehicle.insuranceNumber}
          </p>
        </Modal>
      )}

      {isDriverModalOpen && (
        <Modal
          title="Driver Details"
          onClose={() => setIsDriverModalOpen(false)}
        >
          {selectedDriver ? (
            <>
              <p>
                <strong>Name:</strong> {selectedDriver.name}
              </p>
              <p>
                <strong>License Number:</strong> {selectedDriver.licenseNumber}
              </p>
              <p>
                <strong>Email:</strong> {selectedDriver.email}
              </p>
              <p>
                <strong>Contact Number:</strong> {selectedDriver.contactNumber}
              </p>
              <p>
                <strong>Cost:</strong> Rs. {selectedDriver.driverCostPerDay}/day
              </p>
            </>
          ) : (
            <p>Driver Opted Out</p>
          )}
        </Modal>
      )}

      {isReviewModalOpen && (
        <Modal title="Add Review" onClose={() => setIsReviewModalOpen(false)}>
          <div className="flex items-center mb-4">
            {[1, 2, 3, 4, 5].map((star) => (
              <span
                key={star}
                className={`cursor-pointer text-xl ${
                  rating >= star ? "text-yellow-400" : "text-gray-300"
                }`}
                onClick={() => setRating(star)}
              >
                ★
              </span>
            ))}
          </div>
          <textarea
            className="w-full p-2 border border-gray-300 rounded-md mb-4"
            placeholder="Write your comment here..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
          <button
            className="w-full py-2 bg-orange-500 text-white rounded-md"
            onClick={handleReviewSubmit}
          >
            Submit Review
          </button>
        </Modal>
      )}
    </div>
  );
};

export default BookingHistory;
