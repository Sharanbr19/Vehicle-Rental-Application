import React, { useEffect, useState } from "react";
import {
  getFavoritesByCustomer,
  getVehicleById,
  getUserByEmail,
  removeFavorite,
  getAvailableVehicles,
} from "../../api/auth";
import { useCookies } from "react-cookie";
import { useNavigate } from "react-router-dom";
import { FaTrashAlt } from "react-icons/fa";
import DatePicker from "react-datepicker"; // Assuming you have react-datepicker installed
import "react-datepicker/dist/react-datepicker.css";
import { toast } from "react-toastify";
import StarRating from "../StarRating";

const Favorites = () => {
  const [favorites, setFavorites] = useState([]);
  const [filteredFavorites, setFilteredFavorites] = useState([]);
  const [userId, setUserId] = useState(null);
  const [cookies] = useCookies(["user", "email"]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [error, setError] = useState("");
  const [selectedVehicleId, setSelectedVehicleId] = useState(null);
  const [isAvailableChecked, setIsAvailableChecked] = useState(false);
  const navigate = useNavigate();

  const email = cookies.email;
  const token = cookies.user;

  useEffect(() => {
    const fetchUserId = async () => {
      if (email && token) {
        try {
          const user = await getUserByEmail(email, token);
          setUserId(user.userId);
        } catch (error) {
          console.error("Error fetching user by email:", error);
        }
      }
    };

    fetchUserId();
  }, [email, token]);

  useEffect(() => {
    const fetchFavorites = async () => {
      if (userId) {
        try {
          const fetchedFavorites = await getFavoritesByCustomer(userId, token);
          const favoritesWithDetails = await Promise.all(
            fetchedFavorites.map(async (favorite) => {
              try {
                const vehicleDetails = await getVehicleById(
                  favorite.vehicleId,
                  token
                );
                return { ...favorite, ...vehicleDetails };
              } catch (error) {
                console.error(
                  `Error fetching vehicle details for ID ${favorite.vehicleId}:`,
                  error
                );
                return favorite;
              }
            })
          );

          setFavorites(favoritesWithDetails);
          setFilteredFavorites(favoritesWithDetails);
        } catch (error) {
          console.error("Error fetching favorites:", error);
        }
      }
    };

    fetchFavorites();
  }, [userId, token]);

  const handleRemoveFavorite = async (vehicleId) => {
    try {
      await removeFavorite(userId, vehicleId, token);
      setFavorites(favorites.filter((fav) => fav.vehicleId !== vehicleId));
      setFilteredFavorites(
        filteredFavorites.filter((fav) => fav.vehicleId !== vehicleId)
      );
      toast.success("Vehicle removed from favorites");
    } catch (error) {
      console.error("Error removing favorite:", error);
    }
  };

  const openModal = (vehicleId) => {
    setSelectedVehicleId(vehicleId);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setFromDate(null);
    setToDate(null);
  };

  const formatDate = (date) => {
    if (date) {
      return new Date(date).toISOString().split("T")[0];
    }
    return null;
  };

  const filterVehiclesByDate = async () => {
    setIsModalOpen(false);
    toast.success("Filtered Available Vehicles");
    if (fromDate && toDate) {
      const formattedFromDate = formatDate(fromDate);
      const formattedToDate = formatDate(toDate);

      const availableVehicles = await getAvailableVehicles(
        formattedFromDate,
        formattedToDate,
        token
      );
      const filtered = favorites.filter((vehicle) =>
        availableVehicles.some(
          (availableVehicle) => availableVehicle.vehicleId === vehicle.vehicleId
        )
      );
      setFilteredFavorites(filtered);
      setIsAvailableChecked(true);
    }
  };

  const handleBook = (vehicleId) => {
    navigate(`/book/${vehicleId}`);
  };

  const today = new Date();

  const validateDates = (from, to) => {
    setError("");

    if (!from || !to) return;

    if (to < from) {
      setError("To Date must be greater than From Date.");
      return;
    }

    const dayDifference = (to - from) / (1000 * 60 * 60 * 24);
    if (dayDifference > 15) {
      setError("Maximum allowed booking period is 15 days.");
      return;
    }
  };

  const handleFromDateChange = (date) => {
    setFromDate(date);
    if (toDate && toDate <= date) {
      setToDate(null);
    }

    validateDates(date, toDate);
  };

  const handleToDateChange = (date) => {
    setToDate(date);
    validateDates(fromDate, date);
  };

  return (
    <div>
      <h2 className="text-2xl pt-6 ps-6 font-bold">My Favorites</h2>
      <div className="p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
        {filteredFavorites.length === 0 ? (
          <div className="text-center col-span-full text-gray-500 text-lg">
            No favorite vehicles yet
          </div>
        ) : (
          filteredFavorites.map((vehicle) => (
            <div
              key={vehicle.vehicleId}
              className="bg-white rounded-lg border border-gray w-full sm:max-w-2xs md:max-w-sm lg:max-w-md rounded-lg shadow-md hover:shadow-lg transition-shadow flex flex-col mx-auto relative"
            >
              {vehicle.vehicleImageURL ? (
                <img
                  src={vehicle.vehicleImageURL}
                  alt={vehicle.modelName}
                  className="w-full rounded-lg h-40 sm:h-48 object-cover mb-2 sm:mb-4 rounded"
                />
              ) : (
                <div className="w-full h-40 sm:h-48 bg-gray-300 mb-2 sm:mb-4 rounded flex items-center justify-center">
                  <span className="text-gray-500">Image Not Available</span>
                </div>
              )}
              <div className="bg-cyan-100 p-4 rounded-b-lg">
                <h3 className="text-base sm:text-lg font-semibold mb-1 sm:mb-2">
                  {vehicle.modelName || "Unknown Model"} (
                  {vehicle.categoryType || "N/A"})
                </h3>

                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-gray-700 text-sm sm:text-base mb-1">
                      <strong>Fuel Type:</strong> {vehicle.fuelType}
                    </p>
                    <p className="text-gray-700 text-sm sm:text-base mb-1">
                      <strong>Model Year:</strong> {vehicle.modelYear}
                    </p>
                    <p className="text-gray-700 text-sm sm:text-base mb-1">
                      <strong>Mileage:</strong> {vehicle.mileage} km/litres
                    </p>
                  </div>
                  <div>
                    {vehicle.vehicleId && (
                      <StarRating vehicleId={vehicle.vehicleId} />
                    )}
                    <p className="text-green-600 text-2xl sm:text-base font-bold mt-4">
                      ₹{vehicle.pricePerDay}/day
                    </p>
                  </div>
                </div>

                <button
                  className="absolute top-2 right-2 text-red-500 hover:text-red-700"
                  onClick={() => handleRemoveFavorite(vehicle.vehicleId)}
                >
                  <FaTrashAlt size={20} />
                </button>
                <div className="flex justify-center">
                  {!isAvailableChecked ? (
                    <button
                      className="bg-green-500 text-white w-full py-2 px-4 rounded mt-5"
                      onClick={() => openModal(vehicle.vehicleId)}
                    >
                      Book Vehicle
                    </button>
                  ) : (
                    <button
                      className="bg-green-500 text-white w-full py-2 px-4 rounded mt-auto"
                      onClick={() => handleBook(vehicle.vehicleId)}
                    >
                      Book Vehicle
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex justify-center items-center z-50">
          <div className="bg-white p-4 rounded-md w-96 relative">
            <button
              onClick={closeModal}
              className="absolute top-2 right-4 text-red-500 hover:text-red-700 text-4xl"
            >
              ×
            </button>

            <h2 className="text-xl text-orange-500 font-semibold text-center mb-6">
              Select Booking Dates
            </h2>

            <div className="mb-4 flex justify-center items-center">
              <label
                htmlFor="fromDate"
                className="block text-sm font-medium mr-4"
              >
                From Date
              </label>
              <DatePicker
                selected={fromDate}
                onChange={handleFromDateChange}
                minDate={today}
                className="w-full p-2 border border-gray-300 rounded-md"
                placeholderText="mm/dd/yyyy"
              />
            </div>

            <div className="mb-4 flex justify-center items-center">
              <label
                htmlFor="toDate"
                className="block text-sm font-medium mr-8"
              >
                To Date
              </label>
              <DatePicker
                selected={toDate}
                onChange={handleToDateChange}
                minDate={fromDate || today}
                className="w-full p-2 border border-gray-300 rounded-md"
                placeholderText="mm/dd/yyyy"
              />
            </div>

            {error && (
              <p className="text-red-500 text-sm text-center">{error}</p>
            )}

            <div className="flex justify-center mt-6">
              <button
                onClick={filterVehiclesByDate}
                disabled={!!error || !fromDate || !toDate}
                className={`py-2 px-4 rounded mr-2 ${
                  error || !fromDate || !toDate
                    ? "bg-orange-400 text-white cursor-not-allowed"
                    : "bg-orange-500 hover:bg-orange-600 text-white"
                }`}
              >
                Filter Available Vehicles
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Favorites;
