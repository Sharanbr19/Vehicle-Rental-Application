import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import {
  searchVehicles,
  sortVehicles,
  getAllVehicles,
  filterVehicles,
  addFavorite,
  removeFavorite,
  getUserByEmail,
  getFavoritesByCustomer,
  getAvailableVehicles,
} from "../../api/auth";
import { useCookies } from "react-cookie";
import { useNavigate } from "react-router-dom";
import StarRating from "../StarRating";
import { Search, Sliders, Filter } from "lucide-react";

const VehicleView = () => {
  const [vehicles, setVehicles] = useState([]);
  const [filteredVehicles, setFilteredVehicles] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOption, setSortOption] = useState("");
  
  const [filterCriteria, setFilterCriteria] = useState({
    categoryType: "",
    fuelType: "",
    priceRange: "",
  });
  const [cookies] = useCookies(["user", "email"]);
  const vehiclesPerPage = 6;
  const navigate = useNavigate();
  const [favorites, setFavorites] = useState(new Set());
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [error, setError] = useState("");
  const [availableVehicles, setAvailableVehicles] = useState([]);
  const [isAvailableChecked, setIsAvailableChecked] = useState(false);

  const fetchUserId = async () => {
    const email = cookies.email;
    const token = cookies.user;
    try {
      const user = await getUserByEmail(email, token);
      return user.userId;
    } catch (error) {
      console.error("Error fetching user by email:", error);
      toast.error("Failed to fetch user details.");
    }
  };

  const fetchVehicles = async () => {
    const token = cookies.user;
    if (!token) {
      toast.error("Authentication token not found. Please log in.");
      return;
    }

    try {
      const data = await getAllVehicles(token);
      setVehicles(data);
      setFilteredVehicles(data);
    } catch (error) {
      console.error("Error fetching vehicle data", error);
      toast.error("Failed to fetch vehicles.");
    }
  };

  const fetchFavorites = async () => {
    const userId = await fetchUserId();
    const token = cookies.user;

    try {
      const userFavorites = await getFavoritesByCustomer(userId, token);
      const favoriteIds = new Set(userFavorites.map((fav) => fav.vehicleId));
      setFavorites(favoriteIds);
    } catch (error) {
      console.error("Error fetching favorites:", error);
      toast.error("Failed to fetch favorites.");
    }
  };

  useEffect(() => {
    const initializeData = async () => {
      await fetchVehicles();
      await fetchFavorites();
    };
    initializeData();
  }, []);

  const handleSearch = async (e) => {
    const keyword = e.target.value;
    setSearchQuery(keyword);
    const token = cookies.user;

    try {
      const data = await searchVehicles(keyword, token);
      setFilteredVehicles(data);
      setCurrentPage(1);
    } catch (error) {
      toast.error("Failed to search vehicles.");
    }
  };

  const handleSortChange = async (e) => {
    const [sortBy, order] = e.target.value.split("_");
    setSortOption(e.target.value);
    const token = cookies.user;

    try {
      const data = await sortVehicles(sortBy, order === "asc", token);
      setFilteredVehicles(data);
      setCurrentPage(1);
    } catch (error) {
      toast.error("Failed to sort vehicles.");
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilterCriteria((prev) => {
      const updatedCriteria = {
        ...prev,
        [name]: value,
      };
      applyFilters(updatedCriteria);
      return updatedCriteria;
    });
  };

  const applyFilters = async (updatedCriteria) => {
    const token = cookies.user;
    try {
      const data = await filterVehicles(updatedCriteria, token);
      setFilteredVehicles(data);
      setCurrentPage(1);
    } catch (error) {
      toast.error("Failed to apply filters.");
    }
  };

  const toggleFavorite = async (vehicleId) => {
    const userId = await fetchUserId();
    const token = cookies.user;

    if (favorites.has(vehicleId)) {
      try {
        await removeFavorite(userId, vehicleId, token);
        setFavorites((prev) => {
          const newFavorites = new Set(prev);
          newFavorites.delete(vehicleId);
          return newFavorites;
        });
        toast.success("Vehicle removed from favorites.");
      } catch (error) {
        toast.error("Failed to remove vehicle from favorites.");
      }
    } else {
      try {
        const favoriteDTO = { userId, vehicleId };
        await addFavorite(favoriteDTO, token);
        setFavorites((prev) => new Set(prev).add(vehicleId));
        toast.success("Vehicle added to favorites.");
      } catch (error) {
        toast.error("Failed to add vehicle to favorites.");
      }
    }
  };

  const totalPages = Math.ceil(filteredVehicles.length / vehiclesPerPage);

  const paginateVehicles = () => {
    const startIndex = (currentPage - 1) * vehiclesPerPage;
    return filteredVehicles.slice(startIndex, startIndex + vehiclesPerPage);
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };

  const handleBook = (vehicleId) => {
    navigate(`/book/${vehicleId}`);
  };

  const today = new Date().toISOString().split("T")[0];

  const handleFromDateChange = (e) => {
    const selectedFromDate = e.target.value;
    setFromDate(selectedFromDate);
    if (toDate && new Date(toDate) <= new Date(selectedFromDate)) {
      setToDate("");
    }
    validateDates(selectedFromDate, toDate);
  };

  const handleToDateChange = (e) => {
    const selectedToDate = e.target.value;
    setToDate(selectedToDate);
    validateDates(fromDate, selectedToDate);
  };

  const validateDates = (from, to) => {
    setError(""); 
    if (!from || !to) return; 
    const fromDateObj = new Date(from);
    const toDateObj = new Date(to);
    if (toDateObj < fromDateObj) {
      setError("To Date must be greater than From Date.");
      return;
    }
    const dayDifference = (toDateObj - fromDateObj) / (1000 * 60 * 60 * 24);
    if (dayDifference > 15) {
      setError("Maximum allowed booking period is 15 days.");
      return;
    }
  };

  const checkAvailableVehicles = async () => {
    if (!fromDate || !toDate) {
      toast.error("Please select both from and to dates.");
      return;
    }
    localStorage.clear();
    localStorage.setItem("fromDate", fromDate);
    localStorage.setItem("toDate", toDate);
    const token = cookies.user;
    try {
      const availableVehiclesData = await getAvailableVehicles(
        fromDate,
        toDate,
        token
      );
      setIsModalOpen(false)
      setAvailableVehicles(availableVehiclesData);
      setFilteredVehicles(availableVehiclesData);
      setIsAvailableChecked(true);
      toast.success("Filtered available vehicles");
    } catch (error) {
      toast.error("Failed to check available vehicles.");
    }
  };

  return (
    <div>
      <nav className="bg-gray-200 pt-3 pb-3 ps-1 pe-1 text-white">
        <div className="ps-2 pe-2 flex flex-wrap justify-between items-center">
          <div className="flex items-center bg-white text-black p-2 rounded-md w-3/4 sm:w-auto">
            <input
              type="text"
              placeholder="Search Vehicles"
              value={searchQuery}
              onChange={handleSearch}
              className="outline-none ml-2 flex-1"
            />
            <Search className="text-orange-600" />
          </div>

          <div className="flex gap-2 items-center bg-white text-black p-2 rounded-md">
            <select
              value={sortOption}
              onChange={handleSortChange}
              className="ml-2 outline-none bg-white"
            >
              <option disabled value="">
                Sort By
              </option>
              <option value="priceperday_asc">Price: Low to High</option>
              <option value="priceperday_desc">Price: High to Low</option>
              <option value="modelyear_asc">Year: Oldest to Latest</option>
              <option value="modelyear_desc">Year: Latest to Oldest</option>
            </select>
            <Sliders className="text-orange-600" />
          </div>

          <div className="mt-1 mb-1 flex flex-wrap items-center bg-white text-black rounded-md gap-1">
            <select
              name="categoryType"
              value={filterCriteria.categoryType}
              onChange={handleFilterChange}
              className="p-2 outline-none rounded bg-white"
            >
              <option value="">All Category</option>
              <option value="SUV">SUV</option>
              <option value="Sedan">Sedan</option>
              <option value="Hatchback">Hatchback</option>
              <option value="MUV">MUV</option>
              <option value="XUV">XUV</option>
              <option value="OffRoad">OffRoad</option>
              <option value="Jeep">Jeep</option>
            </select>

            <select
              name="color"
              value={filterCriteria.color}
              onChange={handleFilterChange}
              className="p-2 outline-none rounded bg-white"
            >
              <option value="">All Colors</option>
              <option value="Red">Red</option>
              <option value="White">White</option>
              <option value="Black">Black</option>
              <option value="Blue">Blue</option>
              <option value="Silver">Silver</option>
              <option value="Grey">Grey</option>
              <option value="Orange">Orange</option>
              <option value="Yellow">Yellow</option>
              <option value="Green">Green</option>
            </select>

            <select
              name="fuelType"
              value={filterCriteria.fuelType}
              onChange={handleFilterChange}
              className="p-2 outline-none rounded bg-white"
            >
              <option value="">All Fuel Type</option>
              <option value="Petrol">Petrol</option>
              <option value="Diesel">Diesel</option>
              <option value="Electric">Electric</option>
            </select>

            <select
              name="priceRange"
              value={filterCriteria.priceRange}
              onChange={handleFilterChange}
              className="p-2 outline-none bg-white"
            >
              <option value="">All Price Range</option>
              <option value="<500">less than ₹500</option>
              <option value="500-1000">₹500 - ₹1000</option>
              <option value="1000-1500">₹1000 - ₹1500</option>
              <option value="1500-2000">₹1500 - ₹2000</option>
              <option value=">2000">more than ₹2000</option>
            </select>

            <button className="bg-white text-white p-2 rounded flex items-center gap-2">
              <Filter className="text-orange-500" />
            </button>
          </div>
        </div>
      </nav>

      <div className="px-4 py-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
        {paginateVehicles().length > 0 ? (
          paginateVehicles().map((vehicle) => (
            <div
              key={vehicle.vehicleId}
              className="bg-white w-full sm:max-w-2xs md:max-w-sm lg:max-w-md rounded-lg border border-gray hover:shadow-lg transition-shadow flex flex-col mx-auto relative"
            >
              <img
                src={vehicle.vehicleImageURL}
                alt={vehicle.modelName}
                className="w-full h-40 sm:h-48 rounded-lg object-cover sm:mb-4 rounded"
              />
              <div className="bg-cyan-100 p-4 rounded-b-lg">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-base sm:text-lg font-semibold">
                    {vehicle.modelName} ({vehicle.categoryType})
                  </h3>
                </div>

                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-gray-700 text-sm sm:text-base mb-1">
                      <strong>Fuel Type:</strong> {vehicle.fuelType}
                    </p>
                    <p className="text-gray-700 text-sm sm:text-base mb-1">
                      <strong>Model Year:</strong> {vehicle.modelYear}
                    </p>
                    <p className="text-gray-700 text-sm sm:text-base mb-1">
                      <strong>Mileage:</strong> {vehicle.mileage}km/litres
                    </p>
                  </div>
                  <div>
                    {vehicle.vehicleId && (
                      <StarRating vehicleId={vehicle.vehicleId} />
                    )}
                    <p className="text-green-600 text-2xl sm:text-base font-bold mt-4">
                      ₹{vehicle.pricePerDay}/day
                    </p>
                  </div>
                </div>

                <div className="flex justify-center mt-4">
                  {!isAvailableChecked ? (
                    <button
                      className="bg-green-500 w-full text-white py-2 px-4 rounded mt-auto"
                      onClick={() => setIsModalOpen(true)}
                    >
                      Book Vehicle
                    </button>
                  ) : (
                    <button
                      className="bg-green-500 w-full text-white py-2 px-4 rounded mt-auto"
                      onClick={() => handleBook(vehicle.vehicleId)}
                    >
                      Book Vehicle
                    </button>
                  )}
                </div>

                <button
                  className={`absolute top-1 right-1 p-2 rounded-full ${
                    favorites.has(vehicle.vehicleId)
                      ? "text-red-600"
                      : "text-gray-300"
                  }`}
                  onClick={() => toggleFavorite(vehicle.vehicleId)}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-6 w-6"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
                    />
                  </svg>
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full text-center text-gray-500 text-xl">
            No vehicles found matching the criteria.
          </div>
        )}
      </div>

      {filteredVehicles.length > vehiclesPerPage && (
        <div className="ps-6 pe-6 pb-4 flex items-center justify-between">
          <button
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
            className={`px-4 py-2 text-white rounded-md ${
              currentPage === 1
                ? "bg-blue-300"
                : "bg-blue-500 hover:bg-blue-700"
            }`}
          >
            Previous
          </button>
          <span>
            Page {currentPage} of {totalPages}
          </span>
          <button
            onClick={handleNextPage}
            disabled={currentPage === totalPages}
            className={`px-4 py-2 text-white rounded-md ${
              currentPage === totalPages
                ? "bg-blue-300"
                : "bg-blue-500 hover:bg-blue-700"
            }`}
          >
            Next
          </button>
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded-md w-96 relative">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-2 right-4 text-red-500 hover:text-red-700 text-3xl"
            >
              ×
            </button>

            <h2 className="text-xl text-orange-500 font-semibold text-center mb-6">
              Select Booking Dates
            </h2>

            <div className="mb-4 flex items-center">
              <label
                htmlFor="fromDate"
                className="block text-sm font-medium mr-4"
              >
                From Date
              </label>
              <input
                type="date"
                id="fromDate"
                value={fromDate}
                onChange={handleFromDateChange}
                min={today} 
                className="w-3/4 p-2 border border-gray-300 rounded-md"
              />
            </div>

            <div className="mb-4 flex items-center">
              <label
                htmlFor="toDate"
                className="block text-sm font-medium mr-8"
              >
                To Date
              </label>
              <input
                type="date"
                id="toDate"
                value={toDate}
                onChange={handleToDateChange}
                min={fromDate || today} 
                className="w-3/4 p-2 border border-gray-300 rounded-md"
              />
            </div>

            {error && (
              <p className="text-red-500 text-sm text-center">{error}</p>
            )}

            <div className="flex justify-center mt-6">
              <button
                onClick={checkAvailableVehicles}
                disabled={!!error || !fromDate || !toDate}
                className={`py-2 px-4 rounded mr-2 ${
                  error || !fromDate || !toDate
                    ? "bg-orange-400 text-white cursor-not-allowed"
                    : "bg-orange-500 hover:bg-orange-600 text-white"
                }`}
              >
                Filter Available Vehicles
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VehicleView;
