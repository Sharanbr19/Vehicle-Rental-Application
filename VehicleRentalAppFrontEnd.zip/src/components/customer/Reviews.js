import React, { useEffect, useState } from "react";
import {
  FaEdit,
  FaTrash,
  FaStar,
  FaStarHalfAlt,
  FaRegStar,
  FaTimes,
} from "react-icons/fa";
import {
  getUserByEmail,
  getReviewsByCustomerId,
  updateReview,
  deleteReview,
  getVehicleById,
} from "../../api/auth";
import Cookies from "js-cookie";
import { toast } from "react-toastify";

const Reviews = () => {
  const [reviews, setReviews] = useState([]);
  const [userId, setUserId] = useState(null);
  const [editingReview, setEditingReview] = useState(null);
  const [updatedComment, setUpdatedComment] = useState("");
  const [updatedRating, setUpdatedRating] = useState(null);
  const [vehicles, setVehicles] = useState({});
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const email = Cookies.get("email");
    const token = Cookies.get("user");

    if (email && token) {
      getUserByEmail(email, token).then((user) => {
        setUserId(user.userId);
        getReviewsByCustomerId(user.userId, token).then((data) => {
          setReviews(data);
          data.forEach((review) => {
            getVehicleById(review.vehicleId, token).then((vehicle) => {
              setVehicles((prevVehicles) => ({
                ...prevVehicles,
                [review.vehicleId]: vehicle,
              }));
            });
          });
        });
      });
    }
  }, []);

  const handleEdit = (vehicleId, userId, currentComment, currentRating) => {
    setEditingReview(vehicleId);
    setUpdatedComment(currentComment);
    setUpdatedRating(currentRating);
    setIsModalOpen(true);
  };

  const handleUpdate = (vehicleId, userId) => {
    const updatedReviewDTO = { comment: updatedComment, rating: updatedRating };
    const token = Cookies.get("user");

    updateReview(userId, vehicleId, updatedReviewDTO, token).then(() => {
      setReviews(
        reviews.map((review) =>
          review.vehicleId === vehicleId
            ? { ...review, comment: updatedComment, rating: updatedRating }
            : review
        )
      );
      toast.success("Review Updated Successfully");
      setIsModalOpen(false);
      setUpdatedComment("");
      setUpdatedRating(null);
    });
  };

  const handleDelete = (vehicleId, userId) => {
    const token = Cookies.get("user");

    deleteReview(userId, vehicleId, token).then(() => {
      setReviews(reviews.filter((review) => review.vehicleId !== vehicleId));
      toast.success("Review for vehicle deleted successfully");
    });
  };

  const handleRatingClick = (rating) => {
    setUpdatedRating(rating);
  };

  const renderStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      if (i <= rating) {
        stars.push(<FaStar key={i} className="text-yellow-500" />);
      } else if (i - rating < 1) {
        stars.push(<FaStarHalfAlt key={i} className="text-yellow-500" />);
      } else {
        stars.push(<FaRegStar key={i} className="text-yellow-500" />);
      }
    }
    return stars;
  };

  return (
    <div className="p-6 bg-gray-100 min-h-[100vh] h-auto">
      <h2 className="text-2xl font-bold mb-6">My Reviews</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {reviews.length === 0 ? (
          <p className="text-center text-gray-500 text-lg col-span-full">
            No reviews yet for vehicles.
          </p>
        ) : (
          reviews.map((review) => {
            const vehicle = vehicles[review.vehicleId];
            return (
              <div
                key={review.vehicleId}
                className="bg-white p-5 rounded-lg shadow-md relative"
              >
                <div className="absolute top-2 right-2 flex space-x-6">
                  <button
                    onClick={() =>
                      handleEdit(
                        review.vehicleId,
                        userId,
                        review.comment,
                        review.rating
                      )
                    }
                    className="text-yellow-500 text-2xl hover:text-yellow-700"
                  >
                    <FaEdit />
                  </button>
                  <button
                    onClick={() => handleDelete(review.vehicleId, userId)}
                    className="text-red-500 text-2xl hover:text-red-700"
                  >
                    <FaTrash />
                  </button>
                </div>

                {vehicle && (
                  <div className="mb-4">
                    <img
                      src={vehicle.vehicleImageURL}
                      alt={vehicle.vehicleModalName}
                      className="w-full h-48 object-cover rounded-md"
                    />
                    <h3 className="text-lg font-semibold">
                      {vehicle.modelName}
                    </h3>
                  </div>
                )}
                <div className="flex mt-2 mb-2">
                  {renderStars(review.rating)}
                </div>
                <p>{review.comment}</p>
              </div>
            );
          })
        )}
      </div>

      {/* Modal for editing review */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-96 relative">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-2 right-2 text-red-500 text-xl hover:text-red-700"
            >
              <FaTimes />
            </button>
            <h3 className="text-xl text-center font-semibold mb-4">
              Edit Review
            </h3>
            <div className="flex mt-4">
              <h6 className="pr-3 font-semibold">Rating:</h6>
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => handleRatingClick(star)}
                  className={`text-2xl ${
                    updatedRating >= star ? "text-yellow-500" : "text-gray-300"
                  }`}
                >
                  <FaStar />
                </button>
              ))}
            </div>
            <textarea
              value={updatedComment}
              onChange={(e) => setUpdatedComment(e.target.value)}
              className="w-full h-20 p-2 border border-gray-300 rounded-lg mt-4"
              placeholder="Update your comment"
            />
            <div className="flex justify-center">
              <button
                onClick={() => handleUpdate(editingReview, userId)}
                className="mt-4 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600"
              >
                Update Review
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Reviews;
