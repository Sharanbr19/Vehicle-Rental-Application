import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { updateUserProfile, getUserByEmail } from "../../api/auth";
import { useCookies } from "react-cookie";
import {
  FaUserCircle,
  FaEye,
  FaEyeSlash,
  FaToggleOn,
  FaToggleOff,
} from "react-icons/fa";

const UpdateProfile = ({ onClose }) => {
  const [cookies, setCookie, removeCookie] = useCookies(["user", "email"]);
  const [profileData, setProfileData] = useState({
    email: cookies.email || "",
    password: "",
    newPassword: "",
    confirmPassword: "",
    name: "",
    contactNumber: "",
    gender: "",
    address: "",
    dateOfBirth: "",
  });

  const [formErrors, setFormErrors] = useState({});
  const [newPasswordVisible, setNewPasswordVisible] = useState(false);
  const [confirmPasswordVisible, setConfirmPasswordVisible] = useState(false);
  const [passwordFieldsVisible, setPasswordFieldsVisible] = useState(false);

  const token = cookies.user;
  const email = cookies.email;

  useEffect(() => {
    if (email && token) {
      getUserByEmail(email, token)
        .then((user) => {
          setProfileData({
            ...user,
          });
        })
        .catch((error) => {
          toast.error("Failed to fetch user data.");
        });
    }
  }, [email, token]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfileData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const validate = () => {
    const errors = {};

    if (!profileData.password) errors.password = "Password is required.";
    if (!profileData.name) errors.name = "Name is required.";
    if (profileData.name.length < 3 || profileData.name.length > 50)
      errors.name = "Name length should be less than 50";
    if (!profileData.contactNumber)
      errors.contactNumber = "Contact Number is required.";
    if (!profileData.gender) errors.gender = "Gender is required.";
    if (!profileData.dateOfBirth)
      errors.dateOfBirth = "Date of Birth is required.";

    const phonePattern = /^[0-9]{10}$/;
    if (
      profileData.contactNumber &&
      !phonePattern.test(profileData.contactNumber)
    ) {
      errors.contactNumber = "Contact Number must be 10 digits.";
    }

    const dob = new Date(profileData.dateOfBirth);
    const age = new Date().getFullYear() - dob.getFullYear();
    if (age < 18) {
      errors.dateOfBirth = "You must be at least 18 years old.";
    }
    if (age > 100) {
      errors.dateOfBirth = "You must be less than 100 years old.";
    }

    if (passwordFieldsVisible) {
      const passwordPattern =
        /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,50}$/;
      if (
        !profileData.newPassword ||
        !passwordPattern.test(profileData.newPassword)
      ) {
        errors.newPassword =
          "Password must be between 8 to 50 characters, contain one letter, one number, and one special character.";
      }
      if (profileData.newPassword !== profileData.confirmPassword) {
        errors.confirmPassword = "Passwords must match.";
      }
    } else {
      console.log(profileData.password);
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleUpdateProfile = async () => {
    if (!validate()) return;

    try {
      if (!token) {
        toast.error("User is not authenticated.");
        return;
      }

      const updatedProfileData = { ...profileData };

      if (profileData.newPassword) {
        updatedProfileData.password = profileData.newPassword;
      }else{
        updatedProfileData.password = null;
      }

      delete updatedProfileData.newPassword;
      delete updatedProfileData.confirmPassword;

      await updateUserProfile(
        updatedProfileData.userId,
        updatedProfileData,
        token
      );
      toast.success("Profile updated successfully.");
      onClose();
    } catch (error) {
      toast.error("Failed to update profile.");
    }
  };

  const toggleNewPasswordVisibility = () => {
    setNewPasswordVisible(!newPasswordVisible);
  };

  const toggleConfirmPasswordVisibility = () => {
    setConfirmPasswordVisible(!confirmPasswordVisible);
  };

  const togglePasswordFieldsVisibility = () => {
    setPasswordFieldsVisible(!passwordFieldsVisible);
  };

  return (
    <div className="fixed top-0 right-0 z-50 flex items-center justify-center bg-black bg-opacity-75 w-full h-full">
      <div className="bg-white p-6 rounded-lg w-full max-w-lg relative text-black shadow-lg">
        <button
          className="absolute top-2 right-2 text-4xl text-red-600 hover:text-red-800"
          onClick={onClose}
        >
          &times;
        </button>

        <div className="mb-4 flex items-center">
          <div className="text-orange-500 text-8xl mr-8">
            <FaUserCircle />
          </div>
          <div className="text-2xl text-gray-800">
            <span>{profileData.email}</span>
          </div>
        </div>

        <form>
          <div className="mb-2 flex items-center">
            <label className="block w-1/3 text-gray-700">Name</label>
            <input
              type="text"
              name="name"
              value={profileData.name}
              onChange={handleChange}
              placeholder="Full Name"
              className="w-2/3 p-2 border border-gray-300 rounded"
            />
          </div>
          {formErrors.name && (
            <p className="text-red-500 mb-3">{formErrors.name}</p>
          )}

          <div className="mb-2 flex items-center">
            <label className="block w-1/3 text-gray-700">Contact Number</label>
            <input
              type="text"
              name="contactNumber"
              value={profileData.contactNumber}
              onChange={handleChange}
              placeholder="Contact Number"
              className="w-2/3 p-2 border border-gray-300 rounded"
            />
          </div>
          {formErrors.contactNumber && (
            <p className="text-red-500 mb-3">{formErrors.contactNumber}</p>
          )}

          <div className="mb-2 flex items-center">
            <label className="block w-1/3 text-gray-700">Date of Birth</label>
            <input
              type="date"
              name="dateOfBirth"
              value={profileData.dateOfBirth}
              onChange={handleChange}
              className="w-2/3 p-2 border border-gray-300 rounded"
            />
          </div>
          {formErrors.dateOfBirth && (
            <p className="text-red-500 mb-3">{formErrors.dateOfBirth}</p>
          )}

          <div className="mb-2 flex items-center">
            <label className="block w-1/3 text-gray-700">Gender</label>
            <select
              name="gender"
              value={profileData.gender}
              onChange={handleChange}
              className="w-2/3 p-2 border border-gray-300 rounded"
            >
              <option disabled="true" value="">
                Select Gender
              </option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>
          {formErrors.gender && (
            <p className="text-red-500 mb-3">{formErrors.gender}</p>
          )}

          <div className="mb-2 flex items-center">
            <label className="block w-1/3 text-gray-700">Change Password</label>
            <div
              onClick={togglePasswordFieldsVisibility}
              className="cursor-pointer text-3xl text-orange-300"
            >
              {passwordFieldsVisible ? (
                <FaToggleOn width={100} />
              ) : (
                <FaToggleOff width={100} />
              )}
            </div>
          </div>

          {passwordFieldsVisible && (
            <>
              <div className="mb-2 flex items-center relative">
                <label className="block w-1/3 text-gray-700">
                  New Password
                </label>
                <input
                  type={newPasswordVisible ? "text" : "password"}
                  name="newPassword"
                  value={profileData.newPassword}
                  onChange={handleChange}
                  placeholder="New Password"
                  className="w-2/3 p-2 border border-gray-300 rounded pr-10"
                />
                <div
                  onClick={toggleNewPasswordVisibility}
                  className="absolute right-3 cursor-pointer"
                >
                  {newPasswordVisible ? <FaEyeSlash /> : <FaEye />}
                </div>
              </div>
              {formErrors.newPassword && (
                <p className="text-red-500 mb-3">{formErrors.newPassword}</p>
              )}

              <div className="mb-2 flex items-center relative">
                <label className="block w-1/3 text-gray-700">
                  Confirm Password
                </label>
                <input
                  type={confirmPasswordVisible ? "text" : "password"}
                  name="confirmPassword"
                  value={profileData.confirmPassword}
                  onChange={handleChange}
                  placeholder="Confirm Password"
                  className="w-2/3 p-2 border border-gray-300 rounded pr-10"
                />
                <div
                  onClick={toggleConfirmPasswordVisibility}
                  className="absolute right-3 cursor-pointer"
                >
                  {confirmPasswordVisible ? <FaEyeSlash /> : <FaEye />}
                </div>
              </div>
              {formErrors.confirmPassword && (
                <p className="text-red-500 mb-3">
                  {formErrors.confirmPassword}
                </p>
              )}
            </>
          )}
          <div className="flex justify-center">
            <button
              type="button"
              onClick={handleUpdateProfile}
              className="w-full  p-3 mt-3 bg-orange-500 hover:bg-orange-700 text-white rounded"
            >
              Update Profile
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UpdateProfile;
