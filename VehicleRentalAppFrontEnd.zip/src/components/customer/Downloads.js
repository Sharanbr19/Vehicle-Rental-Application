import React, { useEffect, useState } from "react";
import { getUserByEmail, getRentalAgreementsByCustomerId, getInvoicesByCustomerId } from "../../api/auth";
import Cookies from "js-cookie";
import jsPDF from "jspdf";

const Downloads = () => {
  const [rentalAgreements, setRentalAgreements] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [customerId, setCustomerId] = useState(null);
  const token = Cookies.get("user");
  const email = Cookies.get("email");

  useEffect(() => {
    const fetchUserAndDocuments = async () => {
      try {
        if (!email || !token) throw new Error("User not authenticated");
        
        const userResponse = await getUserByEmail(email, token);
        const customerId = userResponse?.userId;
        setCustomerId(customerId);

        if (!customerId) throw new Error("Customer ID not found");

        const [agreementsResponse, invoicesResponse] = await Promise.all([
          getRentalAgreementsByCustomerId(customerId, token),
          getInvoicesByCustomerId(customerId, token),
        ]);

        setRentalAgreements(agreementsResponse || []);
        setInvoices(invoicesResponse || []);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchUserAndDocuments();
  }, [email, token]);

  const generatePDF = (data, type) => {
    const doc = new jsPDF();
    if (type === "rental") {
      doc.text("Rental Agreement", 10, 10);
      doc.text(`Booking ID: ${data.bookingId}`, 10, 20);
      doc.text(`Agreement Date: ${data.agreementDate}`, 10, 30);
      doc.text(`Terms & Conditions: ${data.termsAndConditions}`, 10, 40);
      doc.save(`Rental_Agreement_${data.bookingId}.pdf`);
    } else {
      doc.text("Invoice", 10, 10);
      doc.text(`Booking ID: ${data.bookingId}`, 10, 20);
      doc.text(`Invoice Date: ${data.invoiceDate}`, 10, 30);
      doc.text(`Total Amount: ₹${data.totalAmount}`, 10, 40);
      doc.save(`Invoice_${data.bookingId}.pdf`);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Downloads</h2>

      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-3">Rental Agreements</h3>
        {rentalAgreements.length > 0 ? (
          <ul>
            {rentalAgreements.map((agreement) => (
              <li key={agreement.rentalId} className="mb-2">
                <button
                  onClick={() => generatePDF(agreement, "rental")}
                  className="bg-blue-500 text-white px-4 py-2 rounded"
                >
                  Download Rental Agreement (Booking ID: {agreement.bookingId})
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p>No rental agreements found.</p>
        )}
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-3">Invoices</h3>
        {invoices.length > 0 ? (
          <ul>
            {invoices.map((invoice) => (
              <li key={invoice.invoiceId} className="mb-2">
                <button
                  onClick={() => generatePDF(invoice, "invoice")}
                  className="bg-green-500 text-white px-4 py-2 rounded"
                >
                  Download Invoice (Booking ID: {invoice.bookingId})
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p>No invoices found.</p>
        )}
      </div>
    </div>
  );
};

export default Downloads;
