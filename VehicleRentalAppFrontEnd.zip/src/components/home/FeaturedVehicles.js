import React from "react";
import { Star } from "lucide-react"; // Icon for star ratings
import BlackCar from "../../assets/images/vehicles/blackCar.png";
import BlackJeep from "../../assets/images/vehicles/blackJeep.png";
import BlueCar from "../../assets/images/vehicles/blueCar.png";
import OrangeCar from "../../assets/images/vehicles/orangeCar.png";
import RedCar from "../../assets/images/vehicles/redCar.png";
import SilverCar from "../../assets/images/vehicles/silverCar.png";
import WhiteCar from "../../assets/images/vehicles/whiteCar.png";
import WhiteJeep from "../../assets/images/vehicles/whiteJeep.png";
import { useNavigate } from "react-router-dom";

function FeaturedVehicles({ isAuthenticated }) {
  const vehicles = [
    {
      id: 1,
      name: "Suzuki Vitara Brezza",
      model: "SUV",
      cost: "Rs 1000/day",
      rating: 4.5,
      image: OrangeCar,
    },
    {
      id: 2,
      name: "Honda Accord 2023",
      model: "Sedan",
      cost: "Rs 1300/day",
      rating: 5,
      image: BlueCar,
    },
    {
      id: 3,
      name: "Ford F-150 2024",
      model: "Sedan",
      cost: "Rs 1500/day",
      rating: 4.5,
      image: SilverCar,
    },
    {
      id: 4,
      name: "Volkswagen Polo 2023",
      model: "Hatchback",
      cost: "Rs 2000/day",
      rating: 4.5,
      image: RedCar,
    },
    {
      id: 5,
      name: "Jimny",
      model: "Offroad",
      cost: "Rs 1200/day",
      rating: 5,
      image: WhiteJeep,
    },
    {
      id: 6,
      name: "Mahindra Thar",
      model: "Jeep",
      cost: "Rs 1500/day",
      rating: 4.5,
      image: BlackJeep,
    },
    {
      id: 7,
      name: "Toyota Highlander 2024",
      model: "XUV",
      cost: "Rs 1800/day",
      rating: 4.5,
      image: WhiteCar,
    },
    {
      id: 8,
      name: "Audi A3",
      model: "Sedan",
      cost: "Rs 1500/day",
      rating: 4.5,
      image: BlackCar,
    },
  ];

  const navigate = useNavigate();

  const handleBookNow = () => {
    if (!isAuthenticated) {
      window.scrollTo(0, 0);
      navigate("/login");
    }
  };

  return (
    <div className="p-6 bg-gray-100 pb-10">
      <h2 className="text-3xl font-semibold text-center text-orange-500 mb-8 pb-5">
        Our Featured Vehicles
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {vehicles.map((vehicle) => (
          <div
            key={vehicle.id}
            className="relative bg-white shadow-lg rounded-lg overflow-hidden transition transform hover:scale-105 duration-300"
          >
            <div className="absolute top-0 right-0 bg-orange-500 text-white text-xs font-bold px-4 py-2 rounded-full">
              Featured
            </div>

            <img
              src={vehicle.image}
              alt={vehicle.name}
              className="w-full h-44 object-cover"
            />

            <div className="p-4">
              <h3 className="text-xl font-bold">{vehicle.name}</h3>
              <p className="text-gray-500 text-sm">{vehicle.model}</p>
              <p className="text-lg font-semibold text-green-600">
                {vehicle.cost}
              </p>

              <div className="flex items-center mt-2">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={18}
                    fill={i < Math.floor(vehicle.rating) ? "orange" : "none"}
                    stroke="orange"
                  />
                ))}
              </div>

              <button
                className="mt-4 w-full bg-yellow-400 hover:bg-yellow-500 text-black py-2 px-4 rounded-lg font-semibold"
                onClick={handleBookNow}
              >
                Book Now
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default FeaturedVehicles;
