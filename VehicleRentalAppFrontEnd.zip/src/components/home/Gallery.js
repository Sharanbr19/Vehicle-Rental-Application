import React from "react";
import Jeep from "../../assets/images/vehicles/jeep.png";
import Sedan from "../../assets/images/vehicles/sedan.png";
import Xuv from "../../assets/images/vehicles/xuv.png";
import BlackCar from "../../assets/images/vehicles/blackCar.png";
import BlackJeep from "../../assets/images/vehicles/blackJeep.png";
import BlueCar from "../../assets/images/vehicles/blueCar.png";
import OrangeCar from "../../assets/images/vehicles/orangeCar.png";
import RedCar from "../../assets/images/vehicles/redCar.png";
import SilverCar from "../../assets/images/vehicles/silverCar.png";
import WhiteCar from "../../assets/images/vehicles/whiteCar.png";
import WhiteJeep from "../../assets/images/vehicles/whiteJeep.png";
import BlackJeepOpen from "../../assets/images/vehicles/images/vehicles/blackJeepOpen.jpg";
import GreMuv from "../../assets/images/vehicles/images/vehicles/greyMuv.jpg";
import BlackHatchback from "../../assets/images/vehicles/images/vehicles/blackHatchback.jpg";
import BlueJeep from "../../assets/images/vehicles/images/vehicles/blueJeep.png";

const Gallery = () => {
  const images = [
    Jeep,
    Sedan,
    Xuv,
    SilverCar,
    BlackCar,
    WhiteCar,
    BlackJeepOpen,
    GreMuv,
    OrangeCar,
    BlueJeep,
    WhiteJeep,
    BlackJeep,
    BlueCar,
    RedCar,
    BlackHatchback
  ];

  return (
    <section id="gallery" className="py-16 text-center">
      <h2 className="text-4xl font-semibold mb-10 text-orange-600">Our Gallery</h2>
      <div className="px-28 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
        {images.map((image, index) => (
          <div key={index} className="relative group">
            <img
              src={image}
              alt={`Vehicle ${index + 1}`}
              className="w-full h-auto object-cover rounded-lg transform transition duration-500 ease-in-out group-hover:scale-110"
            />
          </div>
        ))}
      </div>
    </section>
  );
};

export default Gallery;
