import React from "react";
import { useNavigate } from "react-router-dom";
import jeepImage from "../../assets/images/hero-jeep.png";
import googlePlayIcon from "../../assets/images/googlePlayStore.png";
import appleStoreIcon from "../../assets/images/appleStore.png";

function Hero() {
  return (
    <div className="flex flex-col-reverse mt-8 mb-16 md:flex-row items-center justify-between p-8 space-y-8 md:space-y-0 md:space-x-8">
      <div className="w-full md:w-1/2 text-center md:text-left ml-8">
        <h1 className="text-4xl font-bold text-black mb-2">Looking to save</h1>
        <h1 className="text-4xl font-bold text-black">more on your rental vehicle?</h1>
        <p className="mt-4 text-lg text-gray-700">
          Rent the perfect car for your next journey. Whether it's an off-road
          adventure or a city exploration, we have a vehicle for you!
        </p>

        <div className="mt-6 flex justify-left space-x-4">
          <a href="https://play.google.com/store" target="_blank" rel="noopener noreferrer">
            <img src={googlePlayIcon} alt="Google Play" className="w-32 h-auto object-contain" />
          </a>
          <a href="https://www.apple.com/app-store/" target="_blank" rel="noopener noreferrer">
            <img src={appleStoreIcon} alt="Apple Store" className="w-32 h-auto object-contain" />
          </a>
        </div>

        <div className="mt-20 grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: "+15 Years Experience" },
            { label: "+100 Cars Available" },
            { label: "+500 Satisfied Customers" },
            { label: "+300 Customer Returns" }
          ].map((stat, index) => (
            <div key={index} className="bg-orange-500 text-white text-center p-4 rounded-lg shadow-lg flex flex-col items-center">
              <span className="text-sm">{stat.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="w-full md:w-1/2">
        <img src={jeepImage} alt="Hero Jeep" className="w-full h-auto object-cover rounded-lg" />
      </div>
    </div>
  );
}

export default Hero;
