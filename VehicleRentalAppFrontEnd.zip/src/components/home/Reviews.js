import React, { useState, useEffect } from "react";
import user1 from "../../assets/images/user1.jpg";
import user2 from "../../assets/images/user7.png";
import user3 from "../../assets/images/user3.png";
import user4 from "../../assets/images/user4.png";
import user5 from "../../assets/images/user5.png";
import user6 from "../../assets/images/user6.png";

function Reviews() {
  const reviews = [
    {
      id: 1,
      name: "Shravya",
      comment:
        "Great service! Everything was smooth, and the vehicle was in perfect condition. Definitely booking again!",
      stars: 5,
      image: user2,
    },
    {
      id: 2,
      name: "Ramesh",
      comment:
        "Loved the experience! The jeep I rented was very comfortable and perfect for my road trip. Highly recommended!",
      stars: 4,
      image: user1,
    },
    {
      id: 3,
      name: "Ananya",
      comment:
        "Fantastic! The service was excellent, and I had a wonderful time exploring new places. Will surely rent again.",
      stars: 5,
      image: user3,
    },
    {
      id: 4,
      name: "Pranav",
      comment:
        "Good experience overall, but could improve the pick-up process. However, the vehicle was top-notch!",
      stars: 4,
      image: user5,
    },
    {
      id: 5,
      name: "Kiran",
      comment:
        "Very professional. The vehicle was ready on time, clean, and well-maintained. Great value for the price.",
      stars: 5,
      image: user4,
    },
    {
      id: 6,
      name: "Shravan",
      comment:
        "Had a great experience. The booking process was simple, and the car performed well. Definitely recommend it!",
      stars: 4,
      image: user6,
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const goToNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 3) % reviews.length);
  };

  useEffect(() => {
    const interval = setInterval(goToNext, 5000);
    return () => clearInterval(interval);
  }, []);

  const currentReviews = [
    reviews[(currentIndex + 0) % reviews.length],
    reviews[(currentIndex + 1) % reviews.length],
    reviews[(currentIndex + 2) % reviews.length],
  ];

  return (
    <div className="py-16 px-8 bg-gray-100">
      <h2 className="text-3xl font-bold text-center mb-12">
        What Our Users Say
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-8">
        {currentReviews.map((review) => (
          <div
            key={review.id}
            className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300"
          >
            <img
              src={review.image}
              alt={review.name}
              className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
            />
            <h3 className="text-xl font-semibold text-center">{review.name}</h3>
            <p className="text-gray-700 mt-4 text-sm text-center">
              {review.comment}
            </p>
            <div className="text-center mt-4">
              <span className="text-yellow-500">
                {"⭐".repeat(review.stars)}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Reviews;
