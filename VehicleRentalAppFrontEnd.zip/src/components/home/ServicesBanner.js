import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCar,
  faCalendarCheck,
  faSyncAlt,
  faShieldAlt,
  faThumbsUp,
} from "@fortawesome/free-solid-svg-icons";

const ServicesBanner = () => {
  return (
    <section id="services" className="text-center py-16">
      <h2 className="text-4xl text-orange-600 font-semibold mb-10">
        Our Services
      </h2>
      <div className="flex flex-wrap justify-center gap-8">
        <div className="bg-white p-6 rounded-lg shadow-lg w-full sm:w-60 md:w-60 lg:w-60 xl:w-60">
          <div className="text-4xl text-orange-500 mb-4">
            <FontAwesomeIcon icon={faCalendarCheck} />
          </div>
          <h3 className="text-2xl font-medium text-gray-800 mb-3">
            Easy Booking
          </h3>
          <p className="text-gray-600">
            Book your vehicle quickly and easily through our user-friendly
            platform.
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg w-full sm:w-60 md:w-60 lg:w-60 xl:w-60">
          <div className="text-4xl text-orange-500 mb-4">
            <FontAwesomeIcon icon={faCar} />
          </div>
          <h3 className="text-2xl font-medium text-gray-800 mb-3">
            Driver Service
          </h3>
          <p className="text-gray-600">
            Get a professional driver to take you where you need to go with
            comfort.
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg w-full sm:w-60 md:w-60 lg:w-60 xl:w-60">
          <div className="text-4xl text-orange-500 mb-4">
            <FontAwesomeIcon icon={faSyncAlt} />
          </div>
          <h3 className="text-2xl font-medium text-gray-800 mb-3">
            Flexibility
          </h3>
          <p className="text-gray-600">
            Enjoy flexible rental options and durations that suit your needs.
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-lg w-full sm:w-60 md:w-60 lg:w-60 xl:w-60">
          <div className="text-4xl text-orange-500 mb-4">
            <FontAwesomeIcon icon={faShieldAlt} />
          </div>
          <h3 className="text-2xl font-medium text-gray-800 mb-3">Security</h3>
          <p className="text-gray-600">
            Our vehicles are equipped with security features to ensure your
            safety.
          </p>
        </div>
      </div>
    </section>
  );
};

export default ServicesBanner;
