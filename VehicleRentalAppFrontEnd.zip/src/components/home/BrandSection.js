import React, { useState, useEffect } from "react";
import toyota from "../../assets/images/brands/toyotaLogo.png";
import hyundai from "../../assets/images/brands/hyundaiLogo.png";
import suzuki from "../../assets/images/brands/suzukiLogo.png";
import audi from "../../assets/images/brands/audiLogo.png";
import mahindra from "../../assets/images/brands/mahindraLogo.png";
import mercedes from "../../assets/images/brands/mercedesLogo.png";
import mitsubishi from "../../assets/images/brands/mitsubishiLogo.png";
import nissan from "../../assets/images/brands/nissanLogo.png";
import skoda from "../../assets/images/brands/skodaLogo.png";
import renault from "../../assets/images/brands/renaultLogo.png";
import tata from "../../assets/images/brands/tataLogo.png";
import honda from "../../assets/images/brands/hondaLogo.png";
import bmw from "../../assets/images/brands/bmwLogo.png";
import lexus from "../../assets/images/brands/lexusLogo.png";
import chevrolet from "../../assets/images/brands/chevroletLogo.png";
import jaguar from "../../assets/images/brands/jaguarLogo.png";
import volkswagen from "../../assets/images/brands/volkswagenLogo.png";
import mg from "../../assets/images/brands/mgLogo.png";

const BrandSection = () => {
  const [currentPage, setCurrentPage] = useState(0);
  const brands = [
    { name: "Audi", logo: audi },
    { name: "Mitsubishi", logo: mitsubishi },
    { name: "BMW", logo: bmw },
    { name: "Chevrolet", logo: chevrolet },
    { name: "Skoda", logo: skoda },
    { name: "Jaguar", logo: jaguar },
    { name: "Mercedes", logo: mercedes },
    { name: "Honda", logo: honda },
    { name: "Toyota", logo: toyota },
    { name: "Lexus", logo: lexus },
    { name: "Morris Garages", logo: mg },
    { name: "Renault", logo: renault },
    { name: "Suzuki", logo: suzuki },
    { name: "Mahindra", logo: mahindra },
    { name: "Tata", logo: tata },
    { name: "Hyundai", logo: hyundai },
    { name: "Nissan", logo: nissan },
    { name: "Volkswagen", logo: volkswagen },
  ];
  const brandsPerPage = 6;

  const paginateBrands = () => {
    const startIndex = currentPage * brandsPerPage;
    return brands.slice(startIndex, startIndex + brandsPerPage);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentPage(
        (prevPage) => (prevPage + 1) % Math.ceil(brands.length / brandsPerPage)
      );
    }, 5000);

    return () => clearInterval(interval);
  }, [brands.length, brandsPerPage]);

  return (
    <section id="brands" className="py-16">
      <h2 className="text-4xl font-semibold text-center ml-10 text-orange-600 mb-16">
        Most Popular Vehicle Brands We Offer
      </h2>
      <div className="flex overflow-hidden justify-center">
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-16">
          {paginateBrands().map((brand, index) => (
            <div key={index} className="flex flex-col items-center">
              <img
                src={brand.logo}
                alt={brand.name}
                className="h-24 object-contain"
              />
              <p className="mt-2 text-center text-lg font-medium text-gray-700">
                {brand.name}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BrandSection;
