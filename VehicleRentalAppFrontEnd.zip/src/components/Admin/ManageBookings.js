import React, { useEffect, useState } from "react";
import {
  getAllBookings,
  getUserById,
  getVehicleById,
  getDriverById,
} from "../../api/auth";
import Modal from "../../components/Modal";
import Cookies from "js-cookie";
import { FaCar, FaUser, FaTaxi } from "react-icons/fa";

const ManageBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [selectedDriver, setSelectedDriver] = useState(null); 
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [isVehicleModalOpen, setIsVehicleModalOpen] = useState(false);
  const [isDriverModalOpen, setIsDriverModalOpen] = useState(false); 

  const token = Cookies.get("user");

  useEffect(() => {
    if (token) {
      fetchBookings();
    }
  }, [token]);

  const fetchBookings = async () => {
    try {
      const response = await getAllBookings(token);
      setBookings(response);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      setBookings([]);
    }
  };

  const handleCustomerClick = async (customerId) => {
    try {
      const response = await getUserById(customerId, token);
      setSelectedCustomer(response);
      setIsCustomerModalOpen(true);
    } catch (error) {
      console.error("Error fetching customer details:", error);
    }
  };

  const handleDriverClick = async (driverId) => {
    if (driverId) {
      try {
        const response = await getDriverById(driverId, token);
        setSelectedDriver(response);
        setIsDriverModalOpen(true);
      } catch (error) {
        console.error("Error fetching driver details:", error);
      }
    } else {
      setSelectedDriver(null);
      setIsDriverModalOpen(true);
    }
  };

  const handleVehicleClick = async (vehicleId) => {
    try {
      const response = await getVehicleById(vehicleId, token);
      setSelectedVehicle(response);
      console.log(selectedVehicle);

      setIsVehicleModalOpen(true);
    } catch (error) {
      console.error("Error fetching vehicle details:", error);
    }
  };

  return (
    <div className="sm:p-6">
      <h2 className="text-xl sm:text-2xl font-bold mb-6">
        Manage Bookings
      </h2>

      {bookings.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="w-full border border-gray-300 rounded-lg shadow-md">
            <thead className="bg-gray-200">
              <tr className="text-center text-sm sm:text-base">
                <th className="p-3 border">Booking ID</th>
                <th className="p-3 border">Location</th>
                <th className="p-3 border">From Date</th>
                <th className="p-3 border">To Date</th>
                <th className="p-3 border">Aadhar Number</th>
                <th className="p-3 border">Total Cost</th>
                <th className="p-3 border">Customer</th>
                <th className="p-3 border">Vehicle</th>
                <th className="p-3 border">Driver</th>
                <th className="p-3 border">Status</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking, index) => (
                <tr
                  key={index}
                  className="border-t text-sm sm:text-base text-center"
                >
                  <td className="p-3 border">{booking?.bookingId || "N/A"}</td>
                  <td className="p-3 border">{booking?.location || "N/A"}</td>
                  <td className="p-3 border">{booking?.fromDate || "N/A"}</td>
                  <td className="p-3 border">{booking?.toDate || "N/A"}</td>
                  <td className="p-3 border">
                    {booking?.customerAadharNumber || "N/A"}
                  </td>
                  <td className="p-3 border font-semibold text-green-600">
                    ₹{booking?.totalCost || "N/A"}
                  </td>
                  <td
                    className="p-3 pl-10 border text-orange-500 cursor-pointer"
                    onClick={() => handleCustomerClick(booking?.customerId)}
                  >
                    <FaUser />
                  </td>
                  <td
                    className="p-3 pl-8 border text-orange-500 cursor-pointer text-center"
                    onClick={() => handleVehicleClick(booking?.vehicleId)}
                  >
                    <FaCar />
                  </td>
                  <td
                    className="p-3 pl-8 border text-orange-500 cursor-pointer text-center"
                    onClick={() => handleDriverClick(booking?.driverId)} // Driver column click
                  >
                    <FaTaxi />
                  </td>
                  <td
                    className={`p-3 border font-semibold ${
                      booking?.status === "PENDING"
                        ? "text-yellow-500"
                        : booking?.status === "CANCELLED"
                        ? "text-red-500"
                        : "text-green-500"
                    }`}
                  >
                    {booking?.status || "N/A"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="text-gray-500 text-center">No bookings found.</p>
      )}

      {/* Customer Modal */}
      {isCustomerModalOpen && selectedCustomer && (
        <Modal
          title="Customer Details"
          onClose={() => setIsCustomerModalOpen(false)}
        >
          <p>
            <strong>Email:</strong> {selectedCustomer.email}
          </p>
          <p>
            <strong>Name:</strong> {selectedCustomer.name}
          </p>
          <p>
            <strong>Gender:</strong> {selectedCustomer.gender}
          </p>
          <p>
            <strong>Date Of Birth:</strong> {selectedCustomer.dateOfBirth}
          </p>
          <p>
            <strong>Phone Number:</strong> {selectedCustomer.contactNumber}
          </p>
          <p>
            <strong>Address:</strong> {selectedCustomer.address}
          </p>
        </Modal>
      )}

      {/* Driver Modal */}
      {isDriverModalOpen && (
        <Modal
          title="Driver Details"
          onClose={() => setIsDriverModalOpen(false)}
        >
          {selectedDriver ? (
            <>
              <p>
                <strong>Name:</strong> {selectedDriver.name}
              </p>
              <p>
                <strong>License Number:</strong> {selectedDriver.licenseNumber}
              </p>
              <p>
                <strong>Contact:</strong> {selectedDriver.contactNumber}/day
              </p>
              <p>
                <strong>Email:</strong> {selectedDriver.email}/day
              </p>
              <p>
                <strong>Price:</strong> {selectedDriver.driverCostPerDay}/day
              </p>
            </>
          ) : (
            <p>Driver is not opted for this booking.</p>
          )}
        </Modal>
      )}

      {/* Vehicle Modal */}
      {isVehicleModalOpen && selectedVehicle && (
        <Modal
          title="Vehicle Details"
          onClose={() => setIsVehicleModalOpen(false)}
        >
          <img
            src={selectedVehicle.vehicleImageURL}
            alt="selectedVehicle.modelName"
          />
          <p>
            <strong>Modal Name:</strong> {selectedVehicle.modelName} (
            {selectedVehicle.categoryType})
          </p>
          <p>
            <strong>Cost:</strong> {selectedVehicle.pricePerDay}/day
          </p>
          <p>
            <strong>Mileage:</strong> {selectedVehicle.mileage}/litres
          </p>
          <p>
            <strong>Fuel Type:</strong> {selectedVehicle.fuelType}
          </p>
          <p>
            <strong>Insurance Number:</strong> {selectedVehicle.insuranceNumber}
          </p>
          <p>
            <strong>Registration Number:</strong>{" "}
            {selectedVehicle.registrationNumber}
          </p>
          <p>
            <strong>Features:</strong> {selectedVehicle.featureDescription}
          </p>
        </Modal>
      )}
    </div>
  );
};

export default ManageBookings;
