import React, { useEffect, useState } from "react";
import { getAllReviews, deleteReview } from "../../api/auth";
import { getUserById, getVehicleById } from "../../api/auth";
import Modal from "../../components/Modal";
import Cookies from "js-cookie";
import { FaCar, FaUser, FaEdit, FaTrash } from "react-icons/fa";
import { toast } from "react-toastify";

const ManageReviews = () => {
  const [reviews, setReviews] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [isVehicleModalOpen, setIsVehicleModalOpen] = useState(false);
  const [editReview, setEditReview] = useState({
    customerId: "",
    vehicleId: "",
    rating: "",
    comment: "",
  });

  const token = Cookies.get("user");

  useEffect(() => {
    if (token) {
      fetchReviews();
    }
  }, [token]);

  const fetchReviews = async () => {
    try {
      const response = await getAllReviews(token);
      setReviews(response);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      setReviews([]);
    }
  };

  const handleCustomerClick = async (customerId) => {
    try {
      const response = await getUserById(customerId, token);
      setSelectedCustomer(response);
      setIsCustomerModalOpen(true);
    } catch (error) {
      console.error("Error fetching customer details:", error);
    }
  };

  const handleVehicleClick = async (vehicleId) => {
    try {
      const response = await getVehicleById(vehicleId, token);
      setSelectedVehicle(response);
      setIsVehicleModalOpen(true);
    } catch (error) {
      console.error("Error fetching vehicle details:", error);
    }
  };

  const handleDeleteReview = async (customerId, vehicleId) => {
    try {
      await deleteReview(customerId, vehicleId, token);
      setReviews(
        reviews.filter(
          (review) =>
            review.customerId !== customerId || review.vehicleId !== vehicleId
        )
      );
      toast.success("Review deleted successfully");
    } catch (error) {
      console.error("Error deleting review:", error);
    }
  };

  return (
    <div className="p-4 sm:p-6">
      <h2 className="text-xl sm:text-2xl font-bold mb-4">Manage Reviews</h2>

      {reviews.length > 0 ? (
        <div className="overflow-x-auto max-h-[74vh] overflow-y-auto">
          <table className="w-full border border-gray-300 rounded-lg shadow-md">
            <thead className="bg-gray-200">
              <tr className="text-center text-sm sm:text-base">
                <th className="p-3 border">Rating</th>
                <th className="p-3 border pl-10">Comment</th>
                <th className="p-3 border">Customer</th>
                <th className="p-3 border">Vehicle</th>
                <th className="p-3 border">Delete</th>
              </tr>
            </thead>
            <tbody>
              {reviews.map((review, index) => (
                <tr
                  key={index}
                  className="border-t text-sm sm:text-base text-center"
                >
                  <td className="p-3 border">{review.rating}</td>
                  <td className="p-3 border">{review.comment}</td>
                  <td
                    className="p-3 pl-10 border text-orange-500 cursor-pointer"
                    onClick={() => handleCustomerClick(review.customerId)}
                  >
                    <FaUser />
                  </td>
                  <td
                    className="p-3 pl-8 border text-orange-500 cursor-pointer text-center"
                    onClick={() => handleVehicleClick(review.vehicleId)}
                  >
                    <FaCar />
                  </td>
                  <td className="p-3 border space-x-3">
                    <button
                      onClick={() =>
                        handleDeleteReview(review.customerId, review.vehicleId)
                      }
                      className="text-red-500"
                    >
                      <FaTrash />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="text-gray-500 text-center">No reviews found.</p>
      )}

      {/* Customer Modal */}
      {isCustomerModalOpen && selectedCustomer && (
        <Modal
          title="Customer Details"
          onClose={() => setIsCustomerModalOpen(false)}
        >
          <p>
            <strong>Email:</strong> {selectedCustomer.email}
          </p>
          <p>
            <strong>Name:</strong> {selectedCustomer.name}
          </p>
          <p>
            <strong>Gender:</strong> {selectedCustomer.gender}
          </p>
          <p>
            <strong>Date Of Birth:</strong> {selectedCustomer.dateOfBirth}
          </p>
          <p>
            <strong>Phone Number:</strong> {selectedCustomer.contactNumber}
          </p>
          <p>
            <strong>Address:</strong> {selectedCustomer.address}
          </p>
        </Modal>
      )}

      {/* Vehicle Modal */}
      {isVehicleModalOpen && selectedVehicle && (
        <Modal
          title="Vehicle Details"
          onClose={() => setIsVehicleModalOpen(false)}
        >
          <img
            src={selectedVehicle.vehicleImageURL}
            alt={selectedVehicle.modelName}
          />
          <p>
            <strong>Model Name:</strong> {selectedVehicle.modelName} (
            {selectedVehicle.categoryType})
          </p>
          <p>
            <strong>Cost:</strong> ₹{selectedVehicle.pricePerDay}/day
          </p>
          <p>
            <strong>Mileage:</strong> {selectedVehicle.mileage}/litres
          </p>
          <p>
            <strong>Fuel Type:</strong> {selectedVehicle.fuelType}
          </p>
          <p>
            <strong>Insurance Number:</strong> {selectedVehicle.insuranceNumber}
          </p>
          <p>
            <strong>Registration Number:</strong>{" "}
            {selectedVehicle.registrationNumber}
          </p>
          <p>
            <strong>Features:</strong> {selectedVehicle.featureDescription}
          </p>
        </Modal>
      )}
    </div>
  );
};

export default ManageReviews;
