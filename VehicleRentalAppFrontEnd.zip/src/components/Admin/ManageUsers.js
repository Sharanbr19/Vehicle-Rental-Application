import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { getAllUsers, deleteUser } from "../../api/auth";
import EditUser from "./EditUser";
import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import { FaEdit, FaTrash } from "react-icons/fa";

const ManageUsers = () => {
  const [users, setUsers] = useState([]);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const navigate = useNavigate();
  const token = Cookies.get("user");

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const data = await getAllUsers(token);
        setUsers(data);
      } catch (error) {
        console.error("Error fetching users:", error.message);
        toast.error("Failed to fetch users.");
      }
    };
    fetchUsers();
  }, [token]);

  const handleDeleteUser = async (userId) => {
    try {
      await deleteUser(userId, token);
      toast.success("User deleted successfully.");
      setUsers((prevUsers) =>
        prevUsers.filter((user) => user.userId !== userId)
      );
    } catch (error) {
      console.error("Error deleting user:", error.message);
      toast.error("Failed to delete user.");
    }
  };

  const handleEditUser = (user) => {
    setSelectedUser(user);
    setShowEditModal(true);
  };

  return (
    <div className="container mx-auto p-4">
      <h2 className="text-2xl font-bold mb-4">Manage Users</h2>

      <button
        onClick={() => navigate("/registration")}
        className="bg-blue-500 text-white py-2 px-4 rounded mb-4"
      >
        Add User
      </button>
      <div className="overflow-x-auto max-h-[68vh] overflow-y-auto">
        <table className="min-w-full table-auto border-collapse">
          <thead>
            <tr className="bg-gray-200">
              <th className="px-4 py-2 text-left">Name</th>
              <th className="px-4 py-2 text-left">Email</th>
              <th className="px-4 py-2 text-left">Contact Number</th>
              <th className="px-4 py-2 text-left">Gender</th>
              <th className="px-4 py-2 text-left">Date Of Birth</th>
              <th className="px-4 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.userId} className="border-b">
                <td className="px-4 py-2">{user.name}</td>
                <td className="px-4 py-2">{user.email}</td>
                <td className="px-4 py-2">{user.contactNumber}</td>
                <td className="px-4 py-2">{user.gender}</td>
                <td className="px-4 py-2">{user.dateOfBirth}</td>
                <td className="px-4 py-2 flex gap-2">
                  <button
                    onClick={() => handleEditUser(user)}
                    className="bg-yellow-500 text-white py-1 px-2 rounded flex items-center gap-2 hover:bg-yellow-600"
                  >
                    <FaEdit />
                    Edit 
                  </button>

                  <button
                    onClick={() => handleDeleteUser(user.userId)}
                    className="bg-red-500 text-white py-1 px-2 rounded flex items-center gap-2 hover:bg-red-600"
                  >
                    <FaTrash />
                    Ban
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <EditUser
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
        user={selectedUser}
        setUsers={setUsers}
      />
    </div>
  );
};

export default ManageUsers;
