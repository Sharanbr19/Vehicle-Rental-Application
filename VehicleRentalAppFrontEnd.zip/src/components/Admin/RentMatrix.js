import React, { useEffect, useState } from "react";
import { Bar, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js";
import {
  getTotalBookings,
  getTotalCustomers,
  getTotalDrivers,
  getTotalVehicles,
  getTotalEarnings,
  getEarningsByCategoryType,
  getBookingCountByCategoryType,
} from "../../api/auth.js"; 
import Cookies from "js-cookie";
import { Users, Car, User, CalendarCheck, IndianRupeeIcon } from "lucide-react"; 

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

const AdminMatrix = () => {
  const [totalBookings, setTotalBookings] = useState(0);
  const [totalCustomers, setTotalCustomers] = useState(0);
  const [totalDrivers, setTotalDrivers] = useState(0);
  const [totalVehicles, setTotalVehicles] = useState(0);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [earningsByCategory, setEarningsByCategory] = useState([]);
  const [bookingCountByCategory, setBookingCountByCategory] = useState([]);
  const [loading, setLoading] = useState(true); 

  useEffect(() => {
    const token = Cookies.get("user");

    const fetchData = async () => {
      try {
        const bookings = await getTotalBookings(token);
        const customers = await getTotalCustomers(token);
        const drivers = await getTotalDrivers(token);
        const vehicles = await getTotalVehicles(token);
        const earnings = await getTotalEarnings(token);
        const earningsCategory = await getEarningsByCategoryType(token);
        const bookingCategory = await getBookingCountByCategoryType(token);

        setTotalBookings(bookings);
        setTotalCustomers(customers);
        setTotalDrivers(drivers);
        setTotalVehicles(vehicles);
        setTotalEarnings(earnings);
        setEarningsByCategory(earningsCategory || []);
        setBookingCountByCategory(bookingCategory || []);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false); 
      }
    };

    fetchData();
  }, []);

  const earningsBarData = earningsByCategory.length
    ? {
        labels: earningsByCategory?.map((item) => item[0]) || [],
        datasets: [
          {
            label: "Earnings",
            data: earningsByCategory?.map((item) => item[1]) || [],
            backgroundColor: "#BAB8F3",
          },
        ],
      }
    : null;

  const bookingPieData = bookingCountByCategory.length
    ? {
        labels: bookingCountByCategory?.map((item) => item[0]) || [],
        datasets: [
          {
            data: bookingCountByCategory?.map((item) => item[1]) || [],
            backgroundColor: [
              "#6DBFD1",
              "#5C7EAB",
              "#FF7D63",
              "#FFAC63",
              "#BAB8F3",
              "#F6F9A7",
              '#5CAC68'
            ],
          },
        ],
      }
    : null;

  if (loading) {
    return <div className="text-center">Loading data...</div>; 
  }

  return (
    <div className="container mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6">Revenue Matrix</h2>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
        {[
          {
            title: "Total Customers",
            count: totalCustomers,
            icon: <Users className="w-12 h-12 text-blue-600" />,
          },
          {
            title: "Total Vehicles",
            count: totalVehicles,
            icon: <Car className="w-12 h-12 text-blue-600" />,
          },
          {
            title: "Total Drivers",
            count: totalDrivers,
            icon: <User className="w-12 h-12 text-blue-600" />,
          },
          {
            title: "Total Bookings",
            count: `${totalBookings}`,
            icon: <CalendarCheck className="w-12 h-12 text-blue-600" />,
          },
          {
            title: "Total Earnings",
            count: `Rs ${totalEarnings}`,
            icon: <IndianRupeeIcon className="w-12 h-12 text-blue-600" />,
          },
        ].map((item, index) => (
          <div
            key={index}
            className="bg-cyan-100 shadow-lg p-6 rounded-lg flex flex-col items-center"
          >
            <div>{item.icon}</div>
            <h3 className="text-lg font-semibold mt-2">{item.title}</h3>
            <p className="text-xl font-bold mt-3">{item.count}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
       
        {/* Earnings by Category Bar Chart */}
        <div className="bg-white shadow-lg p-6 rounded-lg">
          <h3 className="text-lg font-semibold mb-4">Earnings by Category</h3>
          {earningsBarData ? (
            <Bar data={earningsBarData} options={{ responsive: true }} />
          ) : (
            <p className="text-center text-gray-500">
              No earnings data available.
            </p>
          )}
        </div>

        {/* Booking Count by Category Pie Chart */}
        <div className="bg-white shadow-lg p-6 rounded-lg">
          <h3 className="text-lg font-semibold mb-4">
            Booking Count by Category
          </h3>
          {bookingPieData ? (
            <Pie data={bookingPieData} options={{ responsive: true }} />
          ) : (
            <p className="text-center text-gray-500">
              No booking data available.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminMatrix;
