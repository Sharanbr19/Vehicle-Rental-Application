import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { getAllDrivers, deleteDriver } from "../../api/auth.js";
import EditDriver from "../driver/EditDriver";
import AddDriver from "../driver/AddDriver";
import Cookies from "js-cookie";
import { FaTrash, FaEdit } from "react-icons/fa";

const ManageDrivers = () => {
  const [drivers, setDrivers] = useState([]);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState();
  const token = Cookies.get("user");

  useEffect(() => {
    const fetchDrivers = async () => {
      try {
        const data = await getAllDrivers(token);
        setDrivers(data);
      } catch (error) {
        console.error("Error fetching drivers:", error.message);
        toast.error("Failed to fetch drivers.");
      }
    };
    fetchDrivers();
  }, [token]);

  const handleDeleteDriver = async (driverId) => {
    try {
      await deleteDriver(driverId, token);
      toast.success("Driver deleted successfully.");
      setDrivers((prevDrivers) =>
        prevDrivers.filter((driver) => driver.driverId !== driverId)
      );
    } catch (error) {
      console.error("Error deleting driver:", error.message);
      toast.error("Failed to delete driver beacause booking exists for the driver.");
    }
  };

  const handleEditDriver = (driver) => {
    setSelectedDriver(driver);
    setShowEditModal(true);
  };

  return (
    <div className="container mx-auto p-4">
      <h2 className="text-xl sm:text-2xl font-bold mb-4">Manage Drivers</h2>

      <button
        onClick={() => setShowAddModal(true)}
        className="bg-blue-500 text-white py-2 px-4 rounded mb-4"
      >
        Add Driver
      </button>
      <div className="max-h-[80vh] overflow-y-auto">
        <table className="min-w-full table-auto border-collapse">
          <thead>
            <tr className="bg-gray-200 text-center">
              <th className="px-4 py-2">Name</th>
              <th className="px-4 py-2">License Number</th>
              <th className="px-4 py-2">Email</th>
              <th className="px-4 py-2">Contact Number</th>
              <th className="px-4 py-2">Cost Per Day</th>
              <th className="px-4 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {drivers.map((driver) => (
              <tr key={driver.driverId} className="border-b text-center">
                <td className="px-4 py-2">{driver.name}</td>
                <td className="px-4 py-2">{driver.licenseNumber}</td>
                <td className="px-4 py-2">{driver.email}</td>
                <td className="px-4 py-2">{driver.contactNumber}</td>
                <td className="px-4 py-2">Rs {driver.driverCostPerDay}</td>
                <td className="px-4 py-2 flex gap-2">
                  <button
                    onClick={() => handleEditDriver(driver)}
                    className="bg-yellow-500 text-white py-1 px-3 rounded flex items-center gap-2 hover:bg-yellow-600"
                  >
                    <FaEdit />
                    Edit
                  </button>

                  <button
                    onClick={() => handleDeleteDriver(driver.driverId)}
                    className="bg-red-500 text-white py-1 px-3 rounded flex items-center gap-2 hover:bg-red-600"
                  >
                    <FaTrash />
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Edit Driver Modal */}
      {showEditModal && (
        <EditDriver
          isOpen={showEditModal}
          onClose={() => setShowEditModal(false)}
          driver={selectedDriver}
          setDrivers={setDrivers}
        />
      )}

      {/* Add Driver Modal */}
      {showAddModal && (
        <AddDriver
          isOpen={showAddModal}
          onClose={() => setShowAddModal(false)}
          setDrivers={setDrivers}
        />
      )}
    </div>
  );
};

export default ManageDrivers;
