import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { updateUser } from "../../api//auth";
import Cookies from "js-cookie";

const EditUser = ({ isOpen, onClose, user, setUsers }) => {
  const [userData, setUserData] = useState({
    name: "",
    contactNumber: "",
    gender: "",
    dateOfBirth: "",
    address: "",
    userType: "",
    password: "",
    email: "",
  });
  const [formErrors, setFormErrors] = useState({});

  useEffect(() => {
    if (user) {
      setUserData({
        name: user.name || "",
        contactNumber: user.contactNumber || "",
        gender: user.gender || "",
        dateOfBirth: user.dateOfBirth || "",
        address: user.address || "",
        userType: user.userType || "",
        password: user.password || "",
        email: user.email || "",
      });
      setFormErrors({})
    }
  }, [isOpen,user]);

  const validate = () => {
    const errors = {};

    const namePattern = /^[A-Za-z]+$/;
    if (!userData.name) errors.name = "Name is required.";
    if(userData.name.length < 3 || userData.name.length > 50){
      errors.name = "Name should be between 3 to 50 characters";
    }else if(!namePattern.test(userData.name)) {
      errors.name = "Name should contain only alphabets";
    }

    const phonePattern = /^[0-9]{10}$/;
    if (!userData.contactNumber) {
      errors.contactNumber = "Contact Number is required.";
    } else if (!phonePattern.test(userData.contactNumber)) {
      errors.contactNumber = "Contact Number must be 10 digits.";
    }

    if (!userData.gender) errors.gender = "Gender is required.";

    if (!userData.dateOfBirth) {
      errors.dateOfBirth = "Date of Birth is required.";
    } else {
      const today = new Date();
      const birthDate = new Date(userData.dateOfBirth);
      let age = today.getFullYear() - birthDate.getFullYear();
      const monthDifference = today.getMonth() - birthDate.getMonth();

      if (
        monthDifference < 0 ||
        (monthDifference === 0 && today.getDate() < birthDate.getDate())
      ) {
        age--;
      }
      if (age < 18) {
        errors.dateOfBirth = "You must be at least 18 years old.";
      }
      else if (age > 100) {
        errors.dateOfBirth = "Age must not exceed 100 years";
      }
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleUpdate = async () => {
    console.log(user.password);
    if (!validate()) return;
    console.log(userData);
    try {
      await updateUser(user.userId, userData, Cookies.get("user"));
      setUsers((prevUsers) =>
        prevUsers.map((u) =>
          u.userId === user.userId ? { ...u, ...userData } : u
        )
      );
      toast.success("User updated successfully.");
      onClose();
    } catch (error) {
      console.error("Error updating user:", error.message);
      toast.error("Failed to update user.");
    }
  };

  if (!isOpen || !user) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-75 z-50">
      <div className="bg-white p-6 rounded-lg w-full max-w-lg relative">
        <button
          className="absolute top-2 right-4 text-4xl text-red-500 hover:text-red-700"
          onClick={onClose}
        >
          &times;
        </button>
        <h2 className="text-xl text-center text-orange-500 font-semibold mb-4">
          Edit User
        </h2>
        <form>
          <div className="mb-4">
            <input
              type="email"
              name="email"
              value={user.email}
              readOnly
              className="w-full p-2 rounded bg-gray-50"
            />
          </div>
          <div className="mb-4">
            <input
              type="text"
              name="name"
              value={userData.name}
              onChange={(e) =>
                setUserData({ ...userData, name: e.target.value })
              }
              placeholder="Name"
              className="w-full p-2 border border-gray-300 rounded"
            />
            {formErrors.name && (
              <p className="text-red-500">{formErrors.name}</p>
            )}
          </div>
          <div className="mb-4">
            <input
              type="text"
              name="contactNumber"
              value={userData.contactNumber}
              onChange={(e) =>
                setUserData({ ...userData, contactNumber: e.target.value })
              }
              placeholder="Contact Number"
              className="w-full p-2 border border-gray-300 rounded"
            />
            {formErrors.contactNumber && (
              <p className="text-red-500">{formErrors.contactNumber}</p>
            )}
          </div>
          <div className="mb-4">
            <select
              name="gender"
              value={userData.gender}
              onChange={(e) =>
                setUserData({ ...userData, gender: e.target.value })
              }
              className="w-full p-2 border border-gray-300 rounded"
            >
              <option disabled="true" value="">
                Select Gender
              </option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
            {formErrors.gender && (
              <p className="text-red-500">{formErrors.gender}</p>
            )}
          </div>
          <div className="mb-4">
            <input
              type="date"
              name="dateOfBirth"
              value={userData.dateOfBirth}
              onChange={(e) =>
                setUserData({ ...userData, dateOfBirth: e.target.value })
              }
              className="w-full p-2 border border-gray-300 rounded"
            />
            {formErrors.dateOfBirth && (
              <p className="text-red-500">{formErrors.dateOfBirth}</p>
            )}
          </div>

          <div className="flex justify-center">
            <button
              type="button"
              onClick={handleUpdate}
              className="bg-orange-500 w-full text-white py-2 px-4 rounded"
            >
              Update
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditUser;
