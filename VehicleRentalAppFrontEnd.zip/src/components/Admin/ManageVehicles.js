import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { getAllVehicles, deleteVehicle, searchVehicles } from "../../api/auth";
import { useCookies } from "react-cookie";
import AddVehicle from "../Vehicle/AddVehicle";
import EditVehicle from "../Vehicle/EditVehicle";
import StarRating from "../StarRating";

const ManageVehicles = () => {
  const [vehicles, setVehicles] = useState([]);
  const [filteredVehicles, setFilteredVehicles] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [cookies] = useCookies(["user"]);
  const vehiclesPerPage = 3;

  const fetchVehicles = async () => {
    const token = cookies.user;

    if (!token) {
      toast.error("Authentication token not found. Please log in.");
      return;
    }

    try {
      const data = await getAllVehicles(token);
      setVehicles(data);
      setFilteredVehicles(data);
    } catch (error) {
      console.error("Error fetching vehicle data", error);
      toast.error("Failed to fetch vehicles.");
    }
  };

  const handleDelete = async (vehicleId) => {
    const token = cookies.user;
    if (!token) {
      toast.error("Please log in to delete a vehicle.");
      return;
    }

    try {
      if (!vehicleId) {
        throw new Error("Vehicle ID is undefined or invalid.");
      }
      await deleteVehicle(vehicleId, token);
      toast.success("Vehicle deleted successfully.");

      setVehicles((prevVehicles) =>
        prevVehicles.filter((vehicle) => vehicle.vehicleId !== vehicleId)
      );
      setFilteredVehicles((prevVehicles) =>
        prevVehicles.filter((vehicle) => vehicle.vehicleId !== vehicleId)
      );
    } catch (error) {
      console.error("Vehicle already booked", error);
      toast.error("Cannot delete because this vehicle is already booked");
    }
  };

  const handleEdit = (vehicle) => {
    setSelectedVehicle(vehicle);
    setShowEditModal(true);
  };

  const handleAddVehicle = (newVehicle) => {
    setVehicles((prevVehicles) => [...prevVehicles, newVehicle]);
    setFilteredVehicles((prevVehicles) => [...prevVehicles, newVehicle]);
    setShowAddModal(false);
  };

  const handleUpdateVehicle = (updatedVehicle) => {
    setVehicles((prevVehicles) =>
      prevVehicles.map((vehicle) =>
        vehicle.vehicleId === updatedVehicle.vehicleId
          ? updatedVehicle
          : vehicle
      )
    );
    setFilteredVehicles((prevVehicles) =>
      prevVehicles.map((vehicle) =>
        vehicle.vehicleId === updatedVehicle.vehicleId
          ? updatedVehicle
          : vehicle
      )
    );
    setShowEditModal(false);
  };

  const handleSearch = async (e) => {
    const keyword = e.target.value;
    setSearchQuery(keyword);
    const token = cookies.user;

    if (!keyword) {
      setFilteredVehicles(vehicles);
      return;
    }

    try {
      const data = await searchVehicles(keyword, token);
      setFilteredVehicles(data);
      setCurrentPage(1);
    } catch (error) {
      toast.error("Failed to search vehicles.");
    }
  };

  const totalPages = Math.ceil(filteredVehicles.length / vehiclesPerPage);

  const paginateVehicles = () => {
    const startIndex = (currentPage - 1) * vehiclesPerPage;
    return filteredVehicles.slice(startIndex, startIndex + vehiclesPerPage);
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };

  useEffect(() => {
    fetchVehicles();
  }, [showEditModal, showAddModal]);

  return (
    <div className="px-4 p-4">
      <h2 className="text-2xl font-bold mb-4">Manage Vehicles</h2>

      <div className="flex gap-32 mb-8">
        <button
          className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 transition"
          onClick={() => setShowAddModal(true)}
        >
          Add Vehicle
        </button>

        <input
          type="text"
          placeholder="Search vehicles..."
          value={searchQuery}
          onChange={handleSearch}
          className="w-1/2 border border-gray-300 rounded py-2 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Vehicle Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {paginateVehicles().map((vehicle) => (
          <div
            key={vehicle.vehicleId}
            className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow flex flex-col"
          >
            <img
              src={vehicle.vehicleImageURL}
              alt={vehicle.modelName}
              className="w-full h-48 object-cover mb-4 rounded"
            />
            <div className="bg-cyan-100 p-4">
              <h3 className="text-lg font-semibold mb-2">
                {vehicle.modelName} ({vehicle.categoryType})
              </h3>
              <div className="flex justify-between">
                <div>
                  <p className="text-gray-700 mb-1">
                    <strong>Fuel:</strong> {vehicle.fuelType}
                  </p>
                  <p className="text-gray-700 mb-1">
                    <strong>Year:</strong> {vehicle.modelYear}
                  </p>
                  <p className="text-gray-700 mb-1">
                    <strong>Mileage:</strong> {vehicle.mileage}/litres
                  </p>
                </div>
                <div>
                  <StarRating vehicleId={vehicle.vehicleId} />
                  <p className="mt-3 text-green-600 text-lg font-bold">
                    ₹{vehicle.pricePerDay}/day
                  </p>
                </div>
              </div>
              <p className="text-gray-700 mb-1">
                <strong>Features:</strong> {vehicle.featureDescription}
              </p>
              <div className="mt-4 flex space-x-4">
                <button
                  className="bg-yellow-500 w-full text-white py-2 px-4 rounded hover:bg-yellow-600"
                  onClick={() => handleEdit(vehicle)}
                >
                  Edit
                </button>
                <button
                  className="bg-red-500 w-full text-white py-2 px-4 rounded hover:bg-red-600"
                  onClick={() => handleDelete(vehicle.vehicleId)}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredVehicles.length === 0 && (
        <p className="text-center text-gray-500 text-2xl">No vehicles found matching search criteria.</p>
      )}

      <div className="flex justify-between items-center mt-6">
        <button
          className={`py-2 px-4 rounded ${
            currentPage === 1
              ? "bg-gray-300 text-gray-600 cursor-not-allowed"
              : "bg-blue-500 text-white hover:bg-blue-600"
          }`}
          onClick={handlePreviousPage}
          disabled={currentPage === 1}
        >
          Previous
        </button>
        <span className="text-gray-700">
          Page {currentPage} of {totalPages}
        </span>
        <button
          className={`py-2 px-4 rounded ${
            currentPage === totalPages
              ? "bg-gray-300 text-gray-600 cursor-not-allowed"
              : "bg-blue-500 text-white hover:bg-blue-600"
          }`}
          onClick={handleNextPage}
          disabled={currentPage === totalPages}
        >
          Next
        </button>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-75 overflow-y-auto z-50">
          <div className="bg-white p-6 rounded-lg w-full max-w-lg relative max-h-[80vh] overflow-y-auto">
            <button
              className="absolute top-2 right-4 text-4xl text-red-500 hover:text-red-700"
              onClick={() => setShowAddModal(false)}
            >
              &times;
            </button>
            <AddVehicle onAddVehicle={handleAddVehicle} />
          </div>
        </div>
      )}

      {showEditModal && selectedVehicle && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-75 overflow-y-auto z-50">
          <div className="bg-white p-6 rounded-lg w-full max-w-lg relative max-h-[80vh] overflow-y-auto">
            <button
              className="absolute top-2 right-4 text-4xl text-red-500 hover:text-red-700"
              onClick={() => setShowEditModal(false)}
            >
              &times;
            </button>
            <EditVehicle
              vehicle={selectedVehicle}
              onUpdateVehicle={handleUpdateVehicle}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default ManageVehicles;
