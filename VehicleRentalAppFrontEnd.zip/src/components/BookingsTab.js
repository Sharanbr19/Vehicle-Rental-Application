import { useState } from "react";

const BookingsTab = ({ filterBookings }) => {
  const [selectedTab, setSelectedTab] = useState("ALL BOOKINGS");
  const tabs = ["ALL BOOKINGS", "UPCOMING", "COMPLETED", "PENDING", "CANCELLED"];

  return (
    <div className="w-full">
      <div className="flex border-b border-gray-300">
        {tabs.map((tab) => (
          <button
            key={tab}
            className={`p-3 sm:px-6 text-sm sm:text-base font-medium focus:outline-none transition-all
              ${
                selectedTab === tab
                  ? "border-b-4 border-blue-500 text-blue-600"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            onClick={() => {
              setSelectedTab(tab);
              filterBookings(tab);
            }}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="p-4 bg-gray-100 rounded-md mt-4">
        <p className="text-gray-700 font-semibold">Showing: {selectedTab}</p>
      </div>
    </div>
  );
};

export default BookingsTab;
