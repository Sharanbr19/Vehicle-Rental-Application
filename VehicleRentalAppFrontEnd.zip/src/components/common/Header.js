import React from "react";
import { useNavigate } from "react-router-dom";
import { useCookies } from "react-cookie";
import logo from "../../assets/images/RentWheelLogo.png";

const Header = ({
  isAuthenticated,
  setIsAuthenticated,
  userRole,
  setUserRole,
}) => {
  const navigate = useNavigate();
  const [, , removeCookie] = useCookies(["user", "role"]);

  const handleLogoClick = () => {
    navigate("/");
  };

  const handleLogout = () => {
    removeCookie("user", { path: "/" });
    removeCookie("role", { path: "/" });
    removeCookie("email", { path: "/" }); 
    setIsAuthenticated(false);
    setUserRole(null);
    navigate("/");
  };
  
  const handleLogin = () => {
    navigate("/login");
  };

  const handleRegister = () => {
    navigate("/registration");
  };

  return (
    <header className="bg-black w-auto text-white p-4 flex justify-between items-center">
      <div
        className="flex items-center space-x-4 cursor-pointer"
        onClick={handleLogoClick}
        aria-label="Go to Home Page"
      >
        <img
          src={logo}
          alt="Rent Wheels Logo"
          className="h-12 sm:h-6 md:h-8 lg:h-10"
        />
        <div className="flex flex-col">
          <h1 className="text-lg sm:text-xs md:text-sm lg:text-base font-bold text-orange-500">
            Rent Wheels
          </h1>
          <p className="text-xs sm:text-xxs md:text-xs lg:text-sm text-yellow-400">
            Rent Vehicles with Ease
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        {isAuthenticated ? (
          <button
            onClick={handleLogout}
            className="bg-red-600 hover:bg-red-800 text-white py-2 px-4 rounded-lg text-sm sm:text-xs md:text-sm lg:text-base"
          >
            Logout
          </button>
        ) : (
          <>
            <button
              onClick={handleLogin}
              className="bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-lg text-sm sm:text-xs md:text-sm lg:text-base"
            >
              Login
            </button>
            <button
              onClick={handleRegister}
              className="bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-lg text-sm sm:text-xs md:text-sm lg:text-base"
            >
              Register
            </button>
          </>
        )}
      </div>
    </header>
  );
};

export default Header;
