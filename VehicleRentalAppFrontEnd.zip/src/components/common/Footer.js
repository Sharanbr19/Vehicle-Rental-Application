import React, { useState } from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faInstagram,
  faFacebook,
  faTwitter,
} from "@fortawesome/free-brands-svg-icons";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function Footer() {
  const [email, setEmail] = useState("");

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleSubscribe = () => {
    if (validateEmail(email)) {
      toast.success("Subscribed successfully!", {
        position: "top-center",
        autoClose: 3000,
      });
      setEmail("");
    } else {
      toast.error("Invalid email address!", {
        position: "top-center",
        autoClose: 3000,
      });
    }
  };

  return (
    <footer className="bg-secondary text-white pt-6">
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="flex justify-center">
          <div>
            <h3 className="text-lg font-semibold mb-4 text-center">
              Quick Links
            </h3>
            <ul className="space-y-2 text-center pt-5">
              <li>
                <Link to="/" className="hover:text-highlight">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/featured-vehicles" className="hover:text-highlight">
                  Vehicles
                </Link>
              </li>
              <li>
                <Link to="/policies" className="hover:text-highlight">
                  Policies
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-highlight">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-highlight">
                  About Us
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col items-center">
          <h3 className="text-lg font-semibold mb-4 text-center">Newsletter</h3>
          <p className="mb-6 text-center">
            Subscribe to our newsletter for daily updates.
          </p>
          <div className="w-full flex justify-center mb-6">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              className="w-1/2 md:w-1/2 l:w-3/4 p-2 rounded-l bg-gray-100 text-black outline-none"
            />
            <button
              onClick={handleSubscribe}
              className="px-4 py-2 bg-primary text-white rounded-r"
            >
              Subscribe
            </button>
          </div>
          <h3 className="text-lg font-semibold mb-4 text-center">Follow Us</h3>
          <div className="flex space-x-14">
            <a
              href="https://www.instagram.com/rent_wheels_?igsh=MW9tN3BuNHd3bmNrcw=="
              target="_blank"
              rel="noopener noreferrer"
              className="text-white hover:text-primary"
            >
              <FontAwesomeIcon icon={faInstagram} size="2x" />
            </a>
            <a
              href="https://www.facebook.com/share/1GnKXUoSnP/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white hover:text-primary"
            >
              <FontAwesomeIcon icon={faFacebook} size="2x" />
            </a>
            <a
              href="https://x.com/Rent_Wheels_?t=t3AISlcNFQ_CWsdtKboSbQ&s=08"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white hover:text-primary"
            >
              <FontAwesomeIcon icon={faTwitter} size="2x" />
            </a>
          </div>
        </div>
      </div>

      <div className="bg-gray-900 text-center py-4 mt-16">
        <p>&copy; 2025 Vehicle Rental. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;
