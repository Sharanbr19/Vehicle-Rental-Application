import { useState, useEffect } from "react";
import { FaStar, FaStarHalfAlt, FaRegStar } from "react-icons/fa";
import { getAverageRatingByVehicle } from "../api/auth";
import Cookies from "js-cookie";

const StarRating = ({ vehicleId }) => {
  const [rating, setRating] = useState(null);
  const token = Cookies.get("user");

  useEffect(() => {
    const fetchRating = async () => {
      try {
        if (vehicleId) {
          const avgRating = await getAverageRatingByVehicle(vehicleId, token);
          setRating(avgRating);
        }
      } catch (error) {
        console.error("Failed to fetch rating", error);
      }
    };
    fetchRating();
  }, [vehicleId]);

  const stars = [];
  if (rating !== null) {
    for (let i = 1; i <= 5; i++) {
      if (i <= rating) {
        stars.push(<FaStar key={i} className="text-yellow-400" />);
      } else if (i - 0.5 === rating) {
        stars.push(<FaStarHalfAlt key={i} className="text-yellow-400" />);
      } else {
        stars.push(<FaRegStar key={i} className="text-gray-300" />);
      }
    }
  }

  return <div className="flex">{stars}</div>;
};

export default StarRating;
