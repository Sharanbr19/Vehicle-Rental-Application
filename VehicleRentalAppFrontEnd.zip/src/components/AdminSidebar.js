import React, { useState } from "react";
import {
  FaCar,
  FaUser,
  FaClipboardList,
  FaUsers,
  FaMoneyBillWave,
  FaPen,
  FaBars, // Hamburger icon
} from "react-icons/fa"; 
import Cookies from 'js-cookie';

const AdminSidebar = ({ activeTab, setActiveTab }) => {
  const [isOpen, setIsOpen] = useState(true); 

  const navLinks = [
    {
      title: "Manage Vehicles",
      icon: <FaCar />,
    },
    {
      title: "Manage Bookings",
      icon: <FaClipboardList />,
    },
    {
      title: "Manage Users",
      icon: <FaUser />,
    },
    {
      title: "Manage Drivers",
      icon: <FaUsers />,
    },
    {
      title: "Manage Reviews",
      icon: <FaPen />,
    },
    {
      title: "View Matrices",
      icon: <FaMoneyBillWave />,
    },
  ];


  return (
    <div className="bg-primary min-h-[100vh]">
      <div
        className="w-20  cursor-pointer bg-orange-500 lg:hidden"
      >
      </div>

      <div
        className={`bg-primary min-h-[100vh] h-auto text-white p-2 absolute md:relative z-10 transition-transform transform ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0 w-16 md:w-16 lg:w-52`}
      >
      <h2 className="text-center font-bold text-lg hidden lg:block">Welcome Admin</h2>
      
      <p className="mb-8 hidden lg:block">{Cookies.get("email")}</p>
      
        {navLinks.map((section, index) => (
          <div key={index} className="mb-4">
            <ul>
              <li
                onClick={() => setActiveTab(section.title)}
                className="cursor-pointer flex items-center justify-center lg:justify-start p-2 space-x-2 rounded-md hover:bg-gray-700 group relative"
              >
                <span className="text-xl">{section.icon}</span>

                <span
                  className="hidden lg:inline-block ml-2"
                  style={{ color: "white" }}
                >
                  {section.title}
                </span>

              </li>
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminSidebar;
