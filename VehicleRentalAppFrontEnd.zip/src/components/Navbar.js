import React, { useState } from "react";
import { Link } from "react-router-dom";

function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="bg-primary text-white p-4">
      <div className="container mx-auto flex justify-end items-center">
        <button
          className={`sm:hidden block px-2 py-1 rounded-md text-white bg-orange border-2 border-white transition-all duration-300 ease-in-out ${
            isMenuOpen
              ? "bg-orange-500 text-white"
              : "hover:bg-orange-500 hover:text-white"
          }`}
          onClick={toggleMenu}
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M4 6h16M4 12h16M4 18h16"
            />
          </svg>
        </button>

        <div className="hidden sm:flex flex-grow items-center justify-center space-x-6">
          <ul className="flex space-x-6">
            <li>
              <Link
                to="/"
                className="px-3 py-2 rounded transition-colors duration-300 hover:bg-black hover:text-yellow-500"
              >
                Home
              </Link>
            </li>
            <li>
              <Link
                to="/featured-vehicles"
                className="px-3 py-2 rounded transition-colors duration-300 hover:bg-black hover:text-yellow-500"
              >
                Featured Vehicles
              </Link>
            </li>
            <li>
              <Link
                to="/contact"
                className="px-3 py-2 rounded transition-colors duration-300 hover:bg-black hover:text-yellow-500"
              >
                Contact
              </Link>
            </li>
            <li>
              <Link
                to="/about"
                className="px-3 py-2 rounded transition-colors duration-300 hover:bg-black hover:text-yellow-500"
              >
                About
              </Link>
            </li>
            <li>
              <Link
                to="/policies"
                className="px-3 py-2 rounded transition-colors duration-300 hover:bg-black hover:text-yellow-500"
              >
                Policies
              </Link>
            </li>
          </ul>
        </div>
      </div>

      <div
        className={`lg:hidden absolute right-0 w-60 rounded-lg p-4 bg-white text-black shadow-lg transition-all duration-300 ease-in-out ${
          isMenuOpen ? "block" : "hidden"
        }`}
        style={{ top: "80px" }}
      >
        <div className="flex justify-end">
          <button
            className="px-2 py-1 rounded-md text-orange-500 bg-white border-2 border-orange-500 transition-all duration-300 ease-in-out"
            onClick={toggleMenu}
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>
        <ul className="flex flex-col items-center space-y-4 py-4">
          <li>
            <Link
              to="/"
              className="px-3 py-2 rounded-md text-black transition-colors duration-300 hover:bg-black hover:text-yellow-500"
            >
              Home
            </Link>
          </li>
          <li>
            <Link
              to="/featured-vehicles"
              className="px-3 py-2 rounded-md text-black transition-colors duration-300 hover:bg-black hover:text-yellow-500"
            >
              Featured Vehicles
            </Link>
          </li>
          <li>
            <Link
              to="/contact"
              className="px-3 py-2 rounded-md text-black transition-colors duration-300 hover:bg-black hover:text-yellow-500"
            >
              Contact
            </Link>
          </li>
          <li>
            <Link
              to="/about"
              className="px-3 py-2 rounded-md text-black transition-colors duration-300 hover:bg-black hover:text-yellow-500"
            >
              About
            </Link>
          </li>
          <li>
            <Link
              to="/policies"
              className="px-3 py-2 rounded-md text-black transition-colors duration-300 hover:bg-black hover:text-yellow-500"
            >
              Policies
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  );
}

export default Navbar;
