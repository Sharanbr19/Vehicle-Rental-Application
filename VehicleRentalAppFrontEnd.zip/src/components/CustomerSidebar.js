import React, { useState } from "react";
import {
  FaCar,
  FaStar,
  FaHistory,
  FaHeart,
  FaBalanceScale,
  FaDownload,
  FaUser,
} from "react-icons/fa";
import Cookies from "js-cookie";

const CustomerSidebar = ({ activeTab, setActiveTab, handleProfileClick }) => {
  const [isOpen, setIsOpen] = useState(true); 

  const navLinks = [
    { name: "Book Vehicles", icon: <FaCar /> },
    { name: "My Bookings", icon: <FaHistory /> },
    { name: "Compare Vehicles", icon: <FaBalanceScale /> },
    { name: "My Reviews", icon: <FaStar /> },
    { name: "My Favorites", icon: <FaHeart /> },
  ];

  return (
    <div className="bg-primary min-h-[100vh] ">
      <div className="w-16 cursor-pointer bg-orange-500 lg:hidden"></div>

      {/* Sidebar */}
      <div
        className={`bg-primary min-h-[100vh] h-auto text-white p-4 absolute md:relative z-8 transition-transform transform ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0 w-16 md:w-16 lg:w-52`}
      >
        <div className="flex flex-col items-center mb-8">
          <div className="cursor-pointer" onClick={handleProfileClick}>
            <FaUser className="text-4xl mb-2 lg:text-6xl" />
          </div>
          <p className="text-sm hidden lg:block">{Cookies.get("email")}</p>
        </div>

        <nav>
          <ul>
            {navLinks.map((link, index) => (
              <li
                key={index}
                onClick={() => setActiveTab(link.name)}
                className="cursor-pointer flex items-center justify-center mb-4 lg:justify-start p-2 space-x-2 rounded-md hover:bg-gray-700 group relative"
              >
                <span className="text-xl">{link.icon}</span>
                <span className="hidden text-l lg:inline-block ml-2">
                  {link.name}
                </span>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  );
};

export default CustomerSidebar;
