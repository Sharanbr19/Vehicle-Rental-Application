import React, { useState } from "react";
import { toast } from "react-toastify";

function ForgotPasswordModal({ show, onClose, onSubmit }) {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async () => {
    if (!email) {
      toast.error("Please enter your email.");
      return;
    }
  
    setIsLoading(true);
    await onSubmit(email);
    setIsLoading(false);
  };
  

  return (
    <>
      {show && (
        <div
          className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-75 z-50"
          onClick={onClose}
        >
          <div
            className="bg-white p-6 rounded-lg w-full max-w-lg relative"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 className="text-2xl font-semibold mb-3">Forgot Password</h2>
            <p className="mb-5">OTP will be sent to the below mail address.</p>

            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-3 mt-5 mb-5 border border-gray-300 rounded-md"
              disabled={isLoading}
            />

            <button
              onClick={handleSubmit}
              className="w-full py-3 bg-primary text-white rounded-md hover:bg-orange-700"
              disabled={isLoading}
            >
              Send OTP
            </button>
          </div>
        </div>
      )}

      {isLoading && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-75 z-50">
          <div className="relative flex flex-col items-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-orange-500"></div>
            <p className="text-white text-lg mt-4">Processing...</p>
          </div>
        </div>
      )}
    </>
  );
}

export default ForgotPasswordModal;
