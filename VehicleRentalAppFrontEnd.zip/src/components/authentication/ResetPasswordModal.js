import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { resetPassword, forgotPassword } from "../../api/auth";
import { use } from "react";

function ResetPasswordModal({ show, email, onClose }) {
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [timeLeft, setTimeLeft] = useState(300); 
  const [showResend, setShowResend] = useState(false);  

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    } else {
      setShowResend(true); 
    }
  }, [timeLeft]);

  useEffect(() => {
    if (show) {
      setTimeLeft(300); 
    }
  }, [show]);
  
  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds
      .toString()
      .padStart(2, "0")}`;
  };

  const handleSubmit = async () => {
    if (!otp || !newPassword || !confirmPassword) {
      toast.error("Please fill in all fields.");
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error("Passwords do not match.");
      return;
    }

    setLoading(true);
    try {
      await resetPassword(email, otp, newPassword); 
      toast.success("Password reset successful!");
      onClose();
    } catch (error) {
      toast.error("Invalid OTP or error resetting password.");
      console.error("Error resetting password:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleResendOTP = async () => {
    setResendLoading(true);
    try {
      await forgotPassword(email); 
      toast.success("OTP resent successfully!");
      setTimeLeft(300);
      setShowResend(false); 
    } catch (error) {
      toast.error("Error resending OTP. Please try again.");
      console.error("Error resending OTP:", error);
    } finally {
      setResendLoading(false);
    }
  };

  return (
    <div className={`modal ${show ? "show" : ""}`} onClick={onClose}>
      <div className="modal-content relative" onClick={(e) => e.stopPropagation()}>
        <span className="absolute top-2 right-4 text-right text-blue-500 font-bold">
          {formatTime(timeLeft)}
        </span>
        <div className="flex flex-col">
          <h2 className="text-2xl text-orange-500 font-semibold">Reset Password</h2>
        <p>
          Enter the OTP sent to the email address: <strong>{email}</strong>
        </p>
        </div>


        <input
          type="text"
          placeholder="Enter OTP"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          className="w-full p-3 mt-4 mb-4 border border-gray-300 rounded-md"
        />
        <input
          type="password"
          placeholder="New Password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          className="w-full p-3 mb-4 border border-gray-300 rounded-md"
        />
        <input
          type="password"
          placeholder="Confirm Password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          className="w-full p-3 mb-4 border border-gray-300 rounded-md"
        />

        {showResend ? (
          <button
            onClick={handleResendOTP}
            className="w-full py-3 bg-orange-500 text-white rounded-md hover:bg-orange-600"
            disabled={resendLoading}
          >
            {resendLoading ? "Resending..." : "Resend OTP"}
          </button>
        ) : (
          <button
            onClick={handleSubmit}
            className="w-full py-3 bg-orange-500 text-white rounded-md hover:bg-orange-700"
            disabled={loading}
          >
            {loading ? "Processing..." : "Reset Password"}
          </button>
        )}
      </div>
    </div>
  );
}

export default ResetPasswordModal;
