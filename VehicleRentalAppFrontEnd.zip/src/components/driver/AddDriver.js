import React, { useState } from "react";
import { toast } from "react-toastify";
import { createDriver } from "../../api/auth.js";
import Cookies from "js-cookie";

const AddDriver = ({ isOpen, onClose, setDrivers }) => {
  const [formData, setFormData] = useState({
    name: "",
    licenseNumber: "",
    driverCostPerDay: "",
    contactNumber: "",
    email: "",
  });

  const [errors, setErrors] = useState({});

  const validate = () => {
    let newErrors = {};

    const namePattern = /^[A-Za-z]+$/;
    if (!formData.name.trim()) newErrors.name = "Name cannot be empty.";
    else if (formData.name.length < 3 || formData.name.length > 50) {
      newErrors.name = "Name should be between 3 to 50 characters";
    } else if (!namePattern.test(formData.name)) {
      newErrors.name = "Name should contain only alphabets";
    }

    if (
      !formData.driverCostPerDay ||
      formData.driverCostPerDay < 200 ||
      formData.driverCostPerDay > 10000
    ) {
      newErrors.driverCostPerDay =
        "Cost per day must be between ₹200 and ₹10,000.";
    }
    const licenseRegex = /^[A-Z]{2}[0-9]{2} [0-9]{12}$/;
    if (!licenseRegex.test(formData.licenseNumber)) {
      newErrors.licenseNumber =
        "License number format must be AA00 000000000000.";
    }
    const contactNumberRegex = /^[6-9]\d{9}$/;
    if (!contactNumberRegex.test(formData.contactNumber)) {
      newErrors.contactNumber =
        "Contact number must be a valid 10-digit number starting with 6, 7, 8, or 9.";
    }
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!emailRegex.test(formData.email)) {
      newErrors.email = "Email format is invalid.";
    } else if (formData.email.length > 100) {
      newErrors.email = "Email length should be less than 50 characters";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      const token = Cookies.get("user");
      const newDriver = await createDriver(formData, token);
      setDrivers((prevDrivers) => [...prevDrivers, newDriver]);
      toast.success("Driver added successfully.");
      onClose();
    } catch (error) {
      toast.error("Failed to add driver.");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-75 z-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96 relative">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-1 right-4 font-semibold text-3xl text-red-500 px-3 py-1 rounded-full "
        >
          x
        </button>

        <h2 className="text-2xl font-semibold text-center text-orange-500 mb-4">
          Add Driver
        </h2>

        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Name"
            className="w-full p-2 border rounded"
          />
          {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}

          <input
            type="text"
            name="licenseNumber"
            value={formData.licenseNumber}
            onChange={handleChange}
            placeholder="License Number"
            className="w-full p-2 border rounded"
          />
          {errors.licenseNumber && (
            <p className="text-red-500 text-sm">{errors.licenseNumber}</p>
          )}

          <input
            type="number"
            name="driverCostPerDay"
            value={formData.driverCostPerDay}
            onChange={handleChange}
            placeholder="Cost Per Day"
            className="w-full p-2 border rounded"
          />
          {errors.driverCostPerDay && (
            <p className="text-red-500 text-sm">{errors.driverCostPerDay}</p>
          )}

          <input
            type="text"
            name="contactNumber"
            value={formData.contactNumber}
            onChange={handleChange}
            placeholder="Contact Number"
            className="w-full p-2 border rounded"
          />
          {errors.contactNumber && (
            <p className="text-red-500 text-sm">{errors.contactNumber}</p>
          )}

          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Email"
            className="w-full p-2 border rounded"
          />
          {errors.email && (
            <p className="text-red-500 text-sm">{errors.email}</p>
          )}

          <div className="flex justify-center space-x-3">
            <button
              type="submit"
              className="w-full bg-orange-500 text-white px-4 py-2 rounded"
            >
              Add
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddDriver;
