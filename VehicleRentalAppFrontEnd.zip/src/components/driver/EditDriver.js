import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { updateDriver } from "../../api/auth.js";
import Cookies from "js-cookie";

const EditDriver = ({ isOpen, onClose, driver, setDrivers }) => {
  const [formData, setFormData] = useState({
    name: "",
    licenseNumber: "",
    driverCostPerDay: "",
    contactNumber: "",
    email: "", 
  });

  const [errors, setErrors] = useState({});

  const token = Cookies.get("user");

  useEffect(() => {
    if (driver) {
      setFormData({
        name: driver.name,
        licenseNumber: driver.licenseNumber,
        driverCostPerDay: driver.driverCostPerDay,
        contactNumber: driver.contactNumber,
        email: driver.email, 
      });
    }
  }, [driver]);

  const validate = () => {
    let newErrors = {};
    const namePattern = /^[A-Za-z]+$/;
    if (!formData.name.trim()) newErrors.name = "Name cannot be empty.";
    else if (formData.name.length < 3 || formData.name.length > 50) {
      newErrors.name = "Name should be between 3 to 50 characters";
    } else if (!namePattern.test(formData.name)) {
      newErrors.name = "Name should contain only alphabets";
    }
    if (!formData.driverCostPerDay || formData.driverCostPerDay < 200 || formData.driverCostPerDay > 10000) {
      newErrors.driverCostPerDay = "Cost per day must be between ₹200 and ₹10,000.";
    }
    const licenseRegex = /^[A-Z]{2}[0-9]{2} [0-9]{12}$/;
    if (!licenseRegex.test(formData.licenseNumber)) {
      newErrors.licenseNumber = "License number format must be AA00 000000000000.";
    }
    const contactNumberRegex = /^[0-9]{10}$/;
    if (!contactNumberRegex.test(formData.contactNumber)) {
      newErrors.contactNumber = "Contact number must be a 10-digit number.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    
    try {
      await updateDriver(driver.driverId, formData, token);
      toast.success("Driver updated successfully.");
      setDrivers((prevDrivers) =>
        prevDrivers.map((d) =>
          d.driverId === driver.driverId ? { ...d, ...formData } : d
        )
      );
      onClose();
    } catch (error) {
      toast.error("Failed to update driver.");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-75 z-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96 relative">
        <button 
          type="button" 
          onClick={onClose} 
          className="absolute top-2 right-4 font-semibold text-4xl text-red-500 px-3 py-1 rounded-full "
        >
          &times;
        </button>
  
        <h2 className="text-2xl text-orange-500 font-semibold mb-4 text-center">Edit Driver</h2>
  
        <form onSubmit={handleSubmit} className="space-y-3">
          <input 
            type="email" 
            name="email" 
            value={formData.email} 
            readOnly 
            className="w-full p-2 bg-gray-50 cursor-not-allowed"
          />

          <input 
            type="text" 
            name="name" 
            value={formData.name} 
            onChange={handleChange} 
            placeholder="Name" 
            className="w-full p-2 border rounded"
          />
          {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}
  
          <input 
            type="text" 
            name="licenseNumber" 
            value={formData.licenseNumber} 
            onChange={handleChange} 
            placeholder="License Number (AA00 000000000000)" 
            className="w-full p-2 border rounded"
          />
          {errors.licenseNumber && <p className="text-red-500 text-sm">{errors.licenseNumber}</p>}
  
          <input 
            type="number" 
            name="driverCostPerDay" 
            value={formData.driverCostPerDay} 
            onChange={handleChange} 
            placeholder="Cost Per Day" 
            className="w-full p-2 border rounded"
          />
          {errors.driverCostPerDay && <p className="text-red-500 text-sm">{errors.driverCostPerDay}</p>}

          <input 
            type="text" 
            name="contactNumber" 
            value={formData.contactNumber} 
            onChange={handleChange} 
            placeholder="Contact Number" 
            className="w-full p-2 border rounded"
          />
          {errors.contactNumber && <p className="text-red-500 text-sm">{errors.contactNumber}</p>}

          <div className="flex justify-center space-x-3">
            <button type="submit" className="bg-orange-500 w-full text-white px-4 py-2 rounded">
              Update
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditDriver;
