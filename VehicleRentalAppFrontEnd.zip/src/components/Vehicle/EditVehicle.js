// import React, { useState } from "react";
// import { toast } from "react-toastify";
// import { updateVehicle } from "../../api/auth";
// import { useCookies } from "react-cookie";

// const EditVehicle = ({ vehicle, onClose, setVehicles }) => {
//   const [vehicleData, setVehicleData] = useState({ ...vehicle, adminId: 1 });
//   const [errors, setErrors] = useState({});
//   const [cookies] = useCookies(["user"]);

//   const validate = () => {
//     const newErrors = {};

//     if (!vehicleData.modelName) {
//       newErrors.modelName = "Model name is required.";
//     }
//     if (!vehicleData.registrationNumber) {
//       newErrors.registrationNumber = "Registration number is required.";
//     } else if (!/^[A-Z0-9-]+$/.test(vehicleData.registrationNumber)) {
//       newErrors.registrationNumber = "Invalid registration number format.";
//     }
//     if (!vehicleData.categoryType) {
//       newErrors.categoryType = "Category type is required.";
//     }
//     if (!vehicleData.fuelType) {
//       newErrors.fuelType = "Fuel type is required.";
//     }
//     if (!vehicleData.color) {
//       newErrors.color = "Color is required.";
//     }
//     if (!vehicleData.modelYear) {
//       newErrors.modelYear = "Model year is required.";
//     } else if (vehicleData.modelYear < 1886 || vehicleData.modelYear > new Date().getFullYear()) {
//       newErrors.modelYear = "Invalid model year.";
//     }
//     if (!vehicleData.pricePerDay || vehicleData.pricePerDay <= 0) {
//       newErrors.pricePerDay = "Price per day must be greater than 0.";
//     }
//     if (!vehicleData.insuranceNumber) {
//       newErrors.insuranceNumber = "Insurance number is required.";
//     }
//     if (!vehicleData.featureDescription) {
//       newErrors.featureDescription = "Feature description is required.";
//     }

//     setErrors(newErrors);
//     return Object.keys(newErrors).length === 0;
//   };

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setVehicleData({
//       ...vehicleData,
//       adminId:1,
//       [name]: value,
//     });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     if (!validate()) {
//       return;
//     }

//     const token = cookies.user;
//     if (!token) {
//       toast.error("Please log in first.");
//       return;
//     }

//     try {
//       console.log(vehicle)
//       console.log(vehicleData)
//       await updateVehicle(vehicle.vehicleId, vehicleData, token);
//       toast.success("Vehicle updated successfully!");
//     } catch (error) {
//       toast.error(error.message || "Failed to update vehicle.");
//     }
//   };

//   return (
//     <div className="max-w-lg mx-auto">
//       <h2 className="text-2xl text-center text-orange-500 font-semibold mb-6">Edit Vehicle Information</h2>

//       <form onSubmit={handleSubmit} className="space-y-4">
//         <div className="flex items-center space-x-4">
//           <label className="w-1/3 font-medium">Model Name</label>
//           <div className="w-2/3">
//             <input
//               type="text"
//               name="modelName"
//               value={vehicleData.modelName}
//               onChange={handleInputChange}
//               className="w-full p-2 border border-gray-300 rounded"
//             />
//             {errors.modelName && (
//               <p className="text-red-500 text-sm">{errors.modelName}</p>
//             )}
//           </div>
//         </div>
//         <div className="flex items-center space-x-4">
//           <label className="w-1/3 font-medium">Registration Number</label>
//           <div className="w-2/3">
//             <input
//               type="text"
//               name="registrationNumber"
//               value={vehicleData.registrationNumber}
//               onChange={handleInputChange}
//               className="w-full p-2 border border-gray-300 rounded"
//             />
//             {errors.registrationNumber && (
//               <p className="text-red-500 text-sm">{errors.registrationNumber}</p>
//             )}
//           </div>
//         </div>
//         <div className="flex items-center space-x-4">
//           <label className="w-1/3 font-medium">Category Type</label>
//           <div className="w-2/3">
//             <input
//               type="text"
//               name="categoryType"
//               value={vehicleData.categoryType}
//               onChange={handleInputChange}
//               className="w-full p-2 border border-gray-300 rounded"
//             />
//             {errors.categoryType && (
//               <p className="text-red-500 text-sm">{errors.categoryType}</p>
//             )}
//           </div>
//         </div>
//         <div className="flex items-center space-x-4">
//           <label className="w-1/3 font-medium">Fuel Type</label>
//           <div className="w-2/3">
//             <input
//               type="text"
//               name="fuelType"
//               value={vehicleData.fuelType}
//               onChange={handleInputChange}
//               className="w-full p-2 border border-gray-300 rounded"
//             />
//             {errors.fuelType && (
//               <p className="text-red-500 text-sm">{errors.fuelType}</p>
//             )}
//           </div>
//         </div>
//         <div className="flex items-center space-x-4">
//           <label className="w-1/3 font-medium">Color</label>
//           <div className="w-2/3">
//             <input
//               type="text"
//               name="color"
//               value={vehicleData.color}
//               onChange={handleInputChange}
//               className="w-full p-2 border border-gray-300 rounded"
//             />
//             {errors.color && (
//               <p className="text-red-500 text-sm">{errors.color}</p>
//             )}
//           </div>
//         </div>
//         <div className="flex items-center space-x-4">
//           <label className="w-1/3 font-medium">Model Year</label>
//           <div className="w-2/3">
//             <input
//               type="number"
//               name="modelYear"
//               value={vehicleData.modelYear}
//               onChange={handleInputChange}
//               className="w-full p-2 border border-gray-300 rounded"
//             />
//             {errors.modelYear && (
//               <p className="text-red-500 text-sm">{errors.modelYear}</p>
//             )}
//           </div>
//         </div>
//         <div className="flex items-center space-x-4">
//           <label className="w-1/3 font-medium">Price Per Day</label>
//           <div className="w-2/3">
//             <input
//               type="number"
//               step="0.01"
//               name="pricePerDay"
//               value={vehicleData.pricePerDay}
//               onChange={handleInputChange}
//               className="w-full p-2 border border-gray-300 rounded"
//             />
//             {errors.pricePerDay && (
//               <p className="text-red-500 text-sm">{errors.pricePerDay}</p>
//             )}
//           </div>
//         </div>
//         <div className="flex items-center space-x-4">
//           <label className="w-1/3 font-medium">Insurance Number</label>
//           <div className="w-2/3">
//             <input
//               type="text"
//               name="insuranceNumber"
//               value={vehicleData.insuranceNumber}
//               onChange={handleInputChange}
//               className="w-full p-2 border border-gray-300 rounded"
//             />
//             {errors.insuranceNumber && (
//               <p className="text-red-500 text-sm">{errors.insuranceNumber}</p>
//             )}
//           </div>
//         </div>
//         <div className="flex items-center space-x-4">
//           <label className="w-1/3 font-medium">Feature Description</label>
//           <div className="w-2/3">
//             <textarea
//               name="featureDescription"
//               value={vehicleData.featureDescription}
//               onChange={handleInputChange}
//               className="w-full p-2 border border-gray-300 rounded"
//             />
//             {errors.featureDescription && (
//               <p className="text-red-500 text-sm">{errors.featureDescription}</p>
//             )}
//           </div>
//         </div>

//         <button
//           type="submit"
//           className="w-full bg-orange-500 text-white py-2 px-4 rounded hover:bg-orange-600 transition"
//         >
//           Update Vehicle
//         </button>
//       </form>
//     </div>
//   );

// };

// export default EditVehicle;

import React, { useState } from "react";
import { toast } from "react-toastify";
import { updateVehicle } from "../../api/auth";
import { useCookies } from "react-cookie";

const EditVehicle = ({ vehicle, onClose, setVehicles }) => {
  const [vehicleData, setVehicleData] = useState({ ...vehicle, adminId: 1 });
  const [errors, setErrors] = useState({});
  const [cookies] = useCookies(["user"]);

  const categoryOptions = [
    "Sedan",
    "Xuv",
    "Suv",
    "Muv",
    "Jeep",
    "Offroad",
    "Hatchback",
  ];
  const colorOptions = [
    "Red",
    "Blue",
    "Black",
    "Grey",
    "Yellow",
    "Silver",
    "White",
    "Orange",
  ];
  const fuelOptions = ["Petrol", "Diesel", "Electric"];

  const validate = () => {
    const newErrors = {};

    const namePattern = /^(?=.*[A-Za-z]{3,})[A-Za-z0-9\- ]+$/;
    if (!vehicleData.modelName.trim())
      newErrors.modelName = "Model Name is required.";
    else if(vehicleData.modelName.length < 3 || vehicleData.modelName.length > 25){
      newErrors.modelName = "Length of model name should be between 3 and 25 characters";
    } else if(!namePattern.test(vehicleData.modelName)){
      newErrors.modelName = "Model name should contain atleast 3 alphabets and 0 or more numbers";
    }

    if (!vehicleData.registrationNumber) {
      newErrors.registrationNumber = "Registration number is required.";
    } else if (
      !/^[A-Z]{2}\d{2}[A-Z]{2}\d{4}$/.test(vehicleData.registrationNumber)
    ) {
      newErrors.registrationNumber =
        "Invalid registration number format (AA00AA0000).";
    }
    if (!vehicleData.categoryType) {
      newErrors.categoryType = "Category type is required.";
    }
    if (!vehicleData.fuelType) {
      newErrors.fuelType = "Fuel type is required.";
    }
    if (!vehicleData.color) {
      newErrors.color = "Color is required.";
    }
    if (!vehicleData.modelYear) {
      newErrors.modelYear = "Model year is required.";
    } else if (
      vehicleData.modelYear < 1886 ||
      vehicleData.modelYear > new Date().getFullYear()
    ) {
      newErrors.modelYear = "Invalid model year.";
    }
    if (
      !vehicleData.pricePerDay ||
      vehicleData.pricePerDay < 400 ||
      vehicleData.pricePerDay > 10000
    ) {
      newErrors.pricePerDay = "Price per day must be between 400 and 10000.";
    }
    if (!vehicleData.insuranceNumber) {
      newErrors.insuranceNumber = "Insurance number is required.";
    } else if (!/^INS\d{8}$/.test(vehicleData.insuranceNumber)) {
      newErrors.insuranceNumber =
        "Invalid insurance number format (INS00000000).";
    }
    if (!vehicleData.featureDescription) {
      newErrors.featureDescription = "Feature description is required.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setVehicleData({
      ...vehicleData,
      adminId: 1,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validate()) {
      return;
    }

    const token = cookies.user;
    if (!token) {
      toast.error("Please log in first.");
      return;
    }

    try {
      console.log(vehicle);
      console.log(vehicleData);
      await updateVehicle(vehicle.vehicleId, vehicleData, token);
      toast.success("Vehicle updated successfully!");
    } catch (error) {
      toast.error(error.message || "Failed to update vehicle.");
    }
  };

  return (
    <div className="max-w-lg mx-auto">
      <h2 className="text-2xl text-center text-orange-500 font-semibold mb-6">
        Edit Vehicle Information
      </h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Model Name</label>
          <div className="w-2/3">
            <input
              type="text"
              name="modelName"
              value={vehicleData.modelName}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            />
            {errors.modelName && (
              <p className="text-red-500 text-sm">{errors.modelName}</p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Registration Number</label>
          <div className="w-2/3">
            <input
              type="text"
              name="registrationNumber"
              value={vehicleData.registrationNumber}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            />
            {errors.registrationNumber && (
              <p className="text-red-500 text-sm">
                {errors.registrationNumber}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Category Type</label>
          <div className="w-2/3">
            <select
              name="categoryType"
              value={vehicleData.categoryType}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            >
              <option disabled="true" value="">Select Category</option>
              {categoryOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
            {errors.categoryType && (
              <p className="text-red-500 text-sm">{errors.categoryType}</p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Fuel Type</label>
          <div className="w-2/3">
            <select
              name="fuelType"
              value={vehicleData.fuelType}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            >
              <option disabled="true" value="">Select Fuel Type</option>
              {fuelOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
            {errors.fuelType && (
              <p className="text-red-500 text-sm">{errors.fuelType}</p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Color</label>
          <div className="w-2/3">
            <select
              name="color"
              value={vehicleData.color}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            >
              <option disabled="true" value="">Select Color</option>
              {colorOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
            {errors.color && (
              <p className="text-red-500 text-sm">{errors.color}</p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Model Year</label>
          <div className="w-2/3">
            <input
              type="number"
              name="modelYear"
              value={vehicleData.modelYear}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            />
            {errors.modelYear && (
              <p className="text-red-500 text-sm">{errors.modelYear}</p>
            )}
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Price Per Day</label>
          <div className="w-2/3">
            <input
              type="number"
              step="0.01"
              name="pricePerDay"
              value={vehicleData.pricePerDay}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            />
            {errors.pricePerDay && (
              <p className="text-red-500 text-sm">{errors.pricePerDay}</p>
            )}
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Insurance Number</label>
          <div className="w-2/3">
            <input
              type="text"
              name="insuranceNumber"
              value={vehicleData.insuranceNumber}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            />
            {errors.insuranceNumber && (
              <p className="text-red-500 text-sm">{errors.insuranceNumber}</p>
            )}
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Feature Description</label>
          <div className="w-2/3">
            <textarea
              name="featureDescription"
              value={vehicleData.featureDescription}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            />
            {errors.featureDescription && (
              <p className="text-red-500 text-sm">
                {errors.featureDescription}
              </p>
            )}
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-orange-500 text-white py-2 px-4 rounded hover:bg-orange-600 transition"
        >
          Update Vehicle
        </button>
      </form>
    </div>
  );
};

export default EditVehicle;
