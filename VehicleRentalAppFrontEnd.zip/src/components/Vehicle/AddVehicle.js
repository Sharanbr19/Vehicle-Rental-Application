import React, { useState } from "react";
import { useCookies } from "react-cookie";
import { toast } from "react-toastify";
import { addVehicle } from "../../api/auth";

const AddVehicle = () => {
  const [vehicleData, setVehicleData] = useState({
    modelName: "",
    registrationNumber: "",
    categoryType: "",
    fuelType: "",
    color: "",
    mileage: 15.3,
    modelYear: "",
    pricePerDay: "",
    featureDescription: "",
    insuranceNumber: "",
    vehicleImageURL: "",
    adminId: "1",
  });

  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [cookies] = useCookies(["user"]);

  const getBearerToken = () => {
    const token = cookies.user;
    return token || null;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setVehicleData({
      ...vehicleData,
      [name]: value,
    });
    setErrors({ ...errors, [name]: "" });
  };

  const validateFields = () => {
    const currentYear = new Date().getFullYear();
    const newErrors = {};

    const namePattern = /^(?=.*[A-Za-z]{3,})[A-Za-z0-9\- ]+$/;
    if (!vehicleData.modelName.trim())
      newErrors.modelName = "Model Name is required.";
    else if(vehicleData.modelName.length < 3 || vehicleData.modelName.length > 25){
      newErrors.modelName = "Length of model name should be between 3 and 25 characters";
    } else if(!namePattern.test(vehicleData.modelName)){
      newErrors.modelName = "Model name should contain atleast 3 alphabets and 0 or more numbers";
    }
    if (!vehicleData.registrationNumber.trim()) {
      newErrors.registrationNumber = "Registration Number is required.";
    } else if (
      !/^[A-Z]{2}\d{2}[A-Z]{2}\d{4}$/.test(vehicleData.registrationNumber)
    ) {
      newErrors.registrationNumber =
        "Registration Number must be in format: AA00AA0000.";
    }

    if (!vehicleData.categoryType.trim())
      newErrors.categoryType = "Category Type is required.";
    if (!vehicleData.fuelType.trim())
      newErrors.fuelType = "Fuel Type is required.";
    if (!vehicleData.color.trim()) newErrors.color = "Color is required.";

    if (!vehicleData.modelYear.trim()) {
      newErrors.modelYear = "Model Year is required.";
    } else if (
      isNaN(vehicleData.modelYear) ||
      vehicleData.modelYear < 2000 ||
      vehicleData.modelYear > currentYear
    ) {
      newErrors.modelYear = `Model Year must be between 2000 and ${currentYear}.`;
    }

    if (!vehicleData.pricePerDay.trim()) {
      newErrors.pricePerDay = "Price Per Day is required.";
    } else if (
      isNaN(vehicleData.pricePerDay) ||
      vehicleData.pricePerDay < 400 ||
      vehicleData.pricePerDay > 10000
    ) {
      newErrors.pricePerDay = "Price Per Day must be between 400 and 10000.";
    }

    if (!vehicleData.insuranceNumber.trim()) {
      newErrors.insuranceNumber = "Insurance Number is required.";
    } else if (!/^INS\d{8}$/.test(vehicleData.insuranceNumber)) {
      newErrors.insuranceNumber =
        "Insurance Number must be in format: INS00000000.";
    }

    if (!vehicleData.featureDescription.trim()) {
      newErrors.featureDescription = "Feature Description is required.";
    }

    if (!vehicleData.vehicleImageURL.trim()) {
      vehicleData.vehicleImageURL =
        "http://localhost:3000/images/vehicles/blueSedan.jpg";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateFields()) return;

    const token = getBearerToken();
    if (!token) {
      setErrorMessage("Authentication token not found. Please log in.");
      toast.error("Please log in first.");
      return;
    }

    try {
      await addVehicle(vehicleData, token);
      setSuccessMessage("Vehicle added successfully!");
      toast.success("Vehicle added successfully!");
      setVehicleData({
        modelName: "",
        registrationNumber: "",
        categoryType: "",
        fuelType: "",
        color: "",
        modelYear: "",
        pricePerDay: "",
        featureDescription: "",
        insuranceNumber: "",
        vehicleImageURL: "",
      });
    } catch (error) {
      setErrorMessage(
        error.message || "Failed to add vehicle. Please try again."
      );
      toast.error(error.message || "Failed to add vehicle.");
    }
  };

  return (
    <div className="max-w-lg mx-auto">
      <h2 className="text-2xl text-center text-orange-500 font-bold mb-6">
        Add Vehicle
      </h2>

      {successMessage && (
        <div className="bg-green-100 text-green-800 p-3 rounded-md mb-4">
          {successMessage}
        </div>
      )}

      {errorMessage && (
        <div className="bg-red-100 text-red-800 p-3 rounded-md mb-4">
          {errorMessage}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Model Name</label>
          <div className="w-2/3">
            <input
              type="text"
              name="modelName"
              value={vehicleData.modelName}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            />
            {errors.modelName && (
              <p className="text-red-500 text-sm">{errors.modelName}</p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Registration Number</label>
          <div className="w-2/3">
            <input
              type="text"
              name="registrationNumber"
              value={vehicleData.registrationNumber}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            />
            {errors.registrationNumber && (
              <p className="text-red-500 text-sm">
                {errors.registrationNumber}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Category Type</label>
          <div className="w-2/3">
            <select
              name="categoryType"
              value={vehicleData.categoryType}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            >
              <option disabled="true" value="">Select Category</option>
              <option value="Sedan">Sedan</option>
              <option value="Xuv">Xuv</option>
              <option value="Suv">Suv</option>
              <option value="Muv">Muv</option>
              <option value="Jeep">Jeep</option>
              <option value="Offroad">Offroad</option>
              <option value="Hatchback">Hatchback</option>
            </select>
            {errors.categoryType && (
              <p className="text-red-500 text-sm">{errors.categoryType}</p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Fuel Type</label>
          <div className="w-2/3">
            <select
              name="fuelType"
              value={vehicleData.fuelType}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            >
              <option disabled="true" value="">Select Fuel Type</option>
              <option value="Petrol">Petrol</option>
              <option value="Diesel">Diesel</option>
              <option value="Electric">Electric</option>
            </select>
            {errors.fuelType && (
              <p className="text-red-500 text-sm">{errors.fuelType}</p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Color</label>
          <div className="w-2/3">
            <select
              name="color"
              value={vehicleData.color}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            >
              <option disabled="true" value="">Select Color</option>
              <option value="Red">Red</option>
              <option value="Blue">Blue</option>
              <option value="Black">Black</option>
              <option value="Grey">Grey</option>
              <option value="Yellow">Yellow</option>
              <option value="Silver">Silver</option>
              <option value="White">White</option>
              <option value="Orange">Orange</option>
            </select>
            {errors.color && (
              <p className="text-red-500 text-sm">{errors.color}</p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Model Year</label>
          <div className="w-2/3">
            <input
              type="text"
              name="modelYear"
              value={vehicleData.modelYear}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            />
            {errors.modelYear && (
              <p className="text-red-500 text-sm">{errors.modelYear}</p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Price Per Day</label>
          <div className="w-2/3">
            <input
              type="number"
              name="pricePerDay"
              value={vehicleData.pricePerDay}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            />
            {errors.pricePerDay && (
              <p className="text-red-500 text-sm">{errors.pricePerDay}</p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Insurance Number</label>
          <div className="w-2/3">
            <input
              type="text"
              name="insuranceNumber"
              value={vehicleData.insuranceNumber}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            />
            {errors.insuranceNumber && (
              <p className="text-red-500 text-sm">{errors.insuranceNumber}</p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Feature Description</label>
          <div className="w-2/3">
            <textarea
              name="featureDescription"
              value={vehicleData.featureDescription}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
              rows="3"
            />
            {errors.featureDescription && (
              <p className="text-red-500 text-sm">
                {errors.featureDescription}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <label className="w-1/3 font-medium">Image URL</label>
          <div className="w-2/3">
            <input
              type="text"
              name="vehicleImageURL"
              value={vehicleData.vehicleImageURL}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded"
            />
            {errors.vehicleImageURL && (
              <p className="text-red-500 text-sm">{errors.vehicleImageURL}</p>
            )}
          </div>
        </div>
        <button
          type="submit"
          className="w-full bg-orange-500 text-white py-2 px-4 rounded hover:bg-orange-600 transition"
        >
          Add Vehicle
        </button>
      </form>
    </div>
  );
};

export default AddVehicle;
