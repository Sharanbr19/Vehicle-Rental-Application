import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import {
  getAllVehicles,
  searchVehicles,
  compareVehicles,
} from "../../api/auth";
import { useCookies } from "react-cookie";
import Modal from "react-modal";
import debounce from "lodash.debounce";

const CompareVehicles = () => {
  const [vehicles, setVehicles] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedVehicles, setSelectedVehicles] = useState([]);
  const [comparisonData, setComparisonData] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [cookies] = useCookies(["user"]);

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  const fetchAllVehicles = async () => {
    const token = cookies.user;
    if (!token) {
      toast.error("Authentication token not found. Please log in.");
      return;
    }

    try {
      const data = await getAllVehicles(token);
      setVehicles(data);
    } catch (error) {
      console.error("Error fetching vehicles:", error);
      toast.error("Failed to fetch vehicles.");
    }
  };

  const fetchSearchVehicles = async (query) => {
    const token = cookies.user;
    if (!token) {
      toast.error("Authentication token not found. Please log in.");
      return;
    }

    try {
      const data = await searchVehicles(query, token);
      setVehicles(data);
    } catch (error) {
      console.error("Error searching vehicles:", error);
      toast.error("Failed to search vehicles.");
    }
  };

  const debouncedSearch = debounce((query) => {
    if (query.trim() === "") {
      fetchAllVehicles();
    } else {
      fetchSearchVehicles(query);
    }
  }, 300);

  const handleSearchChange = (e) => {
    const query = e.target.value;
    setSearchQuery(query);
    debouncedSearch(query);
  };

  useEffect(() => {
    fetchAllVehicles();
    return () => {
      debouncedSearch.cancel();
    };
  }, []);

  const handleVehicleSelection = (vehicleId) => {
    let toastDisplayed = false;

    setSelectedVehicles((prevSelected) => {
      const isAlreadySelected = prevSelected.includes(vehicleId);
      if (isAlreadySelected) {
        return prevSelected.filter((id) => id !== vehicleId);
      }
      if (prevSelected.length === 2) {
        if (!toastDisplayed) {
          toast.error("You can select only 2 vehicles for comparison.");
          toastDisplayed = true;
        }
        return prevSelected;
      }
      return [...prevSelected, vehicleId];
    });
  };

  const handleCompare = async () => {
    if (selectedVehicles.length !== 2) {
      toast.error("Please select exactly 2 vehicles for comparison.");
      return;
    }

    const token = cookies.user;
    if (!token) {
      toast.error("Authentication token not found. Please log in.");
      return;
    }

    try {
      const data = await compareVehicles(selectedVehicles, token);

      const selectedVehicleDetails = vehicles.filter((vehicle) =>
        selectedVehicles.includes(vehicle.vehicleId)
      );

      setComparisonData({
        details: selectedVehicleDetails,
        comparison: data,
      });

      setIsModalOpen(true);
    } catch (error) {
      console.error("Error comparing vehicles:", error);
      toast.error("Failed to compare vehicles.");
    }
  };

  const totalPages = Math.ceil(vehicles.length / itemsPerPage);

  const paginatedVehicles = vehicles.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="p-6 px-4">
      <div className="p-4 flex flex-col sm:flex-row items-center justify-center mb-4 gap-4 sm:gap-6">
        <input
          type="text"
          placeholder="Search vehicles"
          value={searchQuery}
          onChange={handleSearchChange}
          className="border px-4 py-2 rounded-lg w-full sm:w-80"
        />
        <button
          className="bg-primary text-white py-2 px-6 rounded hover:bg-orange-700 w-full sm:w-auto"
          onClick={handleCompare}
        >
          Compare Vehicles
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 mb-6">
        {paginatedVehicles.length > 0 ? (
          paginatedVehicles.map((vehicle) => (
            <div
              key={vehicle.vehicleId}
              className="border rounded-lg shadow-md"
            >
              <img
                src={vehicle.vehicleImageURL}
                alt={vehicle.modelName}
                className="w-full h-48 object-cover rounded"
              />
              <div className="p-6 bg-cyan-100">
              <h3 className="text-lg text-center font-semibold mb-2">
                {vehicle.modelName} ({vehicle.categoryType})
              </h3>
              <div className="flex justify-center">
                <button
                  className={`py-2 px-4 mt-2 rounded w-full ${
                    selectedVehicles.includes(vehicle.vehicleId)
                      ? "bg-green-500 text-white"
                      : "bg-blue-500 text-white"
                  }`}
                  onClick={() => handleVehicleSelection(vehicle.vehicleId)}
                >
                  {selectedVehicles.includes(vehicle.vehicleId)
                    ? "Selected"
                    : "Select for Comparison"}
                </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full text-center text-gray-500 text-xl">
            No vehicles found matching the search criteria.
          </div>
        )}
      </div>

      <div className="flex justify-center items-center gap-4">
        <button
          disabled={currentPage === 1}
          onClick={() => setCurrentPage((prev) => prev - 1)}
          className="bg-blue-500 hover:bg-blue-600 text-white py-1 px-4 rounded disabled:opacity-50"
        >
          Previous
        </button>
        <span className="text-lg">
          Page {currentPage} of {totalPages}
        </span>
        <button
          disabled={currentPage === totalPages}
          onClick={() => setCurrentPage((prev) => prev + 1)}
          className="bg-blue-500 hover:bg-blue-600 text-white py-1 px-4 rounded disabled:opacity-50"
        >
          Next
        </button>
      </div>

      <Modal
        isOpen={isModalOpen}
        onRequestClose={() => setIsModalOpen(false)}
        contentLabel="Comparison Results"
        className="bg-white p-6 rounded-lg shadow-lg max-w-4xl w-full max-h-[85vh] mx-auto overflow-y-auto fixed inset-0 m-auto"
        overlayClassName="fixed inset-0 bg-black bg-opacity-75"
      >
        <button
          onClick={() => setIsModalOpen(false)}
          className="absolute top-2 right-4 text-red-500 text-2xl font-bold py-2 px-4 rounded-full hover:text-red-700 transition duration-300"
        >
          ✖
        </button>

        <h2 className="text-2xl font-bold text-orange-500 mb-6 text-center">
          Comparison Results
        </h2>

        {comparisonData && comparisonData.details && (
          <table className="table-auto w-full border-collapse border border-gray-300 text-center">
            <thead>
              <tr>
                <th className="border border-gray-300 px-4 py-2 w-1/4">
                  Vehicle Attribute
                </th>
                <th className="border border-gray-300 px-4 py-2 w-1/3">
                  <img
                    src={comparisonData.details[0]?.vehicleImageURL}
                    alt="Vehicle 1"
                    className="w-full h-32 object-cover mx-auto mb-2 rounded-lg"
                  />
                </th>
                <th className="border border-gray-300 px-4 py-2 w-1/3">
                  <img
                    src={comparisonData.details[1]?.vehicleImageURL}
                    alt="Vehicle 2"
                    className="w-full h-32 object-cover mx-auto mb-2 rounded-lg"
                  />
                </th>
              </tr>
            </thead>
            <tbody>
              {comparisonData.comparison.map((data, index) => (
                <tr
                  key={index}
                  className={index % 2 === 0 ? "bg-gray-100" : "bg-white"}
                >
                  <td className="border border-gray-300 px-4 py-3 font-semibold">
                    {data.attribute}
                  </td>
                  <td className="border border-gray-300 px-4 py-3">
                    {data.value1}
                  </td>
                  <td className="border border-gray-300 px-4 py-3">
                    {data.value2}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Modal>
    </div>
  );
};

export default CompareVehicles;
