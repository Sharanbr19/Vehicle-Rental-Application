import axios from "axios";
import { toast } from "react-toastify";

// Function to make an API request
const makeApiCall = async (method, url, data = null, token = null, params = null) => {
  try {
    const headers = {
      Authorization: token ? `Bearer ${token}` : undefined,
      "Content-Type": data ? "application/json" : undefined,
    };

    const config = {
      method,
      url: `${process.env.REACT_APP_API_BASE_URL}${url}`,
      headers,
      data,
      params,
    };
    const response = await axios(config);
    return response.data;
  } catch (error) {
    console.error("API Error:", error.response?.data || error.message);
    throw new Error(error.response?.data?.message || "API request failed");
  }
};

// Login User
export const loginUser = (credentials) => makeApiCall("post", process.env.REACT_APP_LOGIN_URL, credentials);

// Register User
export const registerUser = (userData) => makeApiCall("post", process.env.REACT_APP_REGISTER_URL, userData);

// Check if Email Exists
export const checkEmailExists = (email) => makeApiCall("get", process.env.REACT_APP_CHECK_EMAIL_URL, null, null, { email });

// Forgot Password
export const forgotPassword = (email) => makeApiCall("post", `${process.env.REACT_APP_FORGOT_PASSWORD_URL}?email=${email}`);

// Reset Password
export const resetPassword = (email, otp, newPassword) => makeApiCall("post", process.env.REACT_APP_RESET_PASSWORD_URL, null, null, { email, otp, newPassword });

// Send OTP
export const sendOtpToEmail = (email) => 
  makeApiCall("post", `${process.env.REACT_APP_SEND_OTP_URL}?email=${email}`);

// Verify OTP
export const verifyOtp = (email, otp) => 
  makeApiCall("post",`${process.env.REACT_APP_VERIFY_OTP_URL}?email=${email}&&otp=${otp}`);

// Get all vehicles
export const getAllVehicles = (token) => makeApiCall("get", process.env.REACT_APP_VEHICLES_URL, null, token);

// Get a specific vehicle by ID
export const getVehicleById = (vehicleId, token) => makeApiCall("get", `${process.env.REACT_APP_VEHICLES_URL}/${vehicleId}`, null, token);

// Add a new vehicle
export const addVehicle = (vehicleData, token) => makeApiCall("post", process.env.REACT_APP_VEHICLES_URL, vehicleData, token);

// Update an existing vehicle
export const updateVehicle = (vehicleId, vehicleData, token) => makeApiCall("put", `${process.env.REACT_APP_VEHICLES_URL}/${vehicleId}`, vehicleData, token);

// Delete a vehicle
export const deleteVehicle = async (vehicleId, token) => {
  try {
    const response = await axios.delete(`${process.env.REACT_APP_API_BASE_URL}${process.env.REACT_APP_VEHICLES_URL}/${vehicleId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    if (error.response && error.response.status === 400 && error.response.data === "Cannot delete vehicle because it is present in a booking") {
      toast.error("Vehicle is already booked, cannot delete");
    } 
    throw error;
  }
};

// Get User by ID
export const getUserById = (userId, token) => makeApiCall("get", `${process.env.REACT_APP_USERS_URL}/${userId}`, null, token);

// Get User by Email
export const getUserByEmail = (email, token) => makeApiCall("get", `${process.env.REACT_APP_USERS_URL}/email/${email}`, null, token);

// Get all users
export const getAllUsers = (token) => makeApiCall("get", `${process.env.REACT_APP_USERS_URL}/all`, null, token);

// Update User
export const updateUser = (userId, userData, token) => makeApiCall("put", `${process.env.REACT_APP_USERS_URL}/${userId}`, userData, token);

//Update user profile
export const updateUserProfile = (userId, userData, token) => makeApiCall("put", `${process.env.REACT_APP_USERS_URL}/user-profile/${userId}`, userData, token);

// Delete User 
export const deleteUser = (userId, token) => makeApiCall("delete", `${process.env.REACT_APP_USERS_URL}/${userId}`, null, token);

// Search Vehicles
export const searchVehicles = (keyword, token) => makeApiCall("get", `${process.env.REACT_APP_SEARCH_VEHICLES_URL}?keyword=${keyword}`, null, token);

// Filter Vehicles
export const filterVehicles = (filterCriteria, token) => makeApiCall("post", process.env.REACT_APP_FILTER_VEHICLES_URL, filterCriteria, token);

// Sort Vehicles
export const sortVehicles = (sortBy, ascending, token) => makeApiCall("get", `${process.env.REACT_APP_SORT_VEHICLES_URL}?sortBy=${sortBy}&ascending=${ascending}`, null, token);

// Compare Vehicles
export const compareVehicles = (vehicleIds, token) => makeApiCall("post", process.env.REACT_APP_COMPARE_VEHICLES_URL, vehicleIds, token);

// Add a vehicle to the user's favorites
export const addFavorite = (favoriteDTO, token) => makeApiCall("post", process.env.REACT_APP_FAVORITES_URL, favoriteDTO, token);

// Remove a vehicle from the user's favorites
export const removeFavorite = (customerId, vehicleId, token) => makeApiCall("delete", `${process.env.REACT_APP_FAVORITES_URL}/${customerId}/${vehicleId}`, null, token);

// Get all favorites for a specific customer
export const getFavoritesByCustomer = (customerId, token) => makeApiCall("get", `${process.env.REACT_APP_FAVORITES_URL}/${customerId}`, null, token);

// Create a new driver
export const createDriver = (driverDTO, token) => makeApiCall("post", process.env.REACT_APP_DRIVERS_URL, driverDTO, token);

// Get a driver by ID
export const getDriverById = (driverId, token) => makeApiCall("get", `${process.env.REACT_APP_DRIVERS_URL}/${driverId}`, null, token);

// Get all drivers
export const getAllDrivers = (token) => makeApiCall("get", process.env.REACT_APP_DRIVERS_URL, null, token);

// Update a driver
export const updateDriver = (driverId, driverDTO, token) => makeApiCall("put", `${process.env.REACT_APP_DRIVERS_URL}/${driverId}`, driverDTO, token);

// Delete a driver
export const deleteDriver = (driverId, token) => makeApiCall("delete", `${process.env.REACT_APP_DRIVERS_URL}/${driverId}`, null, token);

// Create a Booking
export const createBooking = async (bookingData, token) => {
  try {
    const response = await makeApiCall("post", process.env.REACT_APP_BOOKINGS_URL, bookingData, token);
    return response; 
  } catch (error) {
    throw error;
  }
};

// Get Available Vehicles
export const getAvailableVehicles = (fromDate, toDate, token) => makeApiCall("get", `${process.env.REACT_APP_BOOKINGS_URL}/available-vehicles?fromDate=${fromDate}&toDate=${toDate}`, null, token);

// Get Booking by ID
export const getBookingById = (bookingId, token) => makeApiCall("get", `${process.env.REACT_APP_BOOKINGS_URL}/${bookingId}`, null, token);

// Get Booking by Vehicle ID
export const getBookingByCustomerId = (customerId, token) => makeApiCall("get", `${process.env.REACT_APP_BOOKINGS_URL}/customer/${customerId}`, null, token);

// Get Booking by Vehicle ID
export const getBookingByVehicleId = (vehicleId, token) => makeApiCall("get", `${process.env.REACT_APP_BOOKINGS_URL}/vehicle/${vehicleId}`, null, token);

// Get all bookings
export const getAllBookings = (token) => makeApiCall("get", process.env.REACT_APP_BOOKINGS_URL, null, token);

// Update Booking
export const updateBooking = (bookingId, bookingData, token) => makeApiCall("put", `${process.env.REACT_APP_BOOKINGS_URL}/${bookingId}`, bookingData, token);

// Delete Booking
export const deleteBooking = (bookingId, token) => makeApiCall("delete", `${process.env.REACT_APP_BOOKINGS_URL}/${bookingId}`, null, token);

// Check Booking Overlap
export const checkBookingOverlap = (bookingData, token) => makeApiCall("post", `${process.env.REACT_APP_BOOKINGS_URL}/check-overlap`, bookingData, token);

// Create a Payment
export const createPayment = (paymentData, token) => makeApiCall("post", process.env.REACT_APP_PAYMENTS_URL, paymentData, token);

// Get Payment by ID
export const getPaymentById = (paymentId, token) => makeApiCall("get", `${process.env.REACT_APP_PAYMENTS_URL}/${paymentId}`, null, token);

// Get All Payments
export const getAllPayments = (token) => makeApiCall("get", process.env.REACT_APP_PAYMENTS_URL, null, token);

// Update Payment
export const updatePayment = (paymentId, updatedData, token) => makeApiCall("put", `${process.env.REACT_APP_PAYMENTS_URL}/${paymentId}`, updatedData, token);

// Delete Payment
export const deletePayment = (paymentId, token) => makeApiCall("delete", `${process.env.REACT_APP_PAYMENTS_URL}/${paymentId}`, null, token);

// Create Rental Agreement
export const createRentalAgreement = (rentalAgreementData, token) => makeApiCall("post", process.env.REACT_APP_RENTAL_AGREEMENT_URL, rentalAgreementData, token);

// Get Rental Agreement by ID
export const getRentalAgreementById = (rentalId, token) => makeApiCall("get", `${process.env.REACT_APP_RENTAL_AGREEMENT_URL}/${rentalId}`, null, token);

// Get Rental Agreements by Customer ID
export const getRentalAgreementsByCustomerId = (customerId, token) => makeApiCall("get", `${process.env.REACT_APP_RENTAL_AGREEMENT_URL}/customer/${customerId}`, null, token);

// Get All Rental Agreements
export const getAllRentalAgreements = (token) => makeApiCall("get", process.env.REACT_APP_RENTAL_AGREEMENT_URL, null, token);

// Delete Rental Agreement
export const deleteRentalAgreement = (rentalId, token) => makeApiCall("delete", `${process.env.REACT_APP_RENTAL_AGREEMENT_URL}/${rentalId}`, null, token);

// Create Invoice
export const createInvoice = (invoiceData, token) => makeApiCall("post", process.env.REACT_APP_INVOICE_URL, invoiceData, token);

// Get Invoice by ID
export const getInvoiceById = (invoiceId, token) => makeApiCall("get", `${process.env.REACT_APP_INVOICE_URL}/${invoiceId}`, null, token);

// Get Invoices by Customer ID
export const getInvoicesByCustomerId = (customerId, token) => makeApiCall("get", `${process.env.REACT_APP_INVOICE_URL}/customer/${customerId}`, null, token);

// Get All Invoices
export const getAllInvoices = (token) => makeApiCall("get", process.env.REACT_APP_INVOICE_URL, null, token);

// Delete Invoice
export const deleteInvoice = (invoiceId, token) => makeApiCall("delete", `${process.env.REACT_APP_INVOICE_URL}/${invoiceId}`, null, token);

// Create a new review
export const createReview = (reviewDTO, token) => makeApiCall("post", process.env.REACT_APP_REVIEWS_URL, reviewDTO, token);

// Get a review by ID
export const getReviewById = (reviewId, token) => makeApiCall("get", `${process.env.REACT_APP_REVIEWS_URL}/${reviewId}`, null, token);

// Get all reviews
export const getAllReviews = (token) => makeApiCall("get", process.env.REACT_APP_REVIEWS_URL, null, token);

// Update a review
export const updateReview = (customerIdId, vehicleId, reviewDTO, token) => makeApiCall("put", `${process.env.REACT_APP_REVIEWS_URL}/${customerIdId}/${vehicleId}`, reviewDTO, token);

// Delete a review by ID
export const deleteReview = (customerIdId, vehicleId, token) => makeApiCall("delete", `${process.env.REACT_APP_REVIEWS_URL}/${customerIdId}/${vehicleId}`, null, token);

// Get reviews by vehicleId
export const getReviewsByVehicleId = (vehicleId, token) => makeApiCall("get", `${process.env.REACT_APP_REVIEWS_URL}/vehicle/${vehicleId}`, null, token);

// Get reviews by customerId
export const getReviewsByCustomerId = (customerId, token) => makeApiCall("get", `${process.env.REACT_APP_REVIEWS_URL}/customer/${customerId}`, null, token);

// Get average rating for a vehicle
export const getAverageRatingByVehicle = (vehicleId, token) => makeApiCall("get", `${process.env.REACT_APP_REVIEWS_URL}/average-rating/${vehicleId}`, null, token);

// Get total bookings
export const getTotalBookings = (token) => makeApiCall("get", `${process.env.REACT_APP_BOOKINGS_URL}/total-bookings`, null, token);

// Get total earnings
export const getTotalEarnings = (token) => makeApiCall("get", `${process.env.REACT_APP_BOOKINGS_URL}/total-earnings`, null, token);

// Get earnings by category type
export const getEarningsByCategoryType = (token) => makeApiCall("get", `${process.env.REACT_APP_BOOKINGS_URL}/earnings-by-category`, null, token);

// Get booking count by category type
export const getBookingCountByCategoryType = (token) => makeApiCall("get", `${process.env.REACT_APP_BOOKINGS_URL}/booking-count-by-category`, null, token);

// Get total drivers
export const getTotalDrivers = (token) => makeApiCall("get", `${process.env.REACT_APP_DRIVERS_URL}/total-drivers`, null, token);

// Get total customers
export const getTotalCustomers = (token) => makeApiCall("get", `${process.env.REACT_APP_USERS_URL}/total-customers`, null, token);

// Get total vehicles
export const getTotalVehicles = (token) => makeApiCall("get", `${process.env.REACT_APP_VEHICLES_URL}/total-vehicles`, null, token);