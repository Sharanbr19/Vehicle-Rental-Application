import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCookies } from "react-cookie";
import { forgotPassword, loginUser } from "../api/auth";
import { FaUser, FaLock, FaEye, FaEyeSlash } from "react-icons/fa";
import ResetPasswordModal from "../components/authentication/ResetPasswordModal";
import ForgotPasswordModal from "../components/authentication/ForgotPasswordModal";
import CryptoJS from "crypto-js";
import { toast } from "react-toastify";
const SECRET_KEY =
  "DbrTCGPmwy6YM/wK9zeZuJn289w/5PqtYF4arUAE2dUuP5vlFIpFEl31ks6o7WEf+fOqecX8cJHf2Yt/TWzUocD+ivaEh1bFC+J3YHP7sJHUmIjiuqKUujlgKlpD8XxKzVU0+vihkMQgLO0FbsxFYHLSR3X4oWu6RDHpFzRE+zfVYQlksLiBQJkn55NkbcPQKxzBpT6EeHbT3E7VLvUFpjQCWpEQ/oYFCUFx4WzXxZZt00Y0LT+0GJ5ajnJcAesoSNrZOcZx+Yb5gFq1YDB9l80gKQahTwIUfWa0rsPwk28=";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [, setCookie] = useCookies(["user", "role"]);
  const navigate = useNavigate();

  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [emailForReset, setEmailForReset] = useState("");

  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const decodeToken = (token) => {
    try {
      const base64Payload = token.split(".")[1];
      const payload = atob(base64Payload);
      return JSON.parse(payload);
    } catch (error) {
      console.error("Error decoding token:", error);
      return null;
    }
  };

  const encryptData = (data) => {
    return CryptoJS.AES.encrypt(data, SECRET_KEY).toString();
  };

  const emailValidationRegex =
    /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  const passwordValidationRegex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

  const handleSubmit = async (e) => {
    e.preventDefault();

    setEmailError("");
    setPasswordError("");

    if (email.length > 50) {
      setPasswordError("Email length should be less than 50.");
      return;
    }

    if (!emailValidationRegex.test(email)) {
      setEmailError("Please enter a valid email address.");
      return;
    }

    if (password.length > 25) {
      setPasswordError("Password length should be less than 25.");
      return;
    }

    if (!passwordValidationRegex.test(password)) {
      setPasswordError(
        "Password must be at least 8 characters long, include uppercase and lowercase letters, a number, and a special character."
      );
      return;
    }

    try {
      const credentials = { email, password };
      const token = await loginUser(credentials);

      if (token) {
        const decodedToken = decodeToken(token);
        if (!decodedToken) {
          setPasswordError("Invalid token received.");
          return;
        }
        const { role, sub: decodedEmail } = decodedToken;

        const encryptedRole = encryptData(role);

        setCookie("user", token, { path: "/", maxAge: 3600 });
        setCookie("role", encryptedRole, { path: "/", maxAge: 3600 });
        setCookie("email", decodedEmail, { path: "/", maxAge: 3600 });

        if (role === "ADMIN") {
          navigate("/admin");
          toast.success("Login Successful!");
        } else {
          navigate("/customer");
          toast.success("Login Successful!");
        }
      }
    } catch (error) {
      setPasswordError("Invalid credentials. Please try again.");
      console.error("Login error:", error);
    }
  };

  const handleForgotPasswordClick = () => {
    setShowForgotPassword(true);
    setEmailForReset(email);
  };

  const handleResetPasswordClick = () => {
    setEmailForReset(email);
    setShowForgotPassword(false);
    setShowResetPassword(true);
  };

  const handleForgotPassword = async (email) => {
    setEmailForReset(email);
    try {
      await forgotPassword(email);
      setShowForgotPassword(false);
      setShowResetPassword(true);
      toast.success("OTP sent successfully!");
    } catch (error) {
      toast.error("User with the provided email does not exist.");
    }
  };

  return (
    <React.Fragment>
      <div className="flex justify-center items-center min-h-[80vh] bg-gray-100">
        <div className="max-w-lg w-full p-6 bg-white shadow-lg rounded-lg">
          <h2 className="text-3xl font-semibold text-center mb-6">Login</h2>

          <form onSubmit={handleSubmit}>
            <div className="relative mb-4">
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-3 pl-10 border border-gray-300 rounded-md"
              />
              <FaUser className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
            </div>
            {emailError && (
              <p className="text-red-500 text-sm mb-3">{emailError}</p>
            )}

            <div className="relative mb-6">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-3 pl-10 border border-gray-300 rounded-md"
              />
              <FaLock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2"
              >
                {showPassword ? (
                  <FaEyeSlash className="text-gray-500" />
                ) : (
                  <FaEye className="text-gray-500" />
                )}
              </button>
            </div>
            {passwordError && (
              <p className="text-red-500 text-sm mb-3">{passwordError}</p>
            )}

            <button
              type="submit"
              className="w-full py-3 mb-3 bg-primary text-white rounded-md hover:bg-orange-700"
            >
              Login
            </button>

            <button
              type="button"
              onClick={() => handleForgotPasswordClick()}
              className="block text-center mt-2"
            >
              Forgot Password?
            </button>
            <button
              type="button"
              onClick={() => handleResetPasswordClick()}
              className="visibility: hidden"
            >
              Reset Password?
            </button>

            <ForgotPasswordModal
              show={showForgotPassword}
              onClose={() => setShowForgotPassword(false)}
              onSubmit={handleForgotPassword}
            />

            <ResetPasswordModal
              show={showResetPassword}
              email={emailForReset}
              onClose={() => setShowResetPassword(false)}
            />
          </form>
        </div>
      </div>
    </React.Fragment>
  );
}

export default Login;
