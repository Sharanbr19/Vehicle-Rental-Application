import React from "react";
import ErrorImage from "../assets/images/error404.png";
import Footer from "../components/common/Footer";

const PageNotFound = () => {
  return (
    <React.Fragment>
      <div className="flex flex-col md:flex-row items-center justify-center min-h-[80vh] bg-white p-4">
        <div className="md:w-1/2 text-center md:text-left pl-5 ml-5">
          <h1 className="text-8xl font-bold text-orange-500 mb-6">Oops :(</h1>
          <h2 className="text-4xl font-semibold text-yellow-400 mb-4">
            Sorry, the page not found
          </h2>
          <p className="text-gray-600 text-lg leading-relaxed">
            The link you followed is probably broken, <br />
            or the page has been removed.
          </p>
        </div>

        <div className="md:w-1/2 mt-8 md:mt-0 flex justify-center">
          <img
            src={ErrorImage}
            alt="404 Error"
            className="w-[200px] h-[400px] lg:w-[300px] xl:w-[400px] "
          />
        </div>
      </div>
    </React.Fragment>
  );
};

export default PageNotFound;
