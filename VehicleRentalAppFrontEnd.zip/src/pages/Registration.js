import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import {
  registerUser,
  checkEmailExists,
  sendOtpToEmail,
  verifyOtp,
} from "../api/auth";
import Modal from "react-modal";
import { ClipLoader } from "react-spinners";

Modal.setAppElement("#root");

function Register() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    contactNumber: "",
    addressHouse: "",
    addressCity: "",
    addressState: "",
    addressPincode: "",
    gender: "",
    dateOfBirth: "",
    nationality: "Indian",
  });

  const [formErrors, setFormErrors] = useState({});
  const [emailExists, setEmailExists] = useState(false);
  const [otp, setOtp] = useState("");
  const [isOtpModalOpen, setOtpModalOpen] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [otpError, setOtpError] = useState("");
  const [timer, setTimer] = useState(300);
  const [canResendOtp, setCanResendOtp] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const userType = "CUSTOMER";

  useEffect(() => {
    let countdown;
    if (timer > 0) {
      countdown = setInterval(() => setTimer((prev) => prev - 1), 1000);
    } else {
      setCanResendOtp(true);
    }
    return () => clearInterval(countdown);
  }, [timer]);

  const handleChange = async (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));

    if (name === "email") {
      try {
        await checkEmailExists(value);
        setEmailExists(false);
      } catch (error) {
        setEmailExists(true);
      }
    }
  };

  const passwordPattern =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/;
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const namePattern = /^[A-Za-z]+$/;

  const validate = () => {
    const errors = {};

    if (!formData.name) errors.name = "Name is required.";
    if (!namePattern.test(formData.name))
      errors.name = "Name should contain only alphabets.";
    if (formData.name.length < 3 || formData.name.length > 50)
      errors.name = "Name length should be between 3 to 50.";
    if (!formData.email) errors.email = "Email is required.";
    if (formData.email.length > 50)
      errors.email = "Email length should be less than 50 characters.";
    if (!emailPattern.test(formData.email))
      errors.email = "Please enter a valid email address.";
    if (emailExists) errors.email = "Email is already taken.";
    if (!formData.password) errors.password = "Password is required.";
    if (!passwordPattern.test(formData.password))
      errors.password =
        "Password must be at least 8 characters long, contain 1 lowercase, 1 uppercase letter, and 1 special character.";
    if (formData.password.length > 25)
      errors.password = "Password length should be less than 25 characters.";
    if (formData.password !== formData.confirmPassword)
      errors.confirmPassword = "Passwords do not match.";
    if (!formData.contactNumber)
      errors.contactNumber = "Contact number is required.";
    if (isNaN(formData.contactNumber))
      errors.contactNumber = "Contact number should contain only digits.";
    if (
      formData.contactNumber.length < 10 ||
      formData.contactNumber.length > 10
    )
      errors.contactNumber = "Phone number must be 10 digits";
    if (!formData.addressHouse)
      errors.addressHouse = "House address is required   |   ";
    if (!formData.addressCity) errors.addressCity = "City is required   |   ";
    if (!formData.addressState) errors.addressState = "State is required   |   ";
    if (!formData.addressPincode)
      errors.addressPincode = "Pincode is required.";

    if (formData.addressHouse.length > 100)
      errors.addressHouse = "House address should be less than 100 characters.";
    if (formData.addressCity.length > 50) errors.addressCity = "City must be less than 50 characters.";
    if (formData.addressState.length > 50) errors.addressState = "State must be less than 50 characters.";
    if (formData.addressPincode.length > 6 || formData.addressPincode.length < 6)
      errors.addressPincode = "Pincode must be exactly 6 digits.";
    if (isNaN(formData.addressPincode)){
      errors.addressPincode = "Pin code must contain only digits";
    }
    if (!formData.gender) errors.gender = "Gender is required.";
    if (!formData.dateOfBirth)
      errors.dateOfBirth = "Date of birth is required.";
    if (!formData.nationality) errors.nationality = "Nationality is required.";

    const currentDate = new Date();
    const dob = new Date(formData.dateOfBirth);
    const age = currentDate.getFullYear() - dob.getFullYear();
    if (age < 18) {
      errors.dateOfBirth = "You must be at least 18 years old to register.";
    }
    if (age > 100) {
      errors.dateOfBirth = "Your age must be less than 100 years to register.";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setIsLoading(true);

    try {
      await sendOtpToEmail(formData.email);
      toast.info("OTP sent to your email.");
      setOtpModalOpen(true);
      setTimer(300);
    } catch (error) {
      toast.error("Failed to send OTP. Please try again.");
    }

    setIsLoading(false);
  };

  const handleVerifyOtp = async () => {
    setIsVerifying(true);
    setOtpError("");

    try {
      if (!otp) {
        setOtpError("Please enter the OTP.");
        setIsVerifying(false);
        return;
      }

      await verifyOtp(formData.email, otp);
      await completeRegistration();
    } catch (error) {
      setOtpError("Invalid or expired OTP. Please try again.");
    }

    setIsVerifying(false);
  };

  const handleResendOtp = async () => {
    setCanResendOtp(false);
    setTimer(300);
    try {
      await sendOtpToEmail(formData.email);
      toast.info("OTP sent again to your email.");
    } catch (error) {
      toast.error("Failed to resend OTP. Please try again.");
    }
  };

  const completeRegistration = async () => {
    const {
      name,
      email,
      password,
      contactNumber,
      addressHouse,
      addressCity,
      addressState,
      addressPincode,
      gender,
      dateOfBirth,
      nationality,
    } = formData;

    const userData = {
      email,
      password,
      name,
      contactNumber,
      address: `${addressHouse}, ${addressCity}, ${addressState} - ${addressPincode}`,
      gender,
      userType,
      dateOfBirth,
      nationality,
    };

    try {
      await registerUser(userData);
      toast.success("Registration successful! You can now login.");
      setOtpModalOpen(false);
      setFormData({
        name: "",
        email: "",
        password: "",
        confirmPassword: "",
        contactNumber: "",
        addressHouse: "",
        addressCity: "",
        addressState: "",
        addressPincode: "",
        gender: "",
        dateOfBirth: "",
        nationality: "",
      });
    } catch (error) {
      toast.error("Registration failed. Try again.");
    }
  };

  return (
    <React.Fragment>
      <div className="flex justify-center items-center min-h-[80vh] bg-white px-0">
        <div className="w-full max-w-5xl p-6 bg-white shadow-none rounded-lg">
          <h2 className="text-3xl font-semibold text-center mb-6 text-orange-500">
            Registration Form
          </h2>
          <p className="font-semibold text-center mb-6 text-yellow-500">
            Please fill out this form for registration
          </p>
          <form onSubmit={handleRegister}>
            {/* Name */}
            <div className="mb-4 flex items-center">
              <label htmlFor="name" className="w-40 text-left">
                Name:
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Enter your name"
                className="flex-1 p-3 border border-gray-300 rounded-md"
              />
            </div>
            {formErrors.name && (
              <p className="text-red-500 text-sm pb-3">{formErrors.name}</p>
            )}

            {/* Email */}
            <div className="mb-4 flex items-center">
              <label htmlFor="email" className="w-40 text-left">
                Email:
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Enter your email"
                className="flex-1 p-3 border border-gray-300 rounded-md"
              />
            </div>
            {formErrors.email && (
              <p className="text-red-500 text-sm pb-3">{formErrors.email}</p>
            )}

            {/* Contact Number */}
            <div className="mb-4 flex items-center">
              <label htmlFor="contactNumber" className="w-40 text-left">
                Contact Number:
              </label>
              <input
                type="text"
                id="contactNumber"
                name="contactNumber"
                value={formData.contactNumber}
                onChange={handleChange}
                placeholder="Enter your contact number"
                className="flex-1 p-3 border border-gray-300 rounded-md"
              />
            </div>
            {formErrors.contactNumber && (
              <p className="text-red-500 text-sm pb-3">
                {formErrors.contactNumber}
              </p>
            )}

            {/* Date of Birth */}
            <div className="mb-4 flex items-center">
              <label htmlFor="dateOfBirth" className="w-40 text-left">
                Date of Birth:
              </label>
              <input
                type="date"
                id="dateOfBirth"
                name="dateOfBirth"
                value={formData.dateOfBirth}
                onChange={handleChange}
                className="flex-1 p-3 border border-gray-300 rounded-md"
              />
            </div>
            {formErrors.dateOfBirth && (
              <p className="text-red-500 text-sm pb-3">
                {formErrors.dateOfBirth}
              </p>
            )}

            {/* Gender */}
            <div className="mb-4 flex items-center">
              <label htmlFor="gender" className="w-40 text-left">
                Gender:
              </label>
              <select
                id="gender"
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                className="flex-1 p-3 border border-gray-300 rounded-md"
              >
                <option value="" disabled>
                  Select Gender
                </option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
            {formErrors.gender && (
              <p className="text-red-500 text-sm pb-3">{formErrors.gender}</p>
            )}

            {/* Address */}
            <div className="mb-4 flex items-center">
              <label htmlFor="addressPincode" className="w-40 text-left">
                Address:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-4 ml-3">
                <div className="flex-1">
                  <input
                    type="text"
                    name="addressHouse"
                    value={formData.addressHouse}
                    onChange={handleChange}
                    placeholder="Enter house address"
                    className="w-full p-3 border border-gray-300 rounded-md"
                  />
                </div>
                <div className="flex-1">
                  <input
                    type="text"
                    name="addressCity"
                    value={formData.addressCity}
                    onChange={handleChange}
                    placeholder="Enter city"
                    className="w-full p-3 border border-gray-300 rounded-md"
                  />
                </div>
                <div className="flex-1">
                  <input
                    type="text"
                    name="addressState"
                    value={formData.addressState}
                    onChange={handleChange}
                    placeholder="Enter state"
                    className="w-full p-3 border border-gray-300 rounded-md"
                  />
                </div>
                <div className="flex-1">
                  <input
                    type="text"
                    name="addressPincode"
                    value={formData.addressPincode}
                    onChange={handleChange}
                    placeholder="Enter pincode"
                    className="w-full p-3 border border-gray-300 rounded-md"
                  />
                </div>
              </div>
            </div>
            {(formErrors.addressHouse ||
              formErrors.addressCity ||
              formErrors.addressState ||
              formErrors.addressPincode) && (
              <p className="text-red-500 text-sm pb-3">
                {formErrors.addressHouse}
                {formErrors.addressCity}
                {formErrors.addressState}
                {formErrors.addressPincode}
              </p>
            )}

            {/* Password */}
            <div className="mb-4 flex items-center">
              <label htmlFor="password" className="w-40 text-left">
                Password:
              </label>
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Enter your password"
                className="flex-1 p-3 border border-gray-300 rounded-md"
              />
            </div>
            {formErrors.password && (
              <p className="text-red-500 text-sm pb-3">{formErrors.password}</p>
            )}

            {/* Confirm Password */}
            <div className="mb-4 flex items-center">
              <label htmlFor="confirmPassword" className="w-40 text-left">
                Confirm Password:
              </label>
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                placeholder="Confirm your password"
                className="flex-1 p-3 border border-gray-300 rounded-md pb-3"
              />
            </div>
            {formErrors.confirmPassword && (
              <p className="text-red-500 text-sm pb-5">
                {formErrors.confirmPassword}
              </p>
            )}

            <button
              type="submit"
              className="w-1/4 py-3 bg-primary text-white rounded-md hover:bg-orange-700 mt-4 mx-auto block"
            >
              {isLoading ? (
                <ClipLoader size={20} color="#fff" loading={isLoading} />
              ) : (
                "Register"
              )}
            </button>
          </form>

          {/* OTP Modal */}
          <Modal
            isOpen={isOtpModalOpen}
            onRequestClose={() => setOtpModalOpen(false)}
            className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-75"
          >
            <div className="relative bg-white p-6 rounded-lg shadow-lg font-semibold w-96">
              <button
                className="text-red-500 text-2xl absolute top-2 right-6"
                onClick={() => {
                  setOtpModalOpen(false);
                }}
              >
                X
              </button>
              <h2 className="text-xl font-semibold mb-2">Enter OTP</h2>
              <p className="mb-4">
                We have sent an OTP to your email: {formData.email}
              </p>
              <input
                type="text"
                placeholder="Enter OTP"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                className="border p-2 w-full rounded"
              />
              {otpError && <p className="text-red-500 mt-2">{otpError}</p>}

              <div className="flex justify-between text-blue-700 mt-2 ps-2">
                <span>
                  {timer > 0
                    ? `${Math.floor(timer / 60)}:${String(timer % 60).padStart(
                        2,
                        "0"
                      )}`
                    : ""}
                </span>
                {timer === 0 && (
                  <button
                    onClick={handleResendOtp}
                    className="text-blue-500"
                    disabled={isVerifying || !canResendOtp}
                  >
                    Resend OTP
                  </button>
                )}
              </div>

              <button
                onClick={handleVerifyOtp}
                className="bg-green-500 text-white p-3 cursor-pointer rounded w-full mt-4"
              >
                {isVerifying ? "Verifying..." : "Verify Email"}
              </button>
            </div>
          </Modal>
        </div>
      </div>
    </React.Fragment>
  );
}

export default Register;
