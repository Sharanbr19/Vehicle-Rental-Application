import React from "react";
import Navbar from "../components/Navbar";

const AboutUs = () => {
  return (
    <React.Fragment>
      <Navbar />
      <div className="bg-gray-100 text-gray-800">
        <div className="container mx-auto py-12 px-6">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-orange-600">About Us</h1>
            <p className="text-lg text-gray-600 mt-4">
              Welcome to our Vehicle Rental App, your trusted partner for convenient and reliable transportation solutions.
            </p>
          </div>

          {/* About Section */}
          <div className="bg-white p-8 rounded-lg shadow-lg mb-10">
            <h2 className="text-2xl font-semibold text-orange-500 mb-4">Who We Are</h2>
            <p className="text-gray-700 leading-relaxed">
              Established in 2010, we are committed to offering hassle-free vehicle rental services to individuals and businesses alike. Our platform connects users with a wide range of vehicles, from compact cars to luxury SUVs, ensuring that every travel need is met with ease and efficiency.
            </p>
          </div>

          {/* Services Section */}
          <div className="bg-white p-8 rounded-lg shadow-lg mb-10">
            <h2 className="text-2xl font-semibold text-orange-500 mb-4">Our Services</h2>
            <ul className="list-disc list-inside text-gray-700">
              <li className="mb-2">Wide range of vehicles for daily, weekly, and monthly rentals.</li>
              <li className="mb-2">Flexible rental plans to suit your needs.</li>
              <li className="mb-2">Seamless booking process with real-time availability checks.</li>
              <li className="mb-2">24/7 customer support for a stress-free experience.</li>
              <li>Special offers and discounts for corporate clients and frequent renters.</li>
            </ul>
          </div>

          {/* Clients Section */}
          <div className="bg-white p-8 rounded-lg shadow-lg mb-10">
            <h2 className="text-2xl font-semibold text-orange-500 mb-4">Our Clients</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              We are proud to serve a diverse clientele that includes:
            </p>
            <ul className="list-disc list-inside text-gray-700">
              <li className="mb-2">Tourists looking for short-term rentals.</li>
              <li className="mb-2">Corporate businesses requiring fleet solutions.</li>
              <li className="mb-2">Event planners seeking transportation for special occasions.</li>
              <li className="mb-2">Frequent travelers and commuters.</li>
              <li>Local residents needing temporary vehicle solutions.</li>
            </ul>
          </div>

          {/* About the App Section */}
          <div className="bg-white p-8 rounded-lg shadow-lg">
            <h2 className="text-2xl font-semibold text-orange-500 mb-4">About Our Vehicle Rental App</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              Our app is designed with user-friendliness and efficiency in mind. With an intuitive interface and powerful features, it allows users to:
            </p>
            <ul className="list-disc list-inside text-gray-700 mb-4">
              <li className="mb-2">Browse and compare a wide range of vehicles.</li>
              <li className="mb-2">Check real-time availability and pricing.</li>
              <li className="mb-2">Securely book vehicles in just a few clicks.</li>
              <li className="mb-2">Track and manage bookings effortlessly.</li>
              <li>Receive instant support through our in-app chat feature.</li>
            </ul>
            <p className="text-gray-700 leading-relaxed">
              Join thousands of satisfied customers who trust our app for their rental needs. Whether you need a vehicle for a day or a month, our platform ensures a smooth and reliable experience from start to finish.
            </p>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default AboutUs;
