import React, { useEffect, useState } from "react";
import { replace, useLocation, useNavigate } from "react-router-dom";
import { NavLink } from "react-router-dom";
import {
  getVehicleById,
  createPayment,
  createRentalAgreement,
  createInvoice,
  getInvoiceById,
  getRentalAgreementById,
  getUserByEmail,
  deleteBooking,
  updateBooking,
} from "../api/auth";
import Cookies from "js-cookie";
import { toast } from "react-toastify";
import jsPDF from "jspdf";
import { Download } from "lucide-react";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import { FaUser, FaCar, FaEdit, FaTrash } from "react-icons/fa";

const ConfirmBooking = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const [policyAccepted, setPolicyAccepted] = useState(false);
  const [customerModalOpen, setCustomerModalOpen] = useState(false);
  const [vehicleModalOpen, setVehicleModalOpen] = useState(false);
  const [errors, setErrors] = useState({});
  const [bookingData, setBookingData] = useState(state?.bookingData);
  const [vehicleDetails, setVehicleDetails] = useState(null);
  const [customerData, setCustomerData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [invoice, setInvoice] = useState(null);
  const [rentalAgreement, setRentalAgreement] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);

  const [showEditModal, setShowEditModal] = useState(false);
  const [updatedBookingData, setUpdatedBookingData] = useState(bookingData);

  const locations = ["MG Road", "Whitefield", "Majestic", "Kormangala"];

  const token = Cookies.get("user");
  const email = Cookies.get("email");

  useEffect(() => {
    const fetchData = async () => {
      try {
        if (!token || !bookingData?.vehicleId || !email) {
          console.log(token);
          console.log(bookingData?.vehicleId);
          console.log(email);

          throw new Error("Missing token, vehicle ID, or email");
        }

        const [vehicleResponse, customerResponse] = await Promise.all([
          getVehicleById(bookingData.vehicleId, token),
          getUserByEmail(email, token),
        ]);

        setVehicleDetails(vehicleResponse);
        setCustomerData(customerResponse);
      } catch (err) {
        setError(err.message || "Failed to fetch details.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [bookingData, email, token]);

  const handlePayment = async () => {
    try {
      if (!window.Razorpay) throw new Error("Razorpay SDK not loaded");

      const options = {
        key: "rzp_test_B6Fc2rOFUPCcQt",
        amount: bookingData.totalCost * 100,
        currency: "INR",
        name: "Vehicle Rental Application",
        description: "Payment for Vehicle Booking",
        handler: async (response) => {
          setLoading(true);

          const paymentData = {
            razorPayId: response.razorpay_payment_id,
            amount: bookingData.totalCost,
            paymentDateAndTime: new Date().toISOString(),
            bookingId: bookingData.bookingId,
          };

          await createPayment(paymentData, token);

          const rentalAgreementData = {
            agreementDate: new Date().toISOString().split("T")[0],
            termsAndConditions: "",
            bookingId: bookingData.bookingId,
          };

          const invoiceData = {
            invoiceDate: new Date().toISOString().split("T")[0],
            totalAmount: bookingData.totalCost,
            bookingId: bookingData.bookingId,
          };

          const [rentalAgreementResponse, invoiceResponse] = await Promise.all([
            createRentalAgreement(rentalAgreementData, token),
            createInvoice(invoiceData, token),
          ]);

          const [fetchedRentalAgreement, fetchedInvoice] = await Promise.all([
            getRentalAgreementById(rentalAgreementResponse.rentalId, token),
            getInvoiceById(invoiceResponse.invoiceId, token),
          ]);

          setRentalAgreement(fetchedRentalAgreement);
          setInvoice(fetchedInvoice);

          toast.success("Payment successful! Booking confirmed.");

          setTimeout(() => {
            setLoading(false);
            setShowModal(true);
          }, 1500);
        },
        prefill: {
          name: customerData?.name || "User",
          email: email,
          contact: customerData?.contact || "",
        },
        notes: {
          bookingId: bookingData.bookingId,
        },
        theme: {
          color: "#00efef",
        },
      };

      const razorpay = new window.Razorpay(options);
      razorpay.open();
    } catch (error) {
      setLoading(false);
      toast.error(error.message || "Payment failed. Try again.");
    }
  };

  const validateForm = () => {
    let newErrors = {};

    if (!/^\d{12}$/.test(updatedBookingData.customerAadharNumber)) {
      newErrors.aadhar = "Aadhar number must be exactly 12 digits.";
    }

    if (
      !updatedBookingData.wantsDriver &&
      !/^[A-Z]{2}[0-9]{2} [0-9]{12}$/.test(
        updatedBookingData.customerDrivingLicenseNumber
      )
    ) {
      newErrors.license =
        "Invalid format: AA00 000000000000 (2 letters, 2 digits, space, 12 digits)";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const generatePDF = (type) => {
    const doc = new jsPDF();

    if (type === "rental") {
      doc.setDrawColor(0);
      doc.setLineWidth(0.5);
      doc.rect(5, 5, 200, 287);

      doc.setFontSize(18);
      doc.setFont("helvetica", "bold");
      doc.text("Vehicle Rental Agreement", 70, 15);
      doc.setFont("helvetica", "normal");

      doc.setFontSize(12);
      doc.text(`Agreement Date: ${rentalAgreement.agreementDate}`, 10, 35);

      doc.setFontSize(14);
      doc.text("Owner Information:", 10, 45);
      doc.setFontSize(12);
      doc.text(`Name: Rent Wheels`, 10, 52);
      doc.text(`Contact: 9740234550`, 10, 58);
      doc.text(
        `Address: Kumbena Agrahara, Kadugodi, Bangalore - 560001`,
        10,
        64
      );

      doc.setFontSize(14);
      doc.text("Renter Information:", 10, 75);
      doc.setFontSize(12);
      doc.text(`Name: ${customerData.name}`, 10, 82);
      doc.text(`Contact: ${customerData.contactNumber}`, 10, 88);
      doc.text(`Address: ${customerData.address}`, 10, 94);

      doc.setFontSize(14);
      doc.text("Vehicle Details:", 10, 105);
      doc.setFontSize(12);
      doc.text(`Model: ${vehicleDetails.modelName}`, 10, 112);
      doc.text(
        `Registration Number: ${vehicleDetails.registrationNumber}`,
        10,
        118
      );
      doc.text(`Insurance Number: ${vehicleDetails.insuranceNumber}`, 10, 124);

      doc.text(`Rental Start Date: ${bookingData.fromDate}`, 10, 130);
      doc.text(`Rental End Date: ${bookingData.toDate}`, 10, 136);

      doc.setFontSize(14);
      doc.text("Terms & Conditions:", 10, 150);
      doc.setFontSize(12);
      const terms = [
        "1. The renter agrees to return the vehicle in the same condition as received.",
        "2. Any damage to the vehicle will be the responsibility of the renter to pay full amount of the damage",
        "caused.",
        "3. The vehicle should not be used for illegal activities.",
        "4. The owner is not responsible for any traffic violations.",
        "5. Fuel costs are to be borne by the renter.",
        "6. Vehicle should be returned by the end of returning date",
        "7. Additional fine shall be paid by the customer for late return including complete booking cost of other",
        "customers booked for the same vehicle.",
      ];
      let y = 158;
      terms.forEach((term) => {
        doc.text(term, 10, y);
        y += 6;
      });

      doc.setFontSize(12);
      doc.text("Owner Signature:", 10, y + 10);
      doc.line(50, y + 10, 80, y + 10);
      doc.text("Renter Signature:", 120, y + 10);
      doc.line(160, y + 10, 190, y + 10);

      doc.save(
        `Rental_Agreement_${rentalAgreement.agreementDate}_${rentalAgreement.bookingId}.pdf`
      );
    } else {
      doc.setDrawColor(0);
      doc.setLineWidth(0.5);
      doc.rect(5, 5, 200, 287);

      doc.setFontSize(18);
      doc.setFont("helvetica", "bold");
      doc.text("Invoice", 100, 15);
      doc.setFont("helvetica", "normal");

      doc.setFontSize(12);
      doc.text(`Invoice Date: ${invoice.invoiceDate}`, 10, 25);
      doc.text(`Booking ID: ${invoice.bookingId}`, 10, 35);
      doc.text(`Total Amount: Rs. ${invoice.totalAmount}`, 10, 45);

      doc.setFontSize(14);
      doc.text("Customer Information:", 10, 60);
      doc.setFontSize(12);
      doc.text(
        `Name: ${customerData.name}                 Email: ${customerData.email}                 Contact: ${customerData.contactNumber}`,
        10,
        70
      );
      doc.text(`Address: ${customerData.address}`, 10, 80);

      doc.setFontSize(14);
      doc.text("Vehicle Details:", 10, 95);
      doc.setFontSize(12);
      doc.text(
        `Vehicle: ${vehicleDetails.modelName} (${vehicleDetails.categoryType})`,
        10,
        105
      );
      doc.text(
        `Registration Number: ${vehicleDetails.registrationNumber}`,
        10,
        115
      );

      doc.setFontSize(14);
      doc.text("Rental Dates:", 10, 130);
      doc.setFontSize(12);
      doc.text(`Start Date: ${bookingData.fromDate}`, 10, 140);
      doc.text(`End Date: ${bookingData.toDate}`, 10, 150);

      doc.setFontSize(14);
      doc.text("Invoice Table", 10, 170);

      const header = ["Item", "Cost per Day", "No. of Days", "Total Cost"];
      let y = 180;
      const tableX = 10;

      header.forEach((headerItem, index) => {
        doc.setFont("helvetica", "bold");
        const xPos = tableX + index * 40;
        doc.text(headerItem, xPos + 10, y + 5);
      });
      doc.rect(8, 175, 40, 15);
      doc.rect(48, 175, 50, 15);
      doc.rect(128, 175, 70, 15);
      doc.setFont("helvetica", "normal");

      const noOfDays = Math.ceil(
        (new Date(bookingData.toDate) - new Date(bookingData.fromDate)) /
          (1000 * 3600 * 24) +
          1
      );
      const vehicleCost = vehicleDetails.pricePerDay;
      const driverCost = invoice.totalAmount / noOfDays - vehicleCost;

      const tableData = [
        [
          "Vehicle",
          `Rs. ${vehicleCost}`,
          `${noOfDays}`,
          `Rs. ${vehicleCost * noOfDays}`,
        ],
        [
          "Driver",
          `Rs. ${driverCost}`,
          `${noOfDays}`,
          `Rs. ${driverCost * noOfDays}`,
        ],
      ];

      let rowY = y + 15;
      tableData.forEach((row, rowIndex) => {
        let cellX = tableX;
        row.forEach((cell, colIndex) => {
          const cellWidth = 45;
          doc.text(cell, cellX + 5, rowY + 5);
          cellX += cellWidth;
        });
        rowY += 15;
      });
      doc.rect(8, 190, 40, 15);
      doc.rect(48, 205, 50, 15);
      doc.rect(128, 205, 70, 15);
      doc.rect(98, 190, 30, 15);

      doc.rect(tableX - 2, y - 5, 190, rowY - y);

      const netTotal = invoice.totalAmount;
      doc.setFont("helvetica", "bold");
      doc.text(`Net Total: Rs. ${netTotal}`, 10, rowY + 10);

      doc.setFontSize(12);
      doc.setFont("helvetica", "normal");
      doc.text("This is a system-generated invoice.", 10, rowY + 30);
      doc.text("Thank you and book a vehicle for rent again.", 10, rowY + 40);

      doc.save(`Invoice_${invoice.invoiceDate}_${invoice.bookingId}.pdf`);
    }
  };

  if (error) return <p className="text-red-500">{error}</p>;

  const handleCloseModal = () => {
    setShowModal(false);
    navigate("/customer", { replace: true });
  };

  const handleEditBooking = () => {
    setShowEditModal(true);
  };

  const handleOpenCustomerModal = () => {
    setCustomerModalOpen(true);
  };

  const handleCloseCustomerModal = () => {
    setCustomerModalOpen(false);
  };

  const handleOpenVehicleModal = () => {
    setVehicleModalOpen(true);
  };

  const handleCloseVehicleModal = () => {
    setVehicleModalOpen(false);
  };

  const handleSaveChanges = async () => {
    if (validateForm()) {
      try {
        const response = await updateBooking(
          bookingData.bookingId,
          updatedBookingData,
          token
        );
        setBookingData(response);
        toast.success("Booking updated successfully.");
        setShowEditModal(false);
        console.log(bookingData);
      } catch (error) {
        toast.error("Failed to update booking. Try again.");
      }
    }
  };

  const handleOpenDialog = () => {
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleConfirmCancel = async () => {
    try {
      await deleteBooking(bookingData.bookingId, token);
      toast.success("Booking cancelled successfully.");
      navigate("/customer");
    } catch (error) {
      toast.error("Failed to cancel booking. Try again.");
    }
    setOpenDialog(false);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto min-h-[90vh] bg-white">
      <button
        onClick={() => navigate("/customer", { replace: true })}
        className="bg-orange-500 text-white px-4 py-2 rounded mb-4"
      >
        Back to Dashboard
      </button>

      {bookingData && vehicleDetails ? (
        <div className="mt-12">
          <div className="flex flex-col md:flex-row bg-white border rounded-lg shadow-lg overflow-hidden">
            <div className="md:w-1/3 flex justify-center items-center">
              <img
                src={vehicleDetails.vehicleImageURL}
                alt={vehicleDetails.modelName}
                className="w-full h-52 object-contain rounded-md"
              />
            </div>

            <div className="md:w-1/3 p-4 flex flex-col justify-center">
              <h3 className="text-lg font-semibold mb-2">Booking Details</h3>
              <p>
                <strong className="pr-20 mr-1">Vehicle:</strong>
                {vehicleDetails.modelName} ({vehicleDetails.categoryType})
              </p>
              <p>
                <strong className="pr-16 mr-1">Location:</strong>{" "}
                {bookingData.location}
              </p>
              <p>
                <strong className="pr-14">From Date:</strong>{" "}
                {new Date(bookingData.fromDate).toDateString()}
              </p>
              <p>
                <strong className="pr-16 mr-3">To Date:</strong>{" "}
                {new Date(bookingData.toDate).toDateString()}
              </p>
              <p>
                <strong className="pr-14 mr-1">Total Cost:</strong> Rs.{" "}
                {bookingData.totalCost}
              </p>
              <p>
                <strong className="pr-9">Wants Driver:</strong>{" "}
                {bookingData.wantsDriver ? "Yes" : "No"}
              </p>
              <p>
                <strong className="pr-3">Aadhar Number:</strong>{" "}
                {bookingData.customerAadharNumber}
              </p>
              {!bookingData.wantsDriver && (
                <p>
                  <strong className="pr-5">Driving License:</strong>{" "}
                  {bookingData.customerDrivingLicenseNumber}
                </p>
              )}
            </div>

            <div className="md:w-1/3 p-4 flex flex-col ps-16 justify-center space-y-4">
              <button
                onClick={handleOpenCustomerModal}
                className="flex items-center ps-2 justify-start bg-white border border-blue-500 rounded hover:bg-blue-100 w-2/3 h-12"
              >
                <FaUser className="text-blue-500" size={20} />
                <p className="pl-5">View Customer Details</p>{" "}
              </button>
              <button
                onClick={handleOpenVehicleModal}
                className="flex items-center  ps-2 justify-start bg-white border border-green-500 rounded hover:bg-green-100 w-2/3 h-12"
              >
                <FaCar className="text-green-500" size={20} />
                <p className="pl-5">View Vehicle Details</p>{" "}
              </button>
              <button
                onClick={handleEditBooking}
                className="flex items-center  ps-2 justify-start  bg-white border border-yellow-500 rounded hover:bg-yellow-100 w-2/3 h-12"
              >
                <FaEdit className="text-yellow-500" size={20} />
                <p className="pl-5">Edit Booking Details</p>{" "}
              </button>
              <button
                onClick={handleOpenDialog}
                className="flex items-center  ps-2 justify-start bg-white border border-red-500 rounded hover:bg-red-100 w-2/3 h-12"
              >
                <FaTrash className="text-red-500" size={20} />
                <p className="pl-5">Cancel Booking</p>{" "}
              </button>

              {/* Cancel Booking Confirmation Dialog */}
              <Dialog open={openDialog} onClose={handleCloseDialog}>
                <DialogTitle>Cancel Booking</DialogTitle>
                <DialogContent>
                  Are you sure you want to cancel this booking?
                </DialogContent>
                <DialogActions>
                  <Button onClick={handleCloseDialog} color="primary">
                    No, Don't Cancel
                  </Button>
                  <Button onClick={handleConfirmCancel} color="error" autoFocus>
                    Yes, Cancel Booking
                  </Button>
                </DialogActions>
              </Dialog>
            </div>
          </div>
        </div>
      ) : (
        <p>No booking data available.</p>
      )}

      <div className="mt-8">
        <input
          type="checkbox"
          id="policyAccepted"
          className="mr-2 p-3 cursor-pointer"
          checked={policyAccepted}
          onChange={(e) => setPolicyAccepted(e.target.checked)}
        />
        <label htmlFor="policyAccepted" className="text-md cursor-pointer">
          I hereby declare that all the details provided in this booking are
          accurate, true, and complete to the best of my knowledge. I have
          carefully read, understood, and agree to the{" "}
          <NavLink to="/policies" className="text-blue-500 hover:underline">
            policy
          </NavLink>
          .
        </label>
      </div>

      <div className="flex items-center justify-center mt-4">
        <button
          onClick={handlePayment}
          disabled={!policyAccepted}
          className={`bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 ${
            !policyAccepted ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          Make Payment
        </button>
      </div>

      {/* Customer Details Modal */}
      {customerModalOpen && customerData && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="relative bg-white p-6 rounded-lg w-1/3">
            <button
              onClick={handleCloseCustomerModal}
              className="absolute top-2 right-4 text-red-500 font-semibold text-2xl px-2 py-1 rounded-full"
            >
              X
            </button>
            <h2 className="text-xl font-bold mb-4">Customer Details</h2>
            <p>
              <strong>Name:</strong> {customerData.name}
            </p>
            <p>
              <strong>Email:</strong> {customerData.email}
            </p>
            <p>
              <strong>Gender:</strong> {customerData.gender}
            </p>
            <p>
              <strong>Contact:</strong> {customerData.contactNumber}
            </p>
            <p>
              <strong>Date Of Birth:</strong> {customerData.dateOfBirth}
            </p>
            <p>
              <strong>Address:</strong> {customerData.address}
            </p>
          </div>
        </div>
      )}

      {/* Vehicle Details Modal */}
      {vehicleModalOpen && vehicleDetails && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="relative bg-white p-6 rounded-lg w-1/3">
            <button
              onClick={handleCloseVehicleModal}
              className="absolute top-2 right-4 text-red-500 font-semibold text-2xl px-2 py-1 rounded-full"
            >
              X
            </button>
            <h2 className="text-xl font-bold mb-4">Vehicle Details</h2>
            <p>
              <strong>Model:</strong> {vehicleDetails.modelName}
            </p>
            <p>
              <strong>Mileage:</strong> {vehicleDetails.mileage} km/litre
            </p>
            <p>
              <strong>Category:</strong> {vehicleDetails.categoryType}
            </p>
            <p>
              <strong>Fuel Type:</strong> {vehicleDetails.fuelType}
            </p>
            <p>
              <strong>Model Year:</strong> {vehicleDetails.modelYear}
            </p>
            <p>
              <strong>Price Per Day:</strong> ₹{vehicleDetails.pricePerDay}
            </p>
            <p>
              <strong>Features:</strong> {vehicleDetails.featureDescription}
            </p>
          </div>
        </div>
      )}

      {/* Modal */}
      {loading ? (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-75">
          <div className="bg-white p-6 rounded-md shadow-lg flex flex-col items-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-orange-500"></div>
            <p className="mt-4 text-lg font-semibold">Processing Payment...</p>
          </div>
        </div>
      ) : (
        showModal && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-75">
            <div className="bg-white p-6 rounded-md shadow-lg relative max-w-sm h-50">
              <button
                onClick={handleCloseModal}
                className="absolute top-2 right-4 text-red-600 text-3xl"
              >
                ×
              </button>
              <h2 className="text-lg text-center font-semibold mb-8">
                Download Documents
              </h2>
              <button
                onClick={() => generatePDF("invoice")}
                className="bg-orange-500 text-white px-4 py-2 rounded mb-4 w-full flex justify-between items-center"
              >
                Download Invoice
                <Download className="ml-6 text-white" size={20} />
              </button>
              <button
                onClick={() => generatePDF("rental")}
                className="bg-orange-500 text-white px-4 py-2 rounded w-full flex justify-between items-center"
              >
                Download Rental Agreement
                <Download className="text-white ml-6" size={20} />
              </button>
            </div>
          </div>
        )
      )}

      {showEditModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-75">
          <div className="bg-white p-6 rounded-md shadow-lg relative max-w-md w-full">
            <button
              onClick={() => setShowEditModal(false)}
              className="absolute top-2 right-4 text-red-600 text-4xl"
            >
              ×
            </button>

            <h2 className="text-xl text-orange-500 text-center font-semibold mb-6">
              Edit Booking
            </h2>

            <label className="block mb-2">Location:</label>
            <select
              name="location"
              value={updatedBookingData.location}
              onChange={(e) =>
                setUpdatedBookingData({
                  ...updatedBookingData,
                  location: e.target.value,
                })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
            >
              <option disabled="true" value="">
                Select Location
              </option>
              {locations.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>

            <label className="block mb-2">Aadhar Number:</label>
            <input
              type="text"
              value={updatedBookingData.customerAadharNumber}
              onChange={(e) =>
                setUpdatedBookingData({
                  ...updatedBookingData,
                  customerAadharNumber: e.target.value,
                })
              }
              className={`w-full p-2 border rounded mb-1 ${
                errors.aadhar ? "border-red-500" : ""
              }`}
              placeholder="Enter your Aadhar number"
            />
            {errors.aadhar && (
              <p className="text-red-500 text-sm">{errors.aadhar}</p>
            )}

            <label className="block mt-4 mb-2">Need a Driver?</label>
            <div className="flex gap-4 mb-4">
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="wantsDriver"
                  checked={updatedBookingData.wantsDriver}
                  onChange={() =>
                    setUpdatedBookingData({
                      ...updatedBookingData,
                      wantsDriver: true,
                    })
                  }
                />
                Yes
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="wantsDriver"
                  checked={!updatedBookingData.wantsDriver}
                  onChange={() =>
                    setUpdatedBookingData({
                      ...updatedBookingData,
                      wantsDriver: false,
                    })
                  }
                />
                No
              </label>
            </div>

            {!updatedBookingData.wantsDriver && (
              <div>
                <label className="block mb-2">Driving License:</label>
                <input
                  type="text"
                  value={updatedBookingData.customerDrivingLicenseNumber}
                  onChange={(e) =>
                    setUpdatedBookingData({
                      ...updatedBookingData,
                      customerDrivingLicenseNumber: e.target.value,
                    })
                  }
                  className={`w-full p-2 border rounded mb-1 ${
                    errors.license ? "border-red-500" : ""
                  }`}
                  placeholder="Enter your driving license number"
                />
                {errors.license && (
                  <p className="text-red-500 text-sm">{errors.license}</p>
                )}
              </div>
            )}

            <button
              onClick={handleSaveChanges}
              className="bg-orange-500 text-white px-4 py-2 rounded w-full mt-4"
            >
              Save Changes
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConfirmBooking;
