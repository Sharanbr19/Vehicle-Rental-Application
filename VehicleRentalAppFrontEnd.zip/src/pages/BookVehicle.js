import React, { useState, useEffect } from "react";
import { replace, useNavigate, useParams } from "react-router-dom";
import Sedan from "../assets/images/vehicles/sedan.png";
import { toast } from "react-toastify";
import { FaUser } from "react-icons/fa";

import {
  getVehicleById,
  getBookingByVehicleId,
  createBooking,
  getUserByEmail,
  getReviewsByVehicleId,
  getUserById,
} from "../api/auth";
import Cookies from "js-cookie";
import { renderStar } from "../components/renderStar";
import StarRating from "../components/StarRating";

const BookVehicle = () => {
  const { vehicleId } = useParams();
  const [vehicle, setVehicle] = useState({});
  const [formData, setFormData] = useState({
    location: "",
    fromDate: null,
    toDate: null,
    customerAadharNumber: "",
    customerDrivingLicenseNumber: "",
    wantsDriver: false,
    paymentCompleted: false,
    customerId: null,
    vehicleId: vehicleId,
    totalCost: "",
  });
  const [errors, setErrors] = useState({});
  const [bookedDates, setBookedDates] = useState([]);
  const [userId, setUserId] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [reviewers, setReviewers] = useState({});
  const navigate = useNavigate();

  const locations = ["Whitefield", "Koramangala", "Majestic", "MG Road"];
  const token = Cookies.get("user");
  const email = Cookies.get("email");

  useEffect(() => {
    const storedFromDate = localStorage.getItem("fromDate");
    const storedToDate = localStorage.getItem("toDate");
    try {
      if (!token) {
        console.log(token);
        throw new Error("Missing token, vehicle ID, or email");
      }
    } catch (err) {
      console.log(err.message || "Failed to fetch details.");
    }

    if (storedFromDate && storedToDate) {
      setFormData((prevData) => ({
        ...prevData,
        fromDate: new Date(storedFromDate),
        toDate: new Date(storedToDate),
      }));
    }

    getUserByEmail(email, token)
      .then((response) => {
        if (response) {
          setUserId(response.userId);
          setFormData((prevData) => ({
            ...prevData,
            customerId: response.userId,
          }));
        }
      })
      .catch((error) => {
        console.error("Error fetching user data:", error);
      });

    getVehicleById(vehicleId, token)
      .then((response) => {
        if (response) {
          setVehicle(response);
        }
      })
      .catch((error) => {
        console.error("Error fetching vehicle data:", error);
      });

    getBookingByVehicleId(vehicleId, token)
      .then((response) => {
        if (response && response.data) {
          const { bookedDates } = response;
          setBookedDates(bookedDates);
        }
      })
      .catch((error) => {
        console.error("Error fetching booked dates:", error);
      });

    getReviewsByVehicleId(vehicleId, token)
      .then((response) => {
        if (response) {
          setReviews(response);

          response.forEach((review) => {
            if (!reviewers[review.customerId]) {
              getUserById(review.customerId, token)
                .then((userData) => {
                  setReviewers((prev) => ({
                    ...prev,
                    [review.customerId]: {
                      name: userData.name,
                      email: userData.email,
                    },
                  }));
                })
                .catch((error) => {
                  console.error(
                    `Error fetching user data for review ${review.customerId}:`,
                    error
                  );
                });
            }
          });
        }
      })
      .catch((error) => {
        console.error("Error fetching reviews:", error);
      });
  }, [vehicleId, email, token]);

  const validate = () => {
    let formErrors = {};
    const aadharRegex = /^[0-9]{12}$/;
    const licenseRegex = /^[A-Za-z]{2}[0-9]{2} [0-9]{12}$/;

    if (!aadharRegex.test(formData.customerAadharNumber))
      formErrors.customerAadharNumber = "Aadhar number must be 12 digits.";
    if (
      formData.fromDate &&
      formData.toDate &&
      new Date(formData.fromDate) > new Date(formData.toDate)
    )
      formErrors.dateRange = "From date must be before To date.";
    if (
      !licenseRegex.test(formData.customerDrivingLicenseNumber) &&
      !formData.wantsDriver
    )
      formErrors.customerDrivingLicenseNumber =
        "Invalid license number Format: AA00 000000000000.(2 letters, 2 digits, space, 12 digits)";
    if (!formData.location) formErrors.location = "Please select a location.";

    setErrors(formErrors);
    return Object.keys(formErrors).length === 0;
  };

  const handleProceed = () => {
    if (validate()) {
      const bookingData = {
        customerId: formData.customerId,
        vehicleId: formData.vehicleId,
        ...formData,
      };

      createBooking(bookingData, token)
        .then((createdBooking) => {
          console.log("Booking created:", createdBooking);
          navigate("/confirm-booking", {
            state: { bookingData: createdBooking },
          });
        })
        .catch((error) => {
          console.error("Booking failed:", error);
          toast.error(
            "Booking Failed"
          );
        });
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <button
        onClick={() => navigate("/customer")}
        className="absolute top-30 bg-orange-500 text-white px-4 py-2 rounded hover:bg-orange-600"
      >
        Back
      </button>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="ml-12 rounded-lg">
          <div className="flex justify-center">
            <img
              src={vehicle.vehicleImageURL || Sedan}
              alt={vehicle.modelName}
              className="w-3/4 mt-6 h-auto rounded-lg"
            />
          </div>
          <div className="ps-24 pe-12">
            <p className="font-bold mb-3 flex gap-16 items-center">
              <span>
                {vehicle.modelName} ({vehicle.categoryType})
              </span>
              <StarRating vehicleId={vehicle.vehicleId} />
            </p>
            <div className="flex justify-between items-center">
              <div>
                <p className="pb-2">
                  Mileage: <span className="pl-11">{vehicle.mileage}</span>{" "}
                  km/litres
                </p>
                <p className="pb-2">
                  Fuel Type: <span className="pl-8">{vehicle.fuelType}</span>
                </p>
                <p className="pb-2">
                  Model Year: <span className="pl-5">{vehicle.modelYear}</span>
                </p>
                <p className="pb-2">
                  price:{" "}
                  <span className="pl-16">₹{vehicle.pricePerDay} / day</span>
                </p>
              </div>
            </div>
            <p>
              Features:{" "}
              <span className="pl-10">{vehicle.featureDescription}</span>
            </p>
          </div>
        </div>
        <div className="mt-12 bg-cyan-100 p-6 rounded-lg h-auto mb-10">
          <h2 className="text-xl font-bold mb-4">Book Your Vehicle</h2>
          <div className="mb-4 flex items-center gap-6">
            <label className="w-1/3 text-sm font-medium">Location</label>
            <select
              name="location"
              value={formData.location}
              onChange={handleChange}
              className="w-2/3 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Location</option>
              {locations.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>
          {errors.location && (
            <p className="mb-4 text-red-500 text-sm">{errors.location}</p>
          )}

          <div className="mb-4 flex items-center gap-6">
            <label className="w-1/3 text-sm font-medium">From Date</label>
            <p className="w-2/3 px-3 py-2 border border-gray-300 rounded-md bg-gray-50">
              {formData.fromDate
                ? formData.fromDate.toDateString()
                : "No date selected"}
            </p>
          </div>

          <div className="mb-4 flex items-center gap-6">
            <label className="w-1/3 text-sm font-medium">To Date</label>
            <p className="w-2/3 px-3 py-2 border border-gray-300 rounded-md bg-gray-50">
              {formData.toDate
                ? formData.toDate.toDateString()
                : "No date selected"}
            </p>
          </div>

          <div className="mb-4 flex items-center gap-6">
            <label className="w-1/3 text-sm font-medium">Aadhar Number</label>
            <input
              type="text"
              name="customerAadharNumber"
              value={formData.customerAadharNumber}
              onChange={handleChange}
              className="w-2/3 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter your Aadhar number"
            />
          </div>
          {errors.customerAadharNumber && (
            <p className="mb-4 text-red-500 text-sm">
              {errors.customerAadharNumber}
            </p>
          )}

          <div className="mb-4 flex items-center gap-6">
            <label className="w-1/3 text-sm font-medium">Need a Driver?</label>
            <div className="flex gap-4">
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="wantsDriver"
                  checked={formData.wantsDriver}
                  onChange={() =>
                    setFormData({ ...formData, wantsDriver: true })
                  }
                />
                Yes
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="wantsDriver"
                  checked={!formData.wantsDriver}
                  onChange={() =>
                    setFormData({ ...formData, wantsDriver: false })
                  }
                />
                No
              </label>
            </div>
          </div>

          {!formData.wantsDriver && (
            <div>
              <div className="mb-4 flex items-center gap-6">
                <label className="w-1/3 text-sm font-medium">
                  Driving License
                </label>
                <input
                  type="text"
                  name="customerDrivingLicenseNumber"
                  value={formData.customerDrivingLicenseNumber}
                  onChange={handleChange}
                  className="w-2/3 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter your driving license number"
                />
              </div>
              {errors.customerDrivingLicenseNumber && (
                <p className="mb-4 text-red-500 text-sm">
                  {errors.customerDrivingLicenseNumber}
                </p>
              )}
            </div>
          )}

          <button
            onClick={handleProceed}
            className="w-full bg-orange-500 text-white px-4 py-2 rounded hover:bg-orange-600"
          >
            Proceed to Payment
          </button>
        </div>
      </div>

      <div className="mt-12 bg-white p-6 rounded-lg">
        <h2 className="text-xl font-bold mb-4">Customer Reviews</h2>
        {reviews.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {reviews.map((review, index) => {
              const user = reviewers[review.customerId] || {
                name: "Loading...",
                email: "Loading...",
              };
              return (
                <div
                  key={index}
                  className="flex flex-col p-4 bg-gray-100 rounded-lg shadow-sm"
                >
                  <div className="flex items-center mb-3">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-orange-400 flex items-center justify-center text-white">
                      <FaUser className="text-2xl" />
                    </div>
                    <div className="ml-4">
                      <p className="font-semibold text-sm">{user.name}</p>
                      <p className="text-xs text-gray-500">{user.email}</p>
                    </div>
                  </div>
                  <div className="mt-2">
                    <div className="flex mb-2">{renderStar(review.rating)}</div>
                    <p className="text-gray-600">{review.comment}</p>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <p>No reviews yet for this vehicle.</p>
        )}
      </div>
    </div>
  );
};

export default BookVehicle;
