import React, { useState } from "react";
import CustomerSidebar from "../components/CustomerSidebar";
import VehiclesView from "../components/customer/VehicleView";
import UpdateProfile from "../components/customer/UpdateProfile";
import CompareVehicle from "../components/Vehicle/CompareVehicle";
import Favorites from "../components/customer/Favorites";
import BookingHistory from "../components/customer/BookingHistory";
import Reviews from "../components/customer/Reviews";

const CustomerDashboard = () => {
  const [activeTab, setActiveTab] = useState("Book Vehicles");
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleProfileClick = () => {
    setIsModalOpen(!isModalOpen);
  };

  const renderComponent = () => {
    switch (activeTab) {
      case "Book Vehicles":
        return <VehiclesView />;
      case "My Reviews":
        return <Reviews />;
      case "My Bookings":
        return <BookingHistory />;
      case "My Favorites":
        return <Favorites />;
      case "Compare Vehicles":
        return <CompareVehicle />;
      default:
        return <div>Select a navigation option.</div>;
    }
  };

  return (
    <div className="flex h-auto">
      <CustomerSidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        handleProfileClick={handleProfileClick}
      />
      <div className="flex-1 bg-gray-100">{renderComponent()}</div>
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-lg relative">
            <button
              onClick={handleProfileClick}
              className="absolute top-2 right-2 text-2xl text-red-600"
            >
              &times;
            </button>

            <div className="max-h-[80vh] overflow-y-auto p-4">
              <h2 className="text-2xl mb-4">Update Profile</h2>
              <UpdateProfile onClose={handleProfileClick} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerDashboard;
