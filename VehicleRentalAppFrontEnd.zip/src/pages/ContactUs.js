import React, { useState } from "react";
import Navbar from "../components/Navbar";
import contactUs from "../assets/images/contactUs.jpg";

const ContactUs = () => {
  const [name, setName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [message, setMessage] = useState("");

  const [errors, setErrors] = useState({
    name: "",
    email: "",
    message: "",
  });

  const [success, setSuccess] = useState("");

  const emailValidationRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

  const handleSubmit = (e) => {
    e.preventDefault();

    setErrors({ name: "", email: "", message: "" });
    setSuccess("");

    const newErrors = {};
    if (!name.trim()) {
      newErrors.name = "Name is required.";
    }
    if (!contactEmail.trim()) {
      newErrors.email = "Email is required.";
    } else if (!emailValidationRegex.test(contactEmail)) {
      newErrors.email = "Please enter a valid email address.";
    }
    if (!message.trim()) {
      newErrors.message = "Message is required.";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setSuccess("Message sent successfully!");
    setName("");
    setContactEmail("");
    setMessage("");
  };

  return (
    <React.Fragment>
      <Navbar />
      <div className="bg-gray-100 min-h-screen flex flex-col items-center py-10 px-6">
        <h1 className="flex justify-center items-center text-5xl font-bold text-orange-600 mb-14">
          Contact Us
        </h1>
        <div className="container mx-auto flex flex-col md:flex-row bg-white shadow-lg rounded-2xl overflow-hidden">
          <div className="flex-1 bg-gray-50 p-8 flex flex-col">
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-6">
                Get in Touch
              </h2>
              <div className="space-y-10 mt-10">
                <div className="flex items-center">
                  <span className="text-orange-500 mr-4">
                    <i className="fas fa-map-marker-alt"></i>
                  </span>
                  <h3 className="text-gray-600">
                    1-58/1, Whitefield, Bangalore - 560001
                  </h3>
                </div>
                <div className="flex items-center">
                  <span className="text-orange-500 mr-4">
                    <i className="fas fa-phone-alt"></i>
                  </span>
                  <h3 className="text-gray-600">+91 9740234550</h3>
                </div>
                <div className="flex items-center">
                  <span className="text-orange-500 mr-4">
                    <i className="fas fa-envelope"></i>
                  </span>
                  <h3 className="text-gray-600">rentwheels001@gmail.com</h3>
                </div>
              </div>
            </div>

            {/* Social Media Links */}
            <div className="mt-14">
              <h3 className="text-2xl font-bold text-gray-800 mb-8">
                Follow Us
              </h3>
              <div className="flex space-x-4 gap-10">
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-800"
                >
                  <i className="fab fa-facebook-f text-2xl"></i>
                </a>
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-pink-500 hover:text-pink-700"
                >
                  <i className="fab fa-instagram text-2xl"></i>
                </a>
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-400 hover:text-blue-600"
                >
                  <i className="fab fa-twitter text-2xl"></i>
                </a>
              </div>
            </div>
          </div>

          <div className="flex-1 p-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">
              Send Us a Message
            </h2>
            <form className="space-y-4" onSubmit={handleSubmit}>
              <div>
                <label
                  htmlFor="name"
                  className="block text-gray-700 font-medium"
                >
                  Your Name
                </label>
                <input
                  type="text"
                  id="name"
                  placeholder="Enter your name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
                {errors.name && (
                  <p className="text-red-500 text-sm mt-1">{errors.name}</p>
                )}
              </div>
              <div>
                <label
                  htmlFor="email"
                  className="block text-gray-700 font-medium"
                >
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  placeholder="Enter your email"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
                {errors.email && (
                  <p className="text-red-500 text-sm mt-1">{errors.email}</p>
                )}
              </div>
              <div>
                <label
                  htmlFor="message"
                  className="block text-gray-700 font-medium"
                >
                  Message
                </label>
                <textarea
                  id="message"
                  rows="4"
                  placeholder="Write your message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
                ></textarea>
                {errors.message && (
                  <p className="text-red-500 text-sm mt-1">{errors.message}</p>
                )}
              </div>
              <button
                type="submit"
                className="w-full bg-orange-500 text-white font-semibold rounded-lg py-2 hover:bg-orange-600"
              >
                Send Message
              </button>
              {success && (
                <p className="text-green-600 text-lg font-semibold text-center mt-2">
                  {success}
                </p>
              )}
            </form>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default ContactUs;
