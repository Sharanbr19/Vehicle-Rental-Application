import React from "react";
import Navbar from "../components/Navbar";

const Policies = () => {
  return (
    <React.Fragment>
      <Navbar />
      <div className="p-6 bg-gray-100 min-h-screen">
        <div className="max-w-4xl mx-auto bg-white shadow-md rounded-lg p-8">
          <h1 className="text-3xl font-bold text-orange-600 mb-6 text-center">Our Policies</h1>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Rental Policies</h2>
            <ul className="list-disc pl-6 text-gray-700">
              <li>Renters must be at least 18 years old with a valid driver’s license.</li>
              <li>Vehicles must be returned with the same fuel level as provided.</li>
              <li>Late returns will incur additional charges based on the hourly rate.</li>
              <li>Only authorized drivers listed during booking are allowed to drive the vehicle.</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Payment Policies</h2>
            <ul className="list-disc pl-6 text-gray-700">
              <li>A valid credit or debit card is required to secure the booking.</li>
              <li>Full payment must be made before picking up the vehicle.</li>
              <li>Refunds for cancellations are subject to the cancellation policy.</li>
              <li>All applicable taxes and fees are included in the final payment.</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Cancellation Policies</h2>
            <ul className="list-disc pl-6 text-gray-700">
              <li>Cancellations made more than 24 hours before the booking time are fully refundable.</li>
              <li>Cancellations within 24 hours of the booking time will incur a 50% cancellation fee.</li>
              <li>No-shows or cancellations after the scheduled pickup time will not be refunded.</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Damage & Insurance Policies</h2>
            <ul className="list-disc pl-6 text-gray-700">
              <li>All vehicles are insured, but renters are responsible for the deductible in case of an accident.</li>
              <li>Minor damages such as scratches or dents will incur repair charges.</li>
              <li>Optional full damage waiver insurance can be purchased during booking.</li>
              <li>In case of theft, a police report must be filed, and the renter is liable for the deductible.</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Privacy Policy</h2>
            <p className="text-gray-700">
              We value your privacy and ensure that all personal information collected is securely stored. 
              Your data will only be used for processing bookings, improving services, and sending important updates. 
              We do not share your information with third parties without your consent. For more details, please refer to our full Privacy Policy.
            </p>
          </section>
        </div>
      </div>
    </React.Fragment>
  );
};

export default Policies;
