import React, { useState } from "react";
import ManageVehicles from "../components/Admin/ManageVehicles";
import ManageUsers from "../components/Admin/ManageUsers";
import ManageBookings from "../components/Admin/ManageBookings";
import ManageDrivers from "../components/Admin/ManageDrivers";
import RentMatrix from "../components/Admin/RentMatrix";
import AdminSidebar from "../components/AdminSidebar";
import ManageReviews from "../components/Admin/ManageReviews";

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState("Manage Vehicles");

  const renderContent = () => {
    switch (activeTab) {
      case "Manage Vehicles":
        return <ManageVehicles />;
      case "Manage Users":
        return <ManageUsers />;
      case "Manage Bookings":
        return <ManageBookings />;
      case "Manage Drivers":
        return <ManageDrivers />;
      case "Manage Reviews":
        return <ManageReviews />;
      case "View Matrices":
        return <RentMatrix />;

      default:
        return <div>Welcome to Admin Dashboard</div>;
    }
  };

  return (
    <div className="flex h-auto">
      <AdminSidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <div className="flex-1 bg-gray-100">{renderContent()}</div>
    </div>
  );
};

export default AdminDashboard;
