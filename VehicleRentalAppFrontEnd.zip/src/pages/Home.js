import React from "react";
import Navbar from "../components/Navbar";
import Hero from "../components/home/Hero";
import FeaturedVehicles from "../components/home/FeaturedVehicles";
import Reviews from "../components/home/Reviews";
import ServicesBanner from "../components/home/ServicesBanner";
import Gallery from "../components/home/Gallery";
import BrandSection from "../components/home/BrandSection";

function Home() {
  return (
    <React.Fragment>
      <Navbar />
      <Hero />
      <FeaturedVehicles />
      <BrandSection />
      <ServicesBanner />
      <Gallery />
      <Reviews />
    </React.Fragment>
  );
}

export default Home;
