package com.endava.vehiclerentalapp.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ConstantsTest {

    @Test
    void testAdminNotFoundConstant_Positive() {
        assertEquals("Admin not found with ID: ", Constants.ADMIN_NOT_FOUND);
    }

    @Test
    void testVehicleNotFoundConstant_Positive() {
        assertEquals("Vehicle not found with ID: ", Constants.VEHICLE_NOT_FOUND);
    }
    
    @Test
    void testInvalidSortAttributeConstant_Positive() {
        assertEquals("Invalid sort attribute: ", Constants.INVALID_SORT_ATTRIBUTE);
    }
    
    @Test
    void testTwoVehiclesRequiredConstant_Positive() {
        assertEquals("Exactly two vehicle IDs are required for comparison.", Constants.TWO_VEHICLES_REQUIRED);
    }
    
    @Test
    void testBothVehiclesMustExistConstant_Positive() {
        assertEquals("Both vehicles must exist for comparison.", Constants.BOTH_VEHICLES_MUST_EXIST);
    }
    
    @Test
    void testUnsupportedAttributeConstant_Positive() {
        assertEquals("Unsupported attribute for comparison: ", Constants.UNSUPPORTED_ATTRIBUTE);
    }
    
    @Test
    void testNoDifferenceConstant_Positive() {
        assertEquals("No Difference", Constants.NO_DIFFERENCE);
    }
    
    @Test
    void testOtpEmailTemplateContainsHtml_Positive() {
        assertTrue(Constants.OTP_EMAIL_TEMPLATE.contains("<html>"), "OTP email template should contain '<html>' tag");
        assertTrue(Constants.OTP_EMAIL_TEMPLATE.contains("{otp}"), "OTP email template should contain the placeholder '{otp}'");
    }
    
    @Test
    void testBookingSuccessEmailSubject_Positive() {
        assertEquals("Vehicle Rental Booking Successful", Constants.BOOKING_SUCCESS_EMAIL_SUBJECT);
    }
    
    @Test
    void testAdminNotFoundConstant_Negative() {
        assertNotEquals("Admin not found", Constants.ADMIN_NOT_FOUND);
    }

    @Test
    void testVehicleNotFoundConstant_Negative() {
        assertNotEquals("Vehicle not found", Constants.VEHICLE_NOT_FOUND);
    }
    
    @Test
    void testInvalidSortAttributeConstant_Negative() {
        assertNotEquals("Invalid sort attribute", Constants.INVALID_SORT_ATTRIBUTE);
    }
    
    @Test
    void testTwoVehiclesRequiredConstant_Negative() {
        assertNotEquals("Exactly two vehicles are required for comparison.", Constants.TWO_VEHICLES_REQUIRED);
    }
    
    @Test
    void testBothVehiclesMustExistConstant_Negative() {
        assertNotEquals("Both vehicles must exist.", Constants.BOTH_VEHICLES_MUST_EXIST);
    }
    
    @Test
    void testUnsupportedAttributeConstant_Negative() {
        assertNotEquals("Unsupported attribute", Constants.UNSUPPORTED_ATTRIBUTE);
    }
    
    @Test
    void testNoDifferenceConstant_Negative() {
        assertNotEquals("No Change", Constants.NO_DIFFERENCE);
    }
    
    @Test
    void testOtpEmailTemplate_Negative() {
        assertFalse(Constants.OTP_EMAIL_TEMPLATE.contains("{{otp}}"), "OTP template should not use double curly braces");
    }
    
    @Test
    void testBookingSuccessEmailSubject_Negative() {
        assertNotEquals("Booking Successful", Constants.BOOKING_SUCCESS_EMAIL_SUBJECT);
    }
}
