package com.endava.vehiclerentalapp.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class JwtTokenUtilTest {

    private final String testEmail = "test@example.com";
    private final String testRole = "USER";

    @Test
    void testGenerateToken_ReturnsNonNullNonEmptyString() {
        String token = jwtTokenUtil.generateToken(testEmail, testRole);
        assertNotNull(token, "Generated token should not be null");
        assertFalse(token.isEmpty(), "Generated token should not be empty");
    }

    @Test
    void testValidateToken_WithValidToken_ReturnsTrue() {
        String token = jwtTokenUtil.generateToken(testEmail, testRole);
        assertTrue(jwtTokenUtil.validateToken(token), "A valid token should return true when validated");
    }

    @Test
    void testValidateToken_WithInvalidToken_ReturnsFalse() {
        String invalidToken = "this.is.not.a.valid.token";
        assertFalse(jwtTokenUtil.validateToken(invalidToken), "An invalid token should return false when validated");
    }

    @Test
    void testExtractEmail_WithValidToken_ReturnsCorrectEmail() {
        String token = jwtTokenUtil.generateToken(testEmail, testRole);
        String extractedEmail = jwtTokenUtil.extractEmail(token);
        assertEquals(testEmail, extractedEmail, "Extracted email should match the original email");
    }

    @Test
    void testExtractEmail_WithInvalidToken_ThrowsException() {
        String invalidToken = "this.is.not.a.valid.token";
        assertThrows(Exception.class, () -> jwtTokenUtil.extractEmail(invalidToken),
                "Extracting email from an invalid token should throw an exception");
    }
}
