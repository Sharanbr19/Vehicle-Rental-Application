package com.endava.vehiclerentalapp.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class OtpEntryTest {

    private OtpEntry otpEntry;
    private String testOtp;
    private LocalDateTime futureTime;
    private LocalDateTime pastTime;

    @BeforeEach
    void setUp() {
        testOtp = "123456";
        futureTime = LocalDateTime.now().plusMinutes(5); 
        pastTime = LocalDateTime.now().minusMinutes(5); 

        otpEntry = new OtpEntry(testOtp, futureTime);
    }

    @Test
    void testGetOtp_ShouldReturnCorrectOtp() {
        assertEquals(testOtp, otpEntry.getOtp(), "OTP value should match");
    }

    @Test
    void testGetExpirationTime_ShouldReturnCorrectTime() {
        assertEquals(futureTime, otpEntry.getExpirationTime(), "Expiration time should match");
    }

    @Test
    void testIsExpired_FutureTime_ShouldReturnFalse() {
        assertFalse(otpEntry.isExpired(), "OTP should not be expired if expiration time is in the future");
    }

    @Test
    void testIsExpired_PastTime_ShouldReturnTrue() {
        OtpEntry expiredOtpEntry = new OtpEntry(testOtp, pastTime);
        assertTrue(expiredOtpEntry.isExpired(), "OTP should be expired if expiration time is in the past");
    }

    @Test
    void testIsExpired_ExactCurrentTime_ShouldReturnTrue() {
        LocalDateTime now = LocalDateTime.now();
        OtpEntry exactExpiryOtp = new OtpEntry(testOtp, now);
        assertTrue(exactExpiryOtp.isExpired(), "OTP should be expired if expiration time is exactly now");
    }

    @Test
    void testOtpWithEmptyValue_ShouldStillBeValid() {
        OtpEntry emptyOtp = new OtpEntry("", futureTime);
        assertEquals("", emptyOtp.getOtp(), "OTP should accept empty strings");
    }

    @Test
    void testOtpWithNullValue_ShouldThrowException() {
        OtpEntry nullOtp = new OtpEntry(null, futureTime);
        assertNull(nullOtp.getOtp(), "OTP value should allow nulls");
    }
}
