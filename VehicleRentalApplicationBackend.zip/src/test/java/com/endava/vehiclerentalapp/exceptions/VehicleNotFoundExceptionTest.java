package com.endava.vehiclerentalapp.exceptions;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class VehicleNotFoundExceptionTest {

    @Test
    void testConstructorWithMessage_Positive() {
        String message = "Vehicle not found with ID: 1";
        VehicleNotFoundException exception = new VehicleNotFoundException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void testConstructorWithMessageAndCause_Positive() {
        String message = "Vehicle not found with ID: 2";
        Throwable cause = new RuntimeException("Underlying cause");
        VehicleNotFoundException exception = new VehicleNotFoundException(message, cause);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testConstructorWithMessage_Negative() {
        String message = "Vehicle not found with ID: 3";
        VehicleNotFoundException exception = new VehicleNotFoundException(message);
        assertNotEquals("Some other error message", exception.getMessage());
    }

    @Test
    void testConstructorWithMessageAndCause_Negative() {
        String message = "Vehicle not found with ID: 4";
        Throwable cause = new RuntimeException("Expected cause");
        VehicleNotFoundException exception = new VehicleNotFoundException(message, cause);
        Throwable differentCause = new RuntimeException("Different cause");
        assertNotEquals(differentCause.getMessage(), exception.getCause().getMessage());
    }

    @Test
    void testConstructorWithNullMessage() {
        VehicleNotFoundException exception = new VehicleNotFoundException(null);
        assertNull(exception.getMessage());
    }

    @Test
    void testConstructorWithNullMessageAndNullCause() {
        VehicleNotFoundException exception = new VehicleNotFoundException(null, null);
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }
}
