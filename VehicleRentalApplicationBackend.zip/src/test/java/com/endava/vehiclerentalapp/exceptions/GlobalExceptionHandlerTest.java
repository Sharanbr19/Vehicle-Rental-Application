package com.endava.vehiclerentalapp.exceptions;

import static org.junit.jupiter.api.Assertions.*;

import com.endava.vehiclerentalapp.util.Constants;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

class GlobalExceptionHandlerTest {

    private GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    void testHandleUserAlreadyExists_Positive() {
        String errorMessage = "Email is already taken.";
        UserAlreadyExistsException ex = new UserAlreadyExistsException(errorMessage);
        
        ResponseEntity<String> response = handler.handleUserAlreadyExists(ex);
        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals(errorMessage, response.getBody());
    }

    @Test
    void testHandleUserAlreadyExists_Negative() {
        String errorMessage = "Email is already taken.";
        UserAlreadyExistsException ex = new UserAlreadyExistsException(errorMessage);
        
        ResponseEntity<String> response = handler.handleUserAlreadyExists(ex);
        assertNotEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotEquals("Some unexpected error", response.getBody());
    }

    @Test
    void testHandleVehicleNotFound_Positive() {
        String errorMessage = "Vehicle not found with ID: 123";
        VehicleNotFoundException ex = new VehicleNotFoundException(errorMessage);
        
        ResponseEntity<String> response = handler.handleVehicleNotFound(ex);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals(errorMessage, response.getBody());
    }
    
    @Test
    void testHandleVehicleNotFound_Negative() {
        String errorMessage = "Vehicle not found with ID: 123";
        VehicleNotFoundException ex = new VehicleNotFoundException(errorMessage);
        
        ResponseEntity<String> response = handler.handleVehicleNotFound(ex);
        assertNotEquals("Vehicle not found", response.getBody());
        assertNotEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }

    @Test
    void testHandleCustomerNotFound_Positive() {
        String errorMessage = "User not found";
        CustomerNotFoundException ex = new CustomerNotFoundException(errorMessage);
        
        ResponseEntity<String> response = handler.handleCustomerNotFound(ex);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals(errorMessage, response.getBody());
    }
    
    @Test
    void testHandleCustomerNotFound_Negative() {
        String errorMessage = "User not found";
        CustomerNotFoundException ex = new CustomerNotFoundException(errorMessage);
        
        ResponseEntity<String> response = handler.handleCustomerNotFound(ex);
        assertNotEquals("Some other error", response.getBody());
        assertNotEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }
    
    @Test
    void testHandleFavoriteNotFound_Positive() {
        String errorMessage = "Favorite not found for User ID: 1";
        FavoriteNotFoundException ex = new FavoriteNotFoundException(errorMessage);
        
        ResponseEntity<String> response = handler.handleFavoriteNotFound(ex);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals(errorMessage, response.getBody());
    }
    
    @Test
    void testHandleFavoriteNotFound_Negative() {
        String errorMessage = "Favorite not found for User ID: 1";
        FavoriteNotFoundException ex = new FavoriteNotFoundException(errorMessage);
        
        ResponseEntity<String> response = handler.handleFavoriteNotFound(ex);
        assertNotEquals("Favorite not found", response.getBody());
        assertNotEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }
    
    @Test
    void testHandleNoPaymentFound_Positive() {
        String errorMessage = "No payment found with id 999";
        NoPaymentFoundException ex = new NoPaymentFoundException(errorMessage);
        
        ResponseEntity<String> response = handler.handleNoPaymentFound(ex);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals(errorMessage, response.getBody());
    }
    
    @Test
    void testHandleNoPaymentFound_Negative() {
        String errorMessage = "No payment found with id 999";
        NoPaymentFoundException ex = new NoPaymentFoundException(errorMessage);
        
        ResponseEntity<String> response = handler.handleNoPaymentFound(ex);
        assertNotEquals("Different error", response.getBody());
        assertNotEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }

    @Test
    void testHandleDriverNotFound_Positive() {
        String errorMessage = "Driver not found with id 1";
        DriverNotFoundException ex = new DriverNotFoundException(errorMessage);
        
        ResponseEntity<String> response = handler.handleDriverNotFound(ex);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals(errorMessage, response.getBody());
    }
    
    @Test
    void testHandleDriverNotFound_Negative() {
        String errorMessage = "Driver not found with id 1";
        DriverNotFoundException ex = new DriverNotFoundException(errorMessage);
        
        ResponseEntity<String> response = handler.handleDriverNotFound(ex);
        assertNotEquals("Driver error", response.getBody());
        assertNotEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }
    
    @Test
    void testHandleFavoriteAlreadyExist_Positive() {
        String errorMessage = "Favorite already exists for User ID: 1";
        FavoriteAlreadyExistsException ex = new FavoriteAlreadyExistsException(errorMessage);
        
        ResponseEntity<String> response = handler.handleFavoriteAlreadyExist(ex);
        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals(errorMessage, response.getBody());
    }
    
    @Test
    void testHandleFavoriteAlreadyExist_Negative() {
        String errorMessage = "Favorite already exists for User ID: 1";
        FavoriteAlreadyExistsException ex = new FavoriteAlreadyExistsException(errorMessage);
        
        ResponseEntity<String> response = handler.handleFavoriteAlreadyExist(ex);
        assertNotEquals("Not a conflict", response.getBody());
        assertNotEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }
    
    @Test
    void testHandleGeneralException_Positive() {
        Exception ex = new Exception("Any error");
        ResponseEntity<String> response = handler.handleGeneralException(ex);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals(Constants.AN_ERROR_OCCURRED, response.getBody());
    }
    
    @Test
    void testHandleGeneralException_Negative() {
        Exception ex = new Exception("Different error");
        ResponseEntity<String> response = handler.handleGeneralException(ex);
        assertNotEquals("Different error", response.getBody());
        assertNotEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }
}
