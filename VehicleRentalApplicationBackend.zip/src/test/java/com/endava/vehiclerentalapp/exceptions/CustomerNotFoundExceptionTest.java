package com.endava.vehiclerentalapp.exceptions;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CustomerNotFoundExceptionTest {

    @Test
    void testConstructorWithMessage_Positive() {
        String message = "Customer not found";
        CustomerNotFoundException exception = new CustomerNotFoundException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void testConstructorWithMessageAndCause_Positive() {
        String message = "Customer not found";
        Throwable cause = new RuntimeException("Underlying cause");
        CustomerNotFoundException exception = new CustomerNotFoundException(message, cause);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testConstructorWithMessage_Negative() {
        String message = "Customer not found";
        CustomerNotFoundException exception = new CustomerNotFoundException(message);
        assertNotEquals("Some other error message", exception.getMessage());
    }

    @Test
    void testConstructorWithMessageAndCause_Negative() {
        String message = "Customer not found";
        Throwable cause = new RuntimeException("Expected cause");
        CustomerNotFoundException exception = new CustomerNotFoundException(message, cause);
        Throwable differentCause = new RuntimeException("Different cause");
        assertNotEquals(differentCause.getMessage(), exception.getCause().getMessage());
    }

    @Test
    void testConstructorWithNullMessage() {
    	CustomerNotFoundException exception = new CustomerNotFoundException(null);
        assertNull(exception.getMessage());
    }

    @Test
    void testConstructorWithNullMessageAndNullCause() {
    	CustomerNotFoundException exception = new CustomerNotFoundException(null, null);
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }
}

