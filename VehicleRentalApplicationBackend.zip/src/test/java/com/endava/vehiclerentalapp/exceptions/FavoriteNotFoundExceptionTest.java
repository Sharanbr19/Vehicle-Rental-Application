package com.endava.vehiclerentalapp.exceptions;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FavoriteNotFoundExceptionTest {

    @Test
    void testConstructorWithMessage_Positive() {
        String message = "Favorite not found";
        FavoriteNotFoundException exception = new FavoriteNotFoundException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void testConstructorWithMessageAndCause_Positive() {
        String message = "Favorite not found";
        Throwable cause = new RuntimeException("Underlying cause");
        FavoriteNotFoundException exception = new FavoriteNotFoundException(message, cause);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testConstructorWithMessage_Negative() {
        String message = "Favorite not found";
        VehicleNotFoundException exception = new VehicleNotFoundException(message);
        assertNotEquals("Some other error message", exception.getMessage());
    }

    @Test
    void testConstructorWithMessageAndCause_Negative() {
        String message = "Favorite not found";
        Throwable cause = new RuntimeException("Expected cause");
        FavoriteNotFoundException exception = new FavoriteNotFoundException(message, cause);
        Throwable differentCause = new RuntimeException("Different cause");
        assertNotEquals(differentCause.getMessage(), exception.getCause().getMessage());
    }

    @Test
    void testConstructorWithNullMessage() {
    	FavoriteNotFoundException exception = new FavoriteNotFoundException(null);
        assertNull(exception.getMessage());
    }

    @Test
    void testConstructorWithNullMessageAndNullCause() {
    	FavoriteNotFoundException exception = new FavoriteNotFoundException(null, null);
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }
}

