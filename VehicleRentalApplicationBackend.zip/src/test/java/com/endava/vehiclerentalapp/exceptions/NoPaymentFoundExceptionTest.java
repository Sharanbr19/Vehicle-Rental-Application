package com.endava.vehiclerentalapp.exceptions;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class NoPaymentFoundExceptionTest {

    @Test
    void testConstructorWithMessage_Positive() {
        String message = "Payment not found";
        NoPaymentFoundException exception = new NoPaymentFoundException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void testConstructorWithMessageAndCause_Positive() {
        String message = "Payment not found";
        Throwable cause = new RuntimeException("Underlying cause");
        NoPaymentFoundException exception = new NoPaymentFoundException(message, cause);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testConstructorWithMessage_Negative() {
        String message = "Payment not found";
        NoPaymentFoundException exception = new NoPaymentFoundException(message);
        assertNotEquals("Some other error message", exception.getMessage());
    }

    @Test
    void testConstructorWithMessageAndCause_Negative() {
        String message = "Payment not found";
        Throwable cause = new RuntimeException("Expected cause");
        NoPaymentFoundException exception = new NoPaymentFoundException(message, cause);
        Throwable differentCause = new RuntimeException("Different cause");
        assertNotEquals(differentCause.getMessage(), exception.getCause().getMessage());
    }

    @Test
    void testConstructorWithNullMessage() {
    	NoPaymentFoundException exception = new NoPaymentFoundException(null);
        assertNull(exception.getMessage());
    }

    @Test
    void testConstructorWithNullMessageAndNullCause() {
    	NoPaymentFoundException exception = new NoPaymentFoundException(null, null);
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }
}
