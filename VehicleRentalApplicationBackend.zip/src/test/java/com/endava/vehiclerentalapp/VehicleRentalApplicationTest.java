package com.endava.vehiclerentalapp;

import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)  
class VehicleRentalApplicationTest {

    @Test
    void contextLoadsSuccessfully() {
    	System.setProperty("server.port", "9092"); 
        assertDoesNotThrow(() -> VehicleRentalApplication.main(new String[0]));
    }

    @Test
    void applicationStartsSuccessfully() {
    	System.setProperty("server.port", "9093"); 
        try (MockedStatic<SpringApplication> mockedSpringApplication = mockStatic(SpringApplication.class)) {
            mockedSpringApplication.when(() -> SpringApplication.run(VehicleRentalApplication.class, new String[]{}))
                    .thenReturn(null);

            assertDoesNotThrow(() -> VehicleRentalApplication.main(new String[]{}));
            mockedSpringApplication.verify(() -> SpringApplication.run(VehicleRentalApplication.class, new String[]{}), times(1));
        }
    }

    @Test
    void applicationRunsWithValidArguments() {
    	System.setProperty("server.port", "9091"); 
        String[] args = {"--server.port=9091"};
        assertDoesNotThrow(() -> VehicleRentalApplication.main(args));
    }

    @Test
    void applicationThrowsExceptionOnStartupFailure() {
        try (MockedStatic<SpringApplication> mockedSpringApplication = mockStatic(SpringApplication.class)) {
            mockedSpringApplication.when(() -> SpringApplication.run(VehicleRentalApplication.class, new String[]{}))
                    .thenThrow(new RuntimeException("Startup failure"));

            Exception exception = assertThrows(RuntimeException.class, () -> VehicleRentalApplication.main(new String[]{}));
            assertEquals("Startup failure", exception.getMessage());
        }
    }

    @Test
    void applicationRunsWithEmptyArguments() {
        assertDoesNotThrow(() -> VehicleRentalApplication.main(new String[0]));
    }

    @Test
    void applicationContextFailsToLoad() {
        try (MockedStatic<SpringApplication> mockedSpringApplication = mockStatic(SpringApplication.class)) {
            mockedSpringApplication.when(() -> SpringApplication.run(VehicleRentalApplication.class, new String[]{}))
                    .thenThrow(new IllegalStateException("Context loading failure"));

            Exception exception = assertThrows(IllegalStateException.class, () -> VehicleRentalApplication.main(new String[]{}));
            assertEquals("Context loading failure", exception.getMessage());
        }
    }

    @Test
    void applicationRunsAndSpringApplicationRunIsCalledOnce() {
        try (MockedStatic<SpringApplication> mockedSpringApplication = mockStatic(SpringApplication.class)) {
            mockedSpringApplication.when(() -> SpringApplication.run(VehicleRentalApplication.class, new String[]{}))
                    .thenReturn(null);

            VehicleRentalApplication.main(new String[]{});
            mockedSpringApplication.verify(() -> SpringApplication.run(VehicleRentalApplication.class, new String[]{}), times(1));
        }
    }
}
