package com.endava.vehiclerentalapp.dto;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class LoginResponseTest {

    @Test
    void constructorShouldInitializeToken() {
        String expectedToken = "sample.jwt.token";
        LoginResponse response = new LoginResponse(expectedToken);

        assertNotNull(response);
        assertEquals(expectedToken, response.getToken());
    }

    @Test
    void setterShouldUpdateToken() {
        LoginResponse response = new LoginResponse("initial.token");
        String newToken = "updated.jwt.token";
        
        response.setToken(newToken);
        
        assertEquals(newToken, response.getToken());
    }

    @Test
    void constructorShouldHandleNullToken() {
        LoginResponse response = new LoginResponse(null);

        assertNull(response.getToken());
    }

    @Test
    void setterShouldHandleNullToken() {
        LoginResponse response = new LoginResponse("valid.token");
        response.setToken(null);

        assertNull(response.getToken());
    }

    @Test
    void shouldHandleEmptyToken() {
        LoginResponse response = new LoginResponse("");
        
        assertEquals("", response.getToken());
    }
}

