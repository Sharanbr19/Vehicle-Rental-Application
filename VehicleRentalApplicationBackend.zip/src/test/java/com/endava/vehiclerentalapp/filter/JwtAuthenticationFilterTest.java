package com.endava.vehiclerentalapp.filter;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.context.SecurityContextHolder;
import com.endava.vehiclerentalapp.util.jwtTokenUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@ExtendWith(MockitoExtension.class)
class JwtAuthenticationFilterTest {

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Mock
    private FilterChain filterChain;

    @InjectMocks
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        SecurityContextHolder.setContext(SecurityContextHolder.createEmptyContext()); // Ensure clean security context
    }

    @Test
    void testDoFilterInternal_ValidToken() throws ServletException, IOException {
        String validToken = "valid.jwt.token";
        String email = "test@gmail.com";

        when(request.getHeader("Authorization")).thenReturn("Bearer " + validToken);

        try (MockedStatic<jwtTokenUtil> mockedJwtUtil = mockStatic(jwtTokenUtil.class)) {
            mockedJwtUtil.when(() -> jwtTokenUtil.validateToken(validToken)).thenReturn(true);
            mockedJwtUtil.when(() -> jwtTokenUtil.extractEmail(validToken)).thenReturn(email);

            jwtAuthenticationFilter.doFilterInternal(request, response, filterChain);

            assertNotNull(SecurityContextHolder.getContext().getAuthentication(), "Authentication should not be null");
            assertEquals(email, SecurityContextHolder.getContext().getAuthentication().getPrincipal());
            verify(filterChain, times(1)).doFilter(request, response);
        }
    }

    @Test
    void testDoFilterInternal_MissingAuthorizationHeader() throws ServletException, IOException {
        when(request.getHeader("Authorization")).thenReturn(null);

        jwtAuthenticationFilter.doFilterInternal(request, response, filterChain);

        assertNull(SecurityContextHolder.getContext().getAuthentication());
        verify(filterChain, times(1)).doFilter(request, response);
    }
    
    @Test
    void testDoFilterInternal_InvalidToken() throws ServletException, IOException {
        String invalidToken = "invalid.jwt.token";

        when(request.getHeader("Authorization")).thenReturn("Bearer " + invalidToken);

        try (MockedStatic<jwtTokenUtil> mockedJwtUtil = mockStatic(jwtTokenUtil.class)) {
            mockedJwtUtil.when(() -> jwtTokenUtil.validateToken(invalidToken)).thenReturn(false);

            jwtAuthenticationFilter.doFilterInternal(request, response, filterChain);

            assertNull(SecurityContextHolder.getContext().getAuthentication());
            verify(filterChain, times(1)).doFilter(request, response);
        }
    }

    @Test
    void testDoFilterInternal_MalformedToken() {
        String malformedToken = "malformed.token";

        when(request.getHeader("Authorization")).thenReturn("Bearer " + malformedToken);

        try (MockedStatic<jwtTokenUtil> mockedJwtUtil = mockStatic(jwtTokenUtil.class)) {
            mockedJwtUtil.when(() -> jwtTokenUtil.validateToken(malformedToken)).thenThrow(new RuntimeException("malformed token"));

            assertThrows(RuntimeException.class, () -> jwtAuthenticationFilter.doFilterInternal(request, response, filterChain));

            assertNull(SecurityContextHolder.getContext().getAuthentication());
        }
    }
}

