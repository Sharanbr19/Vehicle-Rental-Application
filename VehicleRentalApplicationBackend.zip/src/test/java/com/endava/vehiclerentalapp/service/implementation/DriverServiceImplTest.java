package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.DriverDTO;
import com.endava.vehiclerentalapp.entity.Driver;
import com.endava.vehiclerentalapp.exceptions.DriverNotFoundException;
import com.endava.vehiclerentalapp.mapper.DriverMapper;
import com.endava.vehiclerentalapp.repository.BookingRepository;
import com.endava.vehiclerentalapp.repository.DriverRepository;
import com.endava.vehiclerentalapp.util.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DriverServiceImplTest {

    @Mock
    private DriverRepository driverRepository;

    @Mock
    private DriverMapper driverMapper;

    @Mock
    private BookingRepository bookingRepository;

    @InjectMocks
    private DriverServiceImpl driverService;

    private Driver driver;
    private DriverDTO driverDTO;

    @BeforeEach
    void setUp() {
        driver = new Driver();
        driver.setDriverId(1L);
        driver.setName("Ramesh");
        driver.setLicenseNumber("KA19 123456789012");
        driver.setDriverCostPerDay(100.0);
        driver.setIsDeleted(false);
        driver.setContactNumber("1234567890");

        driverDTO = new DriverDTO();
        driverDTO.setDriverId(1L);
        driverDTO.setName("Ramesh");
        driverDTO.setLicenseNumber("KA19 123456789012");
        driverDTO.setDriverCostPerDay(100.0);
        driverDTO.setIsDeleted(false);
        driverDTO.setContactNumber("1234567890");
    }

    @Test
    void testCreateDriver_Success() {
        when(driverMapper.toEntity(driverDTO)).thenReturn(driver);
        when(driverRepository.save(driver)).thenReturn(driver);
        when(driverMapper.toDTO(driver)).thenReturn(driverDTO);

        DriverDTO result = driverService.createDriver(driverDTO);

        assertNotNull(result);
        assertEquals(driverDTO.getName(), result.getName());
        verify(driverRepository, times(1)).save(driver);
    }

    @Test
    void testGetDriverById_Success() {
        when(driverRepository.findById(1L)).thenReturn(Optional.of(driver));
        when(driverMapper.toDTO(driver)).thenReturn(driverDTO);

        DriverDTO result = driverService.getDriverById(1L);

        assertNotNull(result);
        assertEquals(driverDTO.getDriverId(), result.getDriverId());
    }

    @Test
    void testGetDriverById_DriverNotFound() {
        when(driverRepository.findById(1L)).thenReturn(Optional.empty());

        DriverNotFoundException exception = assertThrows(DriverNotFoundException.class, () -> driverService.getDriverById(1L));

        assertEquals(Constants.DRIVER_NOT_FOUND + "1", exception.getMessage());
    }

    @Test
    void testGetAllDrivers_Success() {
        when(driverRepository.findAll()).thenReturn(Arrays.asList(driver));
        when(driverMapper.toDTO(driver)).thenReturn(driverDTO);

        List<DriverDTO> result = driverService.getAllDrivers();

        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
    }

    @Test
    void testGetAllDrivers_EmptyList() {
        when(driverRepository.findAll()).thenReturn(List.of());

        List<DriverDTO> result = driverService.getAllDrivers();

        assertTrue(result.isEmpty());
    }

    @Test
    void testUpdateDriver_Success() {
        when(driverRepository.findById(1L)).thenReturn(Optional.of(driver));
        when(driverRepository.save(driver)).thenReturn(driver);
        when(driverMapper.toDTO(driver)).thenReturn(driverDTO);

        DriverDTO result = driverService.updateDriver(1L, driverDTO);

        assertNotNull(result);
        assertEquals(driverDTO.getName(), result.getName());
    }

    @Test
    void testUpdateDriver_DriverNotFound() {
        when(driverRepository.findById(1L)).thenReturn(Optional.empty());

        DriverNotFoundException exception = assertThrows(DriverNotFoundException.class, () -> driverService.updateDriver(1L, driverDTO));

        assertEquals(Constants.DRIVER_NOT_FOUND + "1", exception.getMessage());
    }

    @Test
    void testDeleteDriver_Success() {
        when(driverRepository.findById(1L)).thenReturn(Optional.of(driver));
        when(bookingRepository.existsByDriver_DriverIdAndToDateAfter(1L, LocalDate.now())).thenReturn(false);

        assertDoesNotThrow(() -> driverService.deleteDriver(1L));
        verify(driverRepository, times(1)).save(driver);
    }

    @Test
    void testDeleteDriver_DriverNotFound() {
        when(driverRepository.findById(1L)).thenReturn(Optional.empty());

        DriverNotFoundException exception = assertThrows(DriverNotFoundException.class, () -> driverService.deleteDriver(1L));

        assertEquals(Constants.DRIVER_NOT_FOUND + "1", exception.getMessage());
    }

    @Test
    void testDeleteDriver_HasActiveBookings() {
        when(driverRepository.findById(1L)).thenReturn(Optional.of(driver));
        when(bookingRepository.existsByDriver_DriverIdAndToDateAfter(1L, LocalDate.now())).thenReturn(true);

        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> driverService.deleteDriver(1L));

        assertEquals(Constants.CANNOT_DELETE_DRIVER, exception.getMessage());
    }

    @Test
    void testGetTotalDrivers_Success() {
        when(driverRepository.countByIsDeletedFalse()).thenReturn(5L);

        long count = driverService.getTotalDrivers();

        assertEquals(5, count);
    }
}
