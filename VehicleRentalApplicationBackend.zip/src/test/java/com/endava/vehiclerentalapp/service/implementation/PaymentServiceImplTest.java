package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.PaymentDTO;
import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.Payment;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.entity.Vehicle;
import com.endava.vehiclerentalapp.exceptions.NoPaymentFoundException;
import com.endava.vehiclerentalapp.mapper.PaymentMapper;
import com.endava.vehiclerentalapp.repository.BookingRepository;
import com.endava.vehiclerentalapp.repository.PaymentRepository;
import com.endava.vehiclerentalapp.util.Constants;
import com.razorpay.Order;
import com.razorpay.OrderClient;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PaymentServiceImplTest {

	@Mock
	private PaymentRepository paymentRepository;

	@Mock
	private PaymentMapper paymentMapper;

	@Mock
	private BookingRepository bookingRepository;

	@Mock
	private RazorpayClient razorpayClient;

	@InjectMocks
	private PaymentServiceImpl paymentService;

	@InjectMocks
	private MailService mailService;
	
	private Payment payment;
	private PaymentDTO paymentDTO;
	private Booking booking;

	@BeforeEach
	void setUp() {
	    paymentRepository = mock(PaymentRepository.class);
	    bookingRepository = mock(BookingRepository.class);
	    paymentMapper = mock(PaymentMapper.class);
	    mailService = mock(MailService.class);

	    razorpayClient = mock(RazorpayClient.class);
	    OrderClient mockOrderClient = mock(OrderClient.class);

	    Field ordersField = null;
		try {
			ordersField = RazorpayClient.class.getDeclaredField("orders");
		} catch (NoSuchFieldException | SecurityException e) {
			e.printStackTrace();
		} 
	    ordersField.setAccessible(true);
	    try {
			ordersField.set(razorpayClient, mockOrderClient);
		} catch (IllegalArgumentException | IllegalAccessException e) {
			e.printStackTrace();
		} 

	    paymentService = new PaymentServiceImpl(paymentRepository, paymentMapper, bookingRepository, mailService);

	    Field razorpayClientField = null;
		try {
			razorpayClientField = PaymentServiceImpl.class.getDeclaredField("razorpayClient");
		} catch (NoSuchFieldException | SecurityException e) {
			e.printStackTrace();
		} 
	    razorpayClientField.setAccessible(true);
	    try {
			razorpayClientField.set(paymentService, razorpayClient);
		} catch (IllegalArgumentException | IllegalAccessException e) {
			e.printStackTrace();
		} 

	    booking = new Booking();
	    booking.setBookingId(1L);
	    booking.setPaymentCompleted(false);

	    Users customer = new Users();
	    customer.setUserId(1L);
	    customer.setName("Sharan B R");
	    booking.setCustomer(customer); 

	    Vehicle vehicle = new Vehicle();
	    vehicle.setVehicleId(1L);
	    vehicle.setModelName("Toyota Corolla");
	    vehicle.setCategoryType("Suv");
	    booking.setVehicle(vehicle); 
	    
	    payment = new Payment();
	    payment.setPaymentId(1L);
	    payment.setBooking(booking);
	    payment.setAmount(5000.0);
	    payment.setPaymentDateAndTime(LocalDateTime.now());
	    
	    paymentDTO = new PaymentDTO();
	    paymentDTO.setPaymentId(1L);
	    paymentDTO.setBookingId(1L);
	    paymentDTO.setAmount(5000.0);
	}

	@Test
	void testGetPaymentById_Positive() {
		when(paymentRepository.findById(1L)).thenReturn(Optional.of(payment));
		when(paymentMapper.toDTO(payment)).thenReturn(paymentDTO);
		PaymentDTO result = paymentService.getPaymentById(1L);
		assertNotNull(result);
		assertEquals(1L, result.getPaymentId());
	}

	@Test
	void testGetPaymentById_Negative() {
		when(paymentRepository.findById(1L)).thenReturn(Optional.empty());
		assertThrows(NoPaymentFoundException.class, () -> paymentService.getPaymentById(1L));
	}

	@Test
	void testGetAllPayments_Positive() {
		when(paymentRepository.findAll()).thenReturn(List.of(payment));
		when(paymentMapper.toDTO(payment)).thenReturn(paymentDTO);

		List<PaymentDTO> result = paymentService.getAllPayments();
		assertFalse(result.isEmpty());
		assertEquals(1, result.size());
	}

	@Test
	void testGetAllPayments_Negative() {
		when(paymentRepository.findAll()).thenReturn(List.of());
		assertThrows(NoPaymentFoundException.class, () -> paymentService.getAllPayments());
	}

	@Test
	void testCreatePayment_Positive() throws RazorpayException {
	    when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
	    Order mockOrder = mock(Order.class);
	    when(mockOrder.get("id")).thenReturn("order_123");
	    OrderClient mockOrderClient = razorpayClient.orders;
	    when(mockOrderClient.create(any(JSONObject.class))).thenReturn(mockOrder);
	    when(paymentMapper.toEntity(paymentDTO,booking)).thenReturn(payment);
	    when(paymentRepository.save(any(Payment.class))).thenReturn(payment);
	    String result = paymentService.createPayment(paymentDTO);
	    assertTrue(result.contains("order_123"));
	}

	@Test
	void testCreatePayment_Negative() {
		when(bookingRepository.findById(1L)).thenReturn(Optional.empty());
		assertThrows(IllegalArgumentException.class, () -> paymentService.createPayment(paymentDTO));
	}

	@Test
	void testUpdatePayment_Positive() {
		when(paymentRepository.findById(1L)).thenReturn(Optional.of(payment));

		String result = paymentService.updatePayment(1L, paymentDTO);
		assertEquals(Constants.PAYMENT_UPDATED_SUCCESSFULLY, result);
	}

	@Test
	void testUpdatePayment_Negative() {
		when(paymentRepository.findById(1L)).thenReturn(Optional.empty());
		assertThrows(NoPaymentFoundException.class, () -> paymentService.updatePayment(1L, paymentDTO));
	}

	@Test
	void testDeletePayment_Positive() {
		when(paymentRepository.findByPaymentId(1L)).thenReturn(Optional.of(payment));
		doNothing().when(paymentRepository).delete(payment);

		String result = paymentService.deletePayment(1L);
		assertEquals(Constants.PAYMENT_DELETED_SUCCESSFULLY, result);
	}

	@Test
	void testDeletePayment_Negative() {
		when(paymentRepository.findByPaymentId(1L)).thenReturn(Optional.empty());
		assertThrows(NoPaymentFoundException.class, () -> paymentService.deletePayment(1L));
	}
}