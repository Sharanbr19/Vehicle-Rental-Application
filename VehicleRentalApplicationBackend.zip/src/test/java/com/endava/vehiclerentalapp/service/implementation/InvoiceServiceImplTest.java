package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.InvoiceDTO;
import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.Invoice;
import com.endava.vehiclerentalapp.mapper.InvoiceMapper;
import com.endava.vehiclerentalapp.repository.BookingRepository;
import com.endava.vehiclerentalapp.repository.InvoiceRepository;
import com.endava.vehiclerentalapp.util.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.List;
import java.util.Optional;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InvoiceServiceImplTest {

    @Mock
    private InvoiceRepository invoiceRepository;

    @Mock
    private BookingRepository bookingRepository;

    @Mock
    private InvoiceMapper invoiceMapper;

    @InjectMocks
    private InvoiceServiceImpl invoiceService;

    private InvoiceDTO invoiceDTO;
    private Invoice invoice;
    private Booking booking;

    @BeforeEach
    void setUp() {
        invoiceDTO = new InvoiceDTO();
        invoiceDTO.setInvoiceId(1L);
        invoiceDTO.setBookingId(1L);

        booking = new Booking();
        booking.setBookingId(1L);

        invoice = new Invoice();
        invoice.setInvoiceId(1L);
        invoice.setBooking(booking);
    }

    @Test
    void testCreateInvoice_Success() {
        when(bookingRepository.findById(invoiceDTO.getBookingId())).thenReturn(Optional.of(booking));
        when(invoiceMapper.toEntity(invoiceDTO, booking)).thenReturn(invoice);
        when(invoiceRepository.save(invoice)).thenReturn(invoice);
        when(invoiceMapper.toDTO(invoice)).thenReturn(invoiceDTO);

        InvoiceDTO result = invoiceService.createInvoice(invoiceDTO);

        assertNotNull(result);
        assertEquals(invoiceDTO.getInvoiceId(), result.getInvoiceId());
        verify(invoiceRepository, times(1)).save(invoice);
    }

    @Test
    void testGetInvoiceById_Success() {
        when(invoiceRepository.findById(1L)).thenReturn(Optional.of(invoice));
        when(invoiceMapper.toDTO(invoice)).thenReturn(invoiceDTO);

        InvoiceDTO result = invoiceService.getInvoiceById(1L);

        assertNotNull(result);
        assertEquals(invoiceDTO.getInvoiceId(), result.getInvoiceId());
        verify(invoiceRepository, times(1)).findById(1L);
    }

    @Test
    void testGetInvoicesByCustomerId_Success() {
        List<Invoice> invoices = new ArrayList<>();
        invoices.add(invoice);

        when(invoiceRepository.findByBooking_Customer_UserId(1L)).thenReturn(invoices);
        when(invoiceMapper.toDTO(invoice)).thenReturn(invoiceDTO);

        List<InvoiceDTO> result = invoiceService.getInvoicesByCustomerId(1L);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(invoiceRepository, times(1)).findByBooking_Customer_UserId(1L);
    }

    @Test
    void testGetAllInvoices_Success() {
        List<Invoice> invoices = new ArrayList<>();
        invoices.add(invoice);

        when(invoiceRepository.findAll()).thenReturn(invoices);
        when(invoiceMapper.toDTO(invoice)).thenReturn(invoiceDTO);

        List<InvoiceDTO> result = invoiceService.getAllInvoices();

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(invoiceRepository, times(1)).findAll();
    }

    @Test
    void testDeleteInvoice_Success() {
        doNothing().when(invoiceRepository).deleteById(1L);

        assertDoesNotThrow(() -> invoiceService.deleteInvoice(1L));

        verify(invoiceRepository, times(1)).deleteById(1L);
    }

    @Test
    void testCreateInvoice_BookingNotFound() {
        when(bookingRepository.findById(invoiceDTO.getBookingId())).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            invoiceService.createInvoice(invoiceDTO);
        });

        assertEquals(Constants.BOOKING_NOT_FOUND, exception.getMessage());
        verify(invoiceRepository, never()).save(any());
    }

    @Test
    void testGetInvoiceById_NotFound() {
        when(invoiceRepository.findById(1L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            invoiceService.getInvoiceById(1L);
        });

        assertEquals(Constants.INVOICE_NOT_FOUND, exception.getMessage());
        verify(invoiceMapper, never()).toDTO(any());
    }

    @Test
    void testGetInvoicesByCustomerId_EmptyList() {
        when(invoiceRepository.findByBooking_Customer_UserId(1L)).thenReturn(new ArrayList<>());

        List<InvoiceDTO> result = invoiceService.getInvoicesByCustomerId(1L);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testGetAllInvoices_EmptyList() {
        when(invoiceRepository.findAll()).thenReturn(new ArrayList<>());

        List<InvoiceDTO> result = invoiceService.getAllInvoices();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testDeleteInvoice_InvoiceNotFound() {
        doThrow(new RuntimeException(Constants.INVOICE_NOT_FOUND)).when(invoiceRepository).deleteById(999L);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            invoiceService.deleteInvoice(999L);
        });

        assertEquals(Constants.INVOICE_NOT_FOUND, exception.getMessage());
        verify(invoiceRepository, times(1)).deleteById(999L);
    }
}

