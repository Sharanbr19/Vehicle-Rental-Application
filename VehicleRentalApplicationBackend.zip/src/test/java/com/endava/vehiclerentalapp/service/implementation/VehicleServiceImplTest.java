package com.endava.vehiclerentalapp.service.implementation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.endava.vehiclerentalapp.dto.*;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.entity.Vehicle;
import com.endava.vehiclerentalapp.exceptions.AdminNotFoundException;
import com.endava.vehiclerentalapp.exceptions.VehicleNotFoundException;
import com.endava.vehiclerentalapp.mapper.VehicleMapper;
import com.endava.vehiclerentalapp.repository.BookingRepository;
import com.endava.vehiclerentalapp.repository.UserRepository;
import com.endava.vehiclerentalapp.repository.VehicleRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.time.LocalDate;
import java.util.*;

@ExtendWith(MockitoExtension.class)
class VehicleServiceImplTest {

	@Mock
	private VehicleRepository vehicleRepository;

	@Mock
	private UserRepository userRepository;

	@Mock
	private VehicleMapper vehicleMapper;

	@Mock
	private BookingRepository bookingRepository;

	@InjectMocks
	private VehicleServiceImpl vehicleService;

	private Vehicle vehicle;
	private VehicleDTO vehicleDTO;
	private Users admin;

	private Vehicle vehicle1, vehicle2;
	private VehicleDTO vehicleDTO1, vehicleDTO2;

	@BeforeEach
	void setUp() {
		admin = new Users();
		admin.setUserId(1L);
		admin.setEmail("admin@gmail.com");

		vehicleDTO = new VehicleDTO();
		vehicleDTO.setModelName("Sedan");
		vehicleDTO.setRegistrationNumber("KA01AB1234");
		vehicleDTO.setAdminId(1L);

		vehicle = new Vehicle();
		vehicle.setVehicleId(1L);
		vehicle.setModelName("Sedan");
		vehicle.setRegistrationNumber("KA01AB1234");
		vehicle.setAdmin(admin);

		vehicle1 = new Vehicle();
		vehicle1.setVehicleId(1L);
		vehicle1.setModelName("SedanX");
		vehicle1.setCategoryType("Sedan");
		vehicle1.setFuelType("Petrol");
		vehicle1.setColor("Red");
		vehicle1.setPricePerDay(1500.0);
		vehicle1.setMileage(18.0);
		vehicle1.setModelYear("2022");
		vehicle1.setDeleted(false);

		vehicle2 = new Vehicle();
		vehicle2.setVehicleId(2L);
		vehicle2.setModelName("SUVY");
		vehicle2.setCategoryType("SUV");
		vehicle2.setFuelType("Diesel");
		vehicle2.setColor("Black");
		vehicle2.setPricePerDay(2000.0);
		vehicle2.setMileage(15.0);
		vehicle2.setModelYear("2023");
		vehicle2.setDeleted(false);

		vehicleDTO1 = new VehicleDTO();
		vehicleDTO1.setVehicleId(1L);
		vehicleDTO1.setModelName("SedanX");
		vehicleDTO1.setCategoryType("Sedan");
		vehicleDTO1.setFuelType("Petrol");
		vehicleDTO1.setColor("Red");
		vehicleDTO1.setPricePerDay(1500.0);
		vehicleDTO1.setMileage(18.0);
		vehicleDTO1.setModelYear("2022");

		vehicleDTO2 = new VehicleDTO();
		vehicleDTO2.setVehicleId(2L);
		vehicleDTO2.setModelName("SUVY");
		vehicleDTO2.setCategoryType("SUV");
		vehicleDTO2.setFuelType("Diesel");
		vehicleDTO2.setColor("Black");
		vehicleDTO2.setPricePerDay(2000.0);
		vehicleDTO2.setMileage(15.0);
		vehicleDTO2.setModelYear("2023");
	}

	@Test
	void testAddVehicle_Positive() {
		when(userRepository.findById(1L)).thenReturn(Optional.of(admin));
		when(vehicleMapper.toEntity(vehicleDTO, admin)).thenReturn(vehicle);
		when(vehicleRepository.save(any(Vehicle.class))).thenReturn(vehicle);

		assertDoesNotThrow(() -> vehicleService.addVehicle(vehicleDTO));
		verify(vehicleRepository, times(1)).save(vehicle);
	}

	@Test
	void testAddVehicle_Negative_AdminNotFound() {
		when(userRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(AdminNotFoundException.class, () -> vehicleService.addVehicle(vehicleDTO));
	}

	@Test
	void testUpdateVehicle_Positive() {
		when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));
		when(vehicleRepository.save(any(Vehicle.class))).thenReturn(vehicle);
		when(vehicleMapper.toDto(any())).thenReturn(vehicleDTO);

		Optional<VehicleDTO> updatedVehicle = vehicleService.updateVehicle(1L, vehicleDTO);
		assertTrue(updatedVehicle.isPresent());
		assertEquals("Sedan", updatedVehicle.get().getModelName());
	}

	@Test
	void testUpdateVehicle_Negative_VehicleNotFound() {
		when(vehicleRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(VehicleNotFoundException.class, () -> vehicleService.updateVehicle(1L, vehicleDTO));
	}

	@Test
	void testDeleteVehicle_Positive() {
		when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));
		when(bookingRepository.existsByVehicle_VehicleIdAndToDateAfter(eq(1L), any())).thenReturn(false);

		assertDoesNotThrow(() -> vehicleService.deleteVehicle(1L));
		verify(vehicleRepository, times(1)).save(vehicle);
	}

	@Test
	void testDeleteVehicle_Negative_VehicleNotFound() {
		when(vehicleRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(VehicleNotFoundException.class, () -> vehicleService.deleteVehicle(1L));
	}

	@Test
	void testGetVehicleById_Positive() {
		when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));
		when(vehicleMapper.toDto(any())).thenReturn(vehicleDTO);

		Optional<VehicleDTO> foundVehicle = vehicleService.getVehicleById(1L);
		assertTrue(foundVehicle.isPresent());
		assertEquals("Sedan", foundVehicle.get().getModelName());
	}

	@Test
	void testGetVehicleById_Negative_VehicleNotFound() {
		when(vehicleRepository.findById(1L)).thenReturn(Optional.empty());

		Optional<VehicleDTO> foundVehicle = vehicleService.getVehicleById(1L);
		assertFalse(foundVehicle.isPresent());
	}

	@Test
	void testGetAllVehicles_Positive() {
		List<Vehicle> vehicles = List.of(vehicle);
		when(vehicleRepository.findAll()).thenReturn(vehicles);
		when(vehicleMapper.toDto(any())).thenReturn(vehicleDTO);

		List<VehicleDTO> vehicleList = vehicleService.getAllVehicles();
		assertFalse(vehicleList.isEmpty());
	}

	@Test
	void testGetAllVehicles_Negative_EmptyList() {
		when(vehicleRepository.findAll()).thenReturn(Collections.emptyList());

		List<VehicleDTO> vehicleList = vehicleService.getAllVehicles();
		assertTrue(vehicleList.isEmpty());
	}

	@Test
	void testCheckIfVehicleExistsByRegistrationNumber_Positive() {
		when(vehicleRepository.findByRegistrationNumber("KA01AB1234")).thenReturn(Optional.of(vehicle));
		assertTrue(vehicleService.checkIfVehicleExistsByRegistrationNumber("KA01AB1234"));
	}

	@Test
	void testCheckIfVehicleExistsByRegistrationNumber_Negative() {
		when(vehicleRepository.findByRegistrationNumber("KA01AB4321")).thenReturn(Optional.empty());
		assertFalse(vehicleService.checkIfVehicleExistsByRegistrationNumber("KA01AB4321"));
	}

	@Test
	void testSearchVehicles_Positive() {
		when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));
		when(vehicleMapper.toDto(vehicle1)).thenReturn(vehicleDTO1);

		List<VehicleDTO> results = vehicleService.searchVehicles("Sedan");

		assertEquals(1, results.size());
		assertEquals("SedanX", results.get(0).getModelName());
	}

	@Test
	void testSearchVehicles_Negative() {
		when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));

		List<VehicleDTO> results = vehicleService.searchVehicles("Truck");

		assertTrue(results.isEmpty());
	}

	@Test
	void testSortVehicles_ByPricePerDay_Positive() {
		when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));
		when(vehicleMapper.toDto(vehicle1)).thenReturn(vehicleDTO1);
		when(vehicleMapper.toDto(vehicle2)).thenReturn(vehicleDTO2);

		List<VehicleDTO> results = vehicleService.sortVehicles("pricePerDay", true);

		assertEquals(2, results.size());
		assertEquals("SedanX", results.get(0).getModelName());
	}

	@Test
	void testSortVehicles_ByModelYear_Positive() {
	    when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));
	    when(vehicleMapper.toDto(vehicle1)).thenReturn(vehicleDTO1);
	    when(vehicleMapper.toDto(vehicle2)).thenReturn(vehicleDTO2);

	    List<VehicleDTO> results = vehicleService.sortVehicles("modelYear", true);

	    assertEquals(2, results.size());
	    assertEquals("SedanX", results.get(0).getModelName()); 
	    assertEquals("SUVY", results.get(1).getModelName());   
	}

	@Test
	void testSortVehicles_Negative() {
		when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));

		Exception exception = assertThrows(IllegalArgumentException.class,
				() -> vehicleService.sortVehicles("unknown", true));

		assertTrue(exception.getMessage().contains("Invalid sort attribute"));
	}

	@Test
	void testFilterVehiclesByCategory_Positive() {
		VehicleFilterCriteriaDTO criteria = new VehicleFilterCriteriaDTO("Suv",null,null,null);

		when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));
		when(vehicleMapper.toDto(vehicle2)).thenReturn(vehicleDTO2);

		List<VehicleDTO> results = vehicleService.filterVehicles(criteria);

		assertEquals(1, results.size());
		assertEquals("SUVY", results.get(0).getModelName());
	}

	@Test
	void testFilterVehiclesByColor_Positive() {
		VehicleFilterCriteriaDTO criteria = new VehicleFilterCriteriaDTO("Sedan","Petrol","1000-1500","Red");

		when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));
		when(vehicleMapper.toDto(vehicle1)).thenReturn(vehicleDTO1);

		List<VehicleDTO> results = vehicleService.filterVehicles(criteria);

		assertEquals(1, results.size());
		assertEquals("SedanX", results.get(0).getModelName());
	}

	@Test
	void testFilterVehiclesByPrice_LessThan500() {
	    VehicleFilterCriteriaDTO criteria = new VehicleFilterCriteriaDTO("Sedan","Petrol","<500","Red");

	    when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));

	    List<VehicleDTO> results = vehicleService.filterVehicles(criteria);

	    assertEquals(0, results.size()); 
	}

	@Test
	void testFilterVehiclesByPrice_500To1000() {
	    VehicleFilterCriteriaDTO criteria = new VehicleFilterCriteriaDTO("Sedan","Petrol","500-1000","Red");

	    when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));

	    List<VehicleDTO> results = vehicleService.filterVehicles(criteria);

	    assertEquals(0, results.size()); 
	}

	@Test
	void testFilterVehiclesByPrice_1000To1500() {
	    VehicleFilterCriteriaDTO criteria = new VehicleFilterCriteriaDTO("Sedan","Petrol","1000-1500","Red");

	    when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));
	    when(vehicleMapper.toDto(vehicle1)).thenReturn(vehicleDTO1);

	    List<VehicleDTO> results = vehicleService.filterVehicles(criteria);

	    assertEquals(1, results.size());
	    assertEquals(1500.0, results.get(0).getPricePerDay());
	}

	@Test
	void testFilterVehiclesByPrice_1500To2000() {
	    VehicleFilterCriteriaDTO criteria = new VehicleFilterCriteriaDTO(null,null,"1500-2000",null);

	    when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));
	    when(vehicleMapper.toDto(vehicle1)).thenReturn(vehicleDTO1);
	    when(vehicleMapper.toDto(vehicle2)).thenReturn(vehicleDTO2);

	    List<VehicleDTO> results = vehicleService.filterVehicles(criteria);

	    assertEquals(2, results.size()); 
	    assertTrue(results.stream().anyMatch(v -> v.getPricePerDay() == 1500.0));
	    assertTrue(results.stream().anyMatch(v -> v.getPricePerDay() == 2000.0));
	}

	@Test
	void testFilterVehiclesByPrice_GreaterThan2000() {
	    VehicleFilterCriteriaDTO criteria = new VehicleFilterCriteriaDTO("Sedan","Petrol",">2000","Red");

	    when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));

	    List<VehicleDTO> results = vehicleService.filterVehicles(criteria);

	    assertEquals(0, results.size()); 
	}


	@Test
	void testFilterVehiclesByFuelType_Positive() {
		VehicleFilterCriteriaDTO criteria = new VehicleFilterCriteriaDTO(null,"Diesel",null,null);

		when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));
		when(vehicleMapper.toDto(vehicle2)).thenReturn(vehicleDTO2);

		List<VehicleDTO> results = vehicleService.filterVehicles(criteria);

		assertEquals(1, results.size());
		assertEquals("SUVY", results.get(0).getModelName());
	}

	@Test
	void testFilterVehicles_Negative() {
		VehicleFilterCriteriaDTO criteria = new VehicleFilterCriteriaDTO("Van","Petrol","1000-1500","Red");

		when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Arrays.asList(vehicle1, vehicle2));

		List<VehicleDTO> results = vehicleService.filterVehicles(criteria);

		assertTrue(results.isEmpty());
	}

	@Test
	void testCompareVehicles_Positive() {
		List<Long> vehicleIds = Arrays.asList(1L, 2L);
		when(vehicleRepository.findAllById(vehicleIds)).thenReturn(Arrays.asList(vehicle1, vehicle2));

		List<VehicleComparisonDTO> results = vehicleService.compareVehicles(vehicleIds);

		assertEquals(6, results.size());
	}

	@Test
	void testCompareVehicles_Negative_InvalidSize() {
		List<Long> vehicleIds = Arrays.asList(1L);

		Exception exception = assertThrows(IllegalArgumentException.class,
				() -> vehicleService.compareVehicles(vehicleIds));

		assertTrue(exception.getMessage().contains("Exactly two vehicle IDs are required for comparison."));
	}

	@Test
	void testGetVehicleByModelName_Positive() {
		when(vehicleRepository.findByModelNameIgnoreCase("Sedan")).thenReturn(List.of(vehicle));
		when(vehicleMapper.toDto(vehicle)).thenReturn(vehicleDTO);

		Optional<VehicleDTO> result = vehicleService.getVehicleByModelName("Sedan");

		assertTrue(result.isPresent());
		assertEquals("Sedan", result.get().getModelName());
	}

	@Test
	void testGetVehicleByModelName_Negative() {
		when(vehicleRepository.findByModelNameIgnoreCase("SUV")).thenReturn(Collections.emptyList());

		Optional<VehicleDTO> result = vehicleService.getVehicleByModelName("SUV");

		assertFalse(result.isPresent());
	}

	@Test
	void testFilterByColor_Positive() throws Exception {
		Vehicle testVehicle = new Vehicle();
		testVehicle.setColor("Red");

		Method method = VehicleServiceImpl.class.getDeclaredMethod("filterByColor", Vehicle.class, String.class);
		method.setAccessible(true);

		boolean result = (boolean) method.invoke(
				new VehicleServiceImpl(vehicleRepository, userRepository, vehicleMapper, bookingRepository),
				testVehicle, "Red");
		assertTrue(result);
	}

	@Test
	void testFilterByColor_Negative() throws Exception {
		Vehicle testVehicle = new Vehicle();
		testVehicle.setColor("Red");

		Method method = VehicleServiceImpl.class.getDeclaredMethod("filterByColor", Vehicle.class, String.class);
		method.setAccessible(true);

		boolean result = (boolean) method.invoke(
				new VehicleServiceImpl(vehicleRepository, userRepository, vehicleMapper, bookingRepository),
				testVehicle, "Blue");
		assertFalse(result);
	}

	@Test
	void testFilterByPrice_Positive() throws Exception {
		Vehicle testVehicle = new Vehicle();
		testVehicle.setPricePerDay(1200.0);

		Method method = VehicleServiceImpl.class.getDeclaredMethod("filterByPrice", Vehicle.class, String.class);
		method.setAccessible(true);

		boolean result = (boolean) method.invoke(
				new VehicleServiceImpl(vehicleRepository, userRepository, vehicleMapper, bookingRepository),
				testVehicle, "1000-1500");
		assertTrue(result);
	}

	@Test
	void testFilterByPrice_Negative() throws Exception {
		Vehicle testVehicle = new Vehicle();
		testVehicle.setPricePerDay(400.0);

		Method method = VehicleServiceImpl.class.getDeclaredMethod("filterByPrice", Vehicle.class, String.class);
		method.setAccessible(true);

		boolean result = (boolean) method.invoke(
				new VehicleServiceImpl(vehicleRepository, userRepository, vehicleMapper, bookingRepository),
				testVehicle, "500-1000");
		assertFalse(result);
	}

	@Test
	void testFilterByFuelType_Positive() throws Exception {
		Vehicle testVehicle = new Vehicle();
		testVehicle.setFuelType("Petrol");

		Method method = VehicleServiceImpl.class.getDeclaredMethod("filterByFuelType", Vehicle.class, String.class);
		method.setAccessible(true);

		boolean result = (boolean) method.invoke(
				new VehicleServiceImpl(vehicleRepository, userRepository, vehicleMapper, bookingRepository),
				testVehicle, "Petrol");
		assertTrue(result);
	}

	@Test
	void testFilterByFuelType_Negative() throws Exception {
		Vehicle testVehicle = new Vehicle();
		testVehicle.setFuelType("Petrol");

		Method method = VehicleServiceImpl.class.getDeclaredMethod("filterByFuelType", Vehicle.class, String.class);
		method.setAccessible(true);

		boolean result = (boolean) method.invoke(
				new VehicleServiceImpl(vehicleRepository, userRepository, vehicleMapper, bookingRepository),
				testVehicle, "Diesel");
		assertFalse(result);
	}

	@Test
	void testAddVehicleBookingDate_Positive() {
		VehicleBookingDateDTO bookingDateDTO = new VehicleBookingDateDTO();
		bookingDateDTO.setBookedDate(LocalDate.of(2025, 3, 1));

		vehicle = new Vehicle();
		vehicle.setVehicleBookingDates(new ArrayList<>());

		when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));

		assertDoesNotThrow(() -> vehicleService.addVehicleBookingDate(1L, bookingDateDTO));
		verify(vehicleRepository, times(1)).save(vehicle);
	}

	@Test
	void testAddVehicleBookingDate_Negative_VehicleNotFound() {
		VehicleBookingDateDTO bookingDateDTO = new VehicleBookingDateDTO();
		bookingDateDTO.setBookedDate(LocalDate.of(2025, 3, 1));

		when(vehicleRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(VehicleNotFoundException.class, () -> vehicleService.addVehicleBookingDate(1L, bookingDateDTO));
	}

	@Test
	void testGetTotalVehicles_Positive() {
		when(vehicleRepository.countByIsDeletedFalse()).thenReturn(10L);

		long result = vehicleService.getTotalVehicles();
		assertEquals(10L, result);
	}

	@Test
	void testGetTotalVehicles_Negative_ZeroCount() {
		when(vehicleRepository.countByIsDeletedFalse()).thenReturn(0L);

		long result = vehicleService.getTotalVehicles();
		assertEquals(0L, result);
	}
}
