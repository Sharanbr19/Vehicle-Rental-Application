package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.RentalAgreementDTO;
import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.RentalAgreement;
import com.endava.vehiclerentalapp.mapper.RentalAgreementMapper;
import com.endava.vehiclerentalapp.repository.BookingRepository;
import com.endava.vehiclerentalapp.repository.RentalAgreementRepository;
import com.endava.vehiclerentalapp.util.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RentalAgreementServiceImplTest {

    @Mock
    private RentalAgreementRepository rentalAgreementRepository;

    @Mock
    private BookingRepository bookingRepository;

    @Mock
    private RentalAgreementMapper rentalAgreementMapper;

    @InjectMocks
    private RentalAgreementServiceImpl rentalAgreementService;

    private RentalAgreement rentalAgreement;
    private RentalAgreementDTO rentalAgreementDTO;
    private Booking booking;

    @BeforeEach
    void setUp() {
        booking = new Booking();
        booking.setBookingId(1L);

        rentalAgreement = new RentalAgreement();
        rentalAgreement.setRentalId(1L);
        rentalAgreement.setBooking(booking);

        rentalAgreementDTO = new RentalAgreementDTO();
        rentalAgreementDTO.setRentalId(1L);
        rentalAgreementDTO.setBookingId(1L);
    }

    @Test
    void testCreateRentalAgreement_Success() {
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
        when(rentalAgreementMapper.toEntity(rentalAgreementDTO)).thenReturn(rentalAgreement);
        when(rentalAgreementRepository.save(rentalAgreement)).thenReturn(rentalAgreement);
        when(rentalAgreementMapper.toDTO(rentalAgreement)).thenReturn(rentalAgreementDTO);

        RentalAgreementDTO createdAgreement = rentalAgreementService.createRentalAgreement(rentalAgreementDTO);

        assertNotNull(createdAgreement);
        assertEquals(1L, createdAgreement.getRentalId());
        verify(rentalAgreementRepository, times(1)).save(rentalAgreement);
    }

    @Test
    void testCreateRentalAgreement_BookingNotFound() {
        when(bookingRepository.findById(1L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, 
            () -> rentalAgreementService.createRentalAgreement(rentalAgreementDTO));
        assertEquals(Constants.BOOKING_NOT_FOUND, exception.getMessage());
    }

    @Test
    void testGetRentalAgreementById_Success() {
        when(rentalAgreementRepository.findById(1L)).thenReturn(Optional.of(rentalAgreement));
        when(rentalAgreementMapper.toDTO(rentalAgreement)).thenReturn(rentalAgreementDTO);

        RentalAgreementDTO foundAgreement = rentalAgreementService.getRentalAgreementById(1L);

        assertNotNull(foundAgreement);
        assertEquals(1L, foundAgreement.getRentalId());
    }

    @Test
    void testGetRentalAgreementById_NotFound() {
        when(rentalAgreementRepository.findById(1L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, 
            () -> rentalAgreementService.getRentalAgreementById(1L));
        assertEquals(Constants.RENTAL_AGREEMENT_NOT_FOUND, exception.getMessage());
    }

    @Test
    void testGetAllRentalAgreements_Success() {
        when(rentalAgreementRepository.findAll()).thenReturn(List.of(rentalAgreement));
        when(rentalAgreementMapper.toDTO(rentalAgreement)).thenReturn(rentalAgreementDTO);

        List<RentalAgreementDTO> agreements = rentalAgreementService.getAllRentalAgreements();

        assertEquals(1, agreements.size());
        assertEquals(1L, agreements.get(0).getRentalId());
    }

    @Test
    void testGetAllRentalAgreements_EmptyList() {
        when(rentalAgreementRepository.findAll()).thenReturn(List.of());

        List<RentalAgreementDTO> agreements = rentalAgreementService.getAllRentalAgreements();

        assertTrue(agreements.isEmpty());
    }

    @Test
    void testGetRentalAgreementByCustomerId_Success() {
        when(rentalAgreementRepository.findByBooking_Customer_UserId(1L)).thenReturn(List.of(rentalAgreement));
        when(rentalAgreementMapper.toDTO(rentalAgreement)).thenReturn(rentalAgreementDTO);

        List<RentalAgreementDTO> agreements = rentalAgreementService.getRentalAgreementByCustomerId(1L);

        assertEquals(1, agreements.size());
        assertEquals(1L, agreements.get(0).getRentalId());
    }

    @Test
    void testGetRentalAgreementByCustomerId_NoAgreements() {
        when(rentalAgreementRepository.findByBooking_Customer_UserId(1L)).thenReturn(List.of());

        List<RentalAgreementDTO> agreements = rentalAgreementService.getRentalAgreementByCustomerId(1L);

        assertTrue(agreements.isEmpty());
    }

    @Test
    void testDeleteRentalAgreement_Success() {
        doNothing().when(rentalAgreementRepository).deleteById(1L);

        rentalAgreementService.deleteRentalAgreement(1L);

        verify(rentalAgreementRepository, times(1)).deleteById(1L);
    }
}

