package com.endava.vehiclerentalapp.service.implementation;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mail.javamail.JavaMailSender;

class MailServiceTest {

    @Mock
    private JavaMailSender mailSender;

    @Mock
    private MimeMessage mimeMessage;

    @InjectMocks
    private MailService mailService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(mailSender.createMimeMessage()).thenReturn(mimeMessage);
    }

    @Test
    void testSendHtmlEmail_Success() {
        assertDoesNotThrow(() -> {
            mailService.sendHtmlEmail("test@gmail.com", "Test Subject", "<h1>Hello</h1>");
        });

        verify(mailSender, times(1)).send(mimeMessage);
    }

    @Test
    void testSendHtmlEmail_MessagingExceptionThrown() {
        doThrow(new RuntimeException("Error sending email")).when(mailSender).send(any(MimeMessage.class));

        Exception exception = assertThrows(RuntimeException.class, () -> {
            mailService.sendHtmlEmail("test@gmail.com", "Test Subject", "<h1>Hello</h1>");
        });

        assertEquals("Error sending email", exception.getMessage());
    }


    @Test
    void testSendHtmlEmail_InvalidRecipient() {
        Exception exception = assertThrows(MessagingException.class, () -> {
            mailService.sendHtmlEmail("", "Test Subject", "<h1>Hello</h1>");
        });

        assertEquals("Illegal address", exception.getMessage());
    }
}

