package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.FavoriteDTO;
import com.endava.vehiclerentalapp.entity.Favorite;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.entity.Vehicle;
import com.endava.vehiclerentalapp.exceptions.CustomerNotFoundException;
import com.endava.vehiclerentalapp.exceptions.FavoriteAlreadyExistsException;
import com.endava.vehiclerentalapp.exceptions.FavoriteNotFoundException;
import com.endava.vehiclerentalapp.exceptions.VehicleNotFoundException;
import com.endava.vehiclerentalapp.mapper.FavoriteMapper;
import com.endava.vehiclerentalapp.repository.FavoriteRepository;
import com.endava.vehiclerentalapp.repository.UserRepository;
import com.endava.vehiclerentalapp.repository.VehicleRepository;
import com.endava.vehiclerentalapp.util.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.List;
import java.util.Optional;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FavoriteServiceImplTest {

    @Mock
    private FavoriteRepository favoriteRepository;

    @Mock
    private UserRepository usersRepository;

    @Mock
    private VehicleRepository vehicleRepository;

    @Mock
    private FavoriteMapper favoriteMapper;

    @InjectMocks
    private FavoriteServiceImpl favoriteService;

    private FavoriteDTO favoriteDTO;
    private Favorite favorite;
    private Users customer;
    private Vehicle vehicle;

    @BeforeEach
    void setUp() {
        favoriteDTO = new FavoriteDTO();
        favoriteDTO.setUserId(1L);
        favoriteDTO.setVehicleId(2L);

        customer = new Users();
        customer.setUserId(1L);

        vehicle = new Vehicle();
        vehicle.setVehicleId(2L);

        favorite = new Favorite();
        favorite.setCustomer(customer);
        favorite.setVehicle(vehicle);
    }

    @Test
    void testAddFavorite_Success() {
        when(usersRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(vehicleRepository.findById(2L)).thenReturn(Optional.of(vehicle));
        when(favoriteRepository.existsByCustomerAndVehicle(customer, vehicle)).thenReturn(false);
        when(favoriteRepository.save(any(Favorite.class))).thenReturn(favorite);
        when(favoriteMapper.toDto(favorite)).thenReturn(favoriteDTO);

        FavoriteDTO result = favoriteService.addFavorite(favoriteDTO);

        assertNotNull(result);
        assertEquals(favoriteDTO.getUserId(), result.getUserId());
        assertEquals(favoriteDTO.getVehicleId(), result.getVehicleId());
        verify(favoriteRepository, times(1)).save(any(Favorite.class));
    }

    @Test
    void testRemoveFavorite_Success() {
        when(favoriteRepository.findByCustomer_UserIdAndVehicle_VehicleId(1L, 2L))
                .thenReturn(Optional.of(favorite));

        assertDoesNotThrow(() -> favoriteService.removeFavorite(1L, 2L));

        verify(favoriteRepository, times(1)).delete(favorite);
    }

    @Test
    void testGetFavoritesByCustomer_Success() {
        List<Favorite> favoriteList = new ArrayList<>();
        favoriteList.add(favorite);

        when(usersRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(favoriteRepository.findByCustomer(customer)).thenReturn(favoriteList);
        when(favoriteMapper.toDto(favorite)).thenReturn(favoriteDTO);

        List<FavoriteDTO> result = favoriteService.getFavoritesByCustomer(1L);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(favoriteRepository, times(1)).findByCustomer(customer);
    }


    @Test
    void testAddFavorite_CustomerNotFound() {
        when(usersRepository.findById(1L)).thenReturn(Optional.empty());

        CustomerNotFoundException exception = assertThrows(CustomerNotFoundException.class, () -> {
            favoriteService.addFavorite(favoriteDTO);
        });

        assertEquals(Constants.USER_NOT_FOUND + "1", exception.getMessage());
        verify(favoriteRepository, never()).save(any());
    }

    @Test
    void testAddFavorite_VehicleNotFound() {
        when(usersRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(vehicleRepository.findById(2L)).thenReturn(Optional.empty());

        VehicleNotFoundException exception = assertThrows(VehicleNotFoundException.class, () -> {
            favoriteService.addFavorite(favoriteDTO);
        });

        assertEquals(Constants.VEHICLE_NOT_FOUND + "2", exception.getMessage());
        verify(favoriteRepository, never()).save(any());
    }

    @Test
    void testAddFavorite_AlreadyExists() {
        when(usersRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(vehicleRepository.findById(2L)).thenReturn(Optional.of(vehicle));
        when(favoriteRepository.existsByCustomerAndVehicle(customer, vehicle)).thenReturn(true);

        FavoriteAlreadyExistsException exception = assertThrows(FavoriteAlreadyExistsException.class, () -> {
            favoriteService.addFavorite(favoriteDTO);
        });

        assertEquals(Constants.FAVORITE_ALREADY_EXIST + "1 and Vehicle ID: 2", exception.getMessage());
        verify(favoriteRepository, never()).save(any());
    }

    @Test
    void testRemoveFavorite_NotFound() {
        when(favoriteRepository.findByCustomer_UserIdAndVehicle_VehicleId(1L, 2L))
                .thenReturn(Optional.empty());

        FavoriteNotFoundException exception = assertThrows(FavoriteNotFoundException.class, () -> {
            favoriteService.removeFavorite(1L, 2L);
        });

        assertEquals(Constants.FAVORITE_NOT_FOUND + "1 and Vehicle ID: 2", exception.getMessage());
        verify(favoriteRepository, never()).delete(any());
    }

    @Test
    void testGetFavoritesByCustomer_CustomerNotFound() {
        when(usersRepository.findById(1L)).thenReturn(Optional.empty());

        CustomerNotFoundException exception = assertThrows(CustomerNotFoundException.class, () -> {
            favoriteService.getFavoritesByCustomer(1L);
        });

        assertEquals(Constants.USER_NOT_FOUND + "1", exception.getMessage());
        verify(favoriteRepository, never()).findByCustomer(any());
    }

    @Test
    void testGetFavoritesByCustomer_EmptyList() {
        when(usersRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(favoriteRepository.findByCustomer(customer)).thenReturn(new ArrayList<>());

        List<FavoriteDTO> result = favoriteService.getFavoritesByCustomer(1L);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}
