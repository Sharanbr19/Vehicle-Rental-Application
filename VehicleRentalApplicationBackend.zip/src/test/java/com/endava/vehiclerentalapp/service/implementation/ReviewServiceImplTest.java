package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.ReviewDTO;
import com.endava.vehiclerentalapp.entity.Review;
import com.endava.vehiclerentalapp.mapper.ReviewMapper;
import com.endava.vehiclerentalapp.repository.ReviewRepository;
import com.endava.vehiclerentalapp.util.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReviewServiceImplTest {

	@Mock
	private ReviewRepository reviewRepository;

	@Mock
	private ReviewMapper reviewMapper;

	@InjectMocks
	private ReviewServiceImpl reviewService;

	private Review review;
	private ReviewDTO reviewDTO;

	@BeforeEach
	void setUp() {
		review = new Review();
		review.setReviewId(1L);
		review.setRating("5");
		review.setComment("Great vehicle!");
	
		reviewDTO = new ReviewDTO(1L, "5", "Great vehicle!", 1L, 1L);
	}

	@Test
	void testCreateReview_Success() {
		when(reviewRepository.existsByCustomer_UserIdAndVehicle_VehicleId(1L, 1L)).thenReturn(false);
		when(reviewMapper.toEntity(reviewDTO)).thenReturn(review);
		when(reviewRepository.save(review)).thenReturn(review);
		when(reviewMapper.toDTO(review)).thenReturn(reviewDTO);

		ReviewDTO createdReview = reviewService.createReview(reviewDTO);

		assertNotNull(createdReview);
		assertEquals("5", createdReview.getRating());
		verify(reviewRepository, times(1)).save(review);
	}

	@Test
	void testCreateReview_UserAlreadyReviewed() {
		when(reviewRepository.existsByCustomer_UserIdAndVehicle_VehicleId(1L, 1L)).thenReturn(true);

		IllegalStateException exception = assertThrows(IllegalStateException.class,
				() -> reviewService.createReview(reviewDTO));
		assertEquals(Constants.USER_ALREADY_REVIEWED, exception.getMessage());
	}

	@Test
	void testUpdateReview_Success() {
		when(reviewRepository.findByCustomer_UserIdAndVehicle_VehicleId(1L, 1L)).thenReturn(Optional.of(review));
		when(reviewRepository.save(review)).thenReturn(review);
		when(reviewMapper.toDTO(review)).thenReturn(reviewDTO);

		ReviewDTO updatedReview = reviewService.updateReview(1L, 1L, reviewDTO);

		assertNotNull(updatedReview);
		assertEquals("Great vehicle!", updatedReview.getComment());
		verify(reviewRepository, times(1)).save(review);
	}

	@Test
	void testUpdateReview_NotFound() {
		when(reviewRepository.findByCustomer_UserIdAndVehicle_VehicleId(1L, 1L)).thenReturn(Optional.empty());

		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
				() -> reviewService.updateReview(1L, 1L, reviewDTO));
		assertEquals(Constants.REVIEW_NOT_FOUND, exception.getMessage());
	}

	@Test
	void testDeleteReview_Success() {
		when(reviewRepository.findByCustomer_UserIdAndVehicle_VehicleId(1L, 1L)).thenReturn(Optional.of(review));

		reviewService.deleteReview(1L, 1L);

		verify(reviewRepository, times(1)).delete(review);
	}

	@Test
	void testDeleteReview_NotFound() {
		when(reviewRepository.findByCustomer_UserIdAndVehicle_VehicleId(1L, 1L)).thenReturn(Optional.empty());

		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
				() -> reviewService.deleteReview(1L, 1L));
		assertEquals(Constants.REVIEW_NOT_FOUND, exception.getMessage());
	}

	@Test
	void testGetReview_Success() {
		when(reviewRepository.findById(1L)).thenReturn(Optional.of(review));
		when(reviewMapper.toDTO(review)).thenReturn(reviewDTO);

		ReviewDTO foundReview = reviewService.getReview(1L);

		assertNotNull(foundReview);
		assertEquals("5", foundReview.getRating());
	}

	@Test
	void testGetReview_NotFound() {
		when(reviewRepository.findById(1L)).thenReturn(Optional.empty());

		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
				() -> reviewService.getReview(1L));
		assertEquals(Constants.REVIEW_NOT_FOUND, exception.getMessage());
	}

	@Test
	void testGetAllReviews_Success() {
		when(reviewRepository.findAll()).thenReturn(List.of(review));
		when(reviewMapper.toDTO(review)).thenReturn(reviewDTO);

		List<ReviewDTO> reviews = reviewService.getAllReviews();

		assertEquals(1, reviews.size());
		assertEquals("Great vehicle!", reviews.get(0).getComment());
	}

	@Test
	void testGetAllReviews_Empty() {
		when(reviewRepository.findAll()).thenReturn(List.of());

		List<ReviewDTO> reviews = reviewService.getAllReviews();

		assertTrue(reviews.isEmpty());
	}

	@Test
	void testGetReviewsByVehicleId_Success() {
		when(reviewRepository.findByVehicle_VehicleId(1L)).thenReturn(List.of(review));
		when(reviewMapper.toDTO(review)).thenReturn(reviewDTO);

		List<ReviewDTO> reviews = reviewService.getReviewsByVehicleId(1L);

		assertEquals(1, reviews.size());
		assertEquals("5", reviews.get(0).getRating());
	}

	@Test
	void testGetReviewsByVehicleId_NoReviews() {
		when(reviewRepository.findByVehicle_VehicleId(1L)).thenReturn(List.of());

		List<ReviewDTO> reviews = reviewService.getReviewsByVehicleId(1L);

		assertTrue(reviews.isEmpty());
	}

	@Test
	void testGetReviewsByCustomerId_Success() {
		when(reviewRepository.findByCustomer_UserId(1L)).thenReturn(List.of(review));
		when(reviewMapper.toDTO(review)).thenReturn(reviewDTO);

		List<ReviewDTO> reviews = reviewService.getReviewsByCustomerId(1L);

		assertEquals(1, reviews.size());
		assertEquals("Great vehicle!", reviews.get(0).getComment());
	}

	@Test
	void testGetReviewsByCustomerId_NoReviews() {
		when(reviewRepository.findByCustomer_UserId(1L)).thenReturn(List.of());

		List<ReviewDTO> reviews = reviewService.getReviewsByCustomerId(1L);

		assertTrue(reviews.isEmpty());
	}

	@Test
	void testGetAverageRatingByVehicleId_Success() {
		when(reviewRepository.findAverageRatingByVehicleId(1L)).thenReturn(4.5);

		Double avgRating = reviewService.getAverageRatingByVehicleId(1L);

		assertEquals(4.5, avgRating);
	}

	@Test
	void testGetAverageRatingByVehicleId_NoReviews() {
		when(reviewRepository.findAverageRatingByVehicleId(1L)).thenReturn(null);

		Double avgRating = reviewService.getAverageRatingByVehicleId(1L);

		assertEquals(0.0, avgRating);
	}
}
