package com.endava.vehiclerentalapp.service.implementation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.endava.vehiclerentalapp.dto.BookingDTO;
import com.endava.vehiclerentalapp.dto.VehicleDTO;
import com.endava.vehiclerentalapp.entity.*;
import com.endava.vehiclerentalapp.exceptions.CustomerNotFoundException;
import com.endava.vehiclerentalapp.exceptions.DriverNotFoundException;
import com.endava.vehiclerentalapp.exceptions.VehicleNotFoundException;
import com.endava.vehiclerentalapp.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
class BookingServiceImplTest {

	@InjectMocks
	private BookingServiceImpl bookingService;

	@Mock
	private BookingRepository bookingRepository;

	@Mock
	private UserRepository userRepository;

	@Mock
	private VehicleRepository vehicleRepository;

	@Mock
	private DriverRepository driverRepository;

	@Mock
	private DiscountRepository discountRepository;

	@Mock
	private VehicleBookingDateRepository vehicleBookingDateRepository;

	@Mock
	private DriverBookingDateRepository driverBookingDateRepository;

	private BookingDTO bookingDTO;
	private Booking booking;
	private Users customer;
	private Vehicle vehicle;
	private Driver driver;

	@BeforeEach
	void setUp() {
		customer = new Users();
		customer.setUserId(1L);

		vehicle = new Vehicle();
		vehicle.setVehicleId(1L);
		vehicle.setPricePerDay(100.0);

		driver = new Driver();
		driver.setDriverId(1L);
		driver.setDriverCostPerDay(50.0);

		bookingDTO = new BookingDTO();
		bookingDTO.setCustomerId(1L);
		bookingDTO.setVehicleId(1L);
		bookingDTO.setFromDate(LocalDate.now());
		bookingDTO.setToDate(LocalDate.now().plusDays(3));
		bookingDTO.setWantsDriver(true);
		bookingDTO.setDriverId(1L);

		booking = new Booking();
		booking.setBookingId(1L);
		booking.setCustomer(customer);
		booking.setVehicle(vehicle);
		booking.setDriver(driver);
		booking.setFromDate(LocalDate.now());
		booking.setToDate(LocalDate.now().plusDays(3));
	}

	@Test
	void createBooking_Success() throws IllegalAccessException, IllegalArgumentException, InvocationTargetException,
			NoSuchMethodException, SecurityException {
		bookingDTO.setCustomerId(1L);
		bookingDTO.setVehicleId(1L);
		bookingDTO.setFromDate(LocalDate.now());
		bookingDTO.setToDate(LocalDate.now().plusDays(3));
		bookingDTO.setWantsDriver(true);

		when(userRepository.findById(1L)).thenReturn(Optional.of(customer));
		when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));
		when(bookingRepository.countOverlappingBookings(anyLong(), any(), any())).thenReturn(0L);
		when(bookingRepository.save(any(Booking.class))).thenReturn(booking);

		Discount discount = new Discount();
		discount.setDiscountPercentage(10.0);

		when(discountRepository.findHighestDiscountForVehicle(anyLong())).thenReturn(Optional.of(discount));

		if (bookingDTO.getWantsDriver()) {
			when(driverRepository.findById(1L)).thenReturn(Optional.of(driver));
			Method getAvailableDriverMethod = BookingServiceImpl.class.getDeclaredMethod("getAvailableDriver",
					BookingDTO.class);
			getAvailableDriverMethod.setAccessible(true);
			getAvailableDriverMethod.invoke(bookingService, bookingDTO);
		}

		BookingDTO result = bookingService.createBooking(bookingDTO);

		assertNotNull(result);
		assertEquals(1L, result.getCustomerId());
		assertEquals(1L, result.getVehicleId());
	}

	@Test
	void createBooking_CustomerNotFound() {
		when(userRepository.findById(1L)).thenReturn(Optional.empty());
		assertThrows(CustomerNotFoundException.class, () -> bookingService.createBooking(bookingDTO));
	}

	@Test
	void createBooking_VehicleNotFound() {
		when(userRepository.findById(1L)).thenReturn(Optional.of(customer));
		when(vehicleRepository.findById(1L)).thenReturn(Optional.empty());
		assertThrows(VehicleNotFoundException.class, () -> bookingService.createBooking(bookingDTO));
	}

	@Test
	void getBookingById_Success() {
		when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
		BookingDTO result = bookingService.getBookingById(1L);
		assertNotNull(result);
	}

	@Test
	void getBookingById_NotFound() {
		when(bookingRepository.findById(1L)).thenReturn(Optional.empty());
		assertThrows(RuntimeException.class, () -> bookingService.getBookingById(1L));
	}

	@Test
	void getBookingsByCustomerId_Success() {
		when(bookingRepository.findByCustomer_UserId(1L)).thenReturn(List.of(booking));
		List<BookingDTO> results = bookingService.getBookingsByCustomerId(1L);
		assertFalse(results.isEmpty());
	}

	@Test
	void getBookingsByCustomerId_NoBookings() {
		when(bookingRepository.findByCustomer_UserId(1L)).thenReturn(Collections.emptyList());
		List<BookingDTO> results = bookingService.getBookingsByCustomerId(1L);
		assertTrue(results.isEmpty());
	}

	@Test
	void getAvailableVehiclesBetweenDates_Success() {
		when(vehicleRepository.findByIsDeletedFalse()).thenReturn(List.of(vehicle));
		when(vehicleBookingDateRepository.findAll()).thenReturn(Collections.emptyList());

		List<VehicleDTO> results = bookingService.getAvailableVehiclesBetweenDates(LocalDate.now(),
				LocalDate.now().plusDays(3));
		assertFalse(results.isEmpty());
	}

	@Test
	void getAvailableVehiclesBetweenDates_NoVehicles() {
		when(vehicleRepository.findByIsDeletedFalse()).thenReturn(Collections.emptyList());
		List<VehicleDTO> results = bookingService.getAvailableVehiclesBetweenDates(LocalDate.now(),
				LocalDate.now().plusDays(3));
		assertTrue(results.isEmpty());
	}

	@Test
	void deleteBooking_Success() {
		when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
		doNothing().when(vehicleBookingDateRepository).deleteByVehicle_VehicleIdAndBooking_BookingId(anyLong(),
				anyLong());
		doNothing().when(driverBookingDateRepository).deleteByDriver_DriverIdAndBooking_BookingId(anyLong(), anyLong());

		assertDoesNotThrow(() -> bookingService.deleteBooking(1L));
	}

	@Test
	void deleteBooking_NotFound() {
		when(bookingRepository.findById(1L)).thenReturn(Optional.empty());
		assertThrows(RuntimeException.class, () -> bookingService.deleteBooking(1L));
	}

	@Test
	void getBookingsByVehicleId_Success() {
		when(bookingRepository.findAll()).thenReturn(List.of(booking));

		List<BookingDTO> results = bookingService.getBookingsByVehicleId(1L);

		assertFalse(results.isEmpty());
		assertEquals(1, results.size());
	}

	@Test
	void getBookingsByVehicleId_NotFound() {
		when(bookingRepository.findAll()).thenReturn(Collections.emptyList());

		assertThrows(VehicleNotFoundException.class, () -> bookingService.getBookingsByVehicleId(1L));
	}

	@Test
	void getAllBookings_Success() {
		when(bookingRepository.findAll()).thenReturn(List.of(booking));

		List<BookingDTO> results = bookingService.getAllBookings();

		assertFalse(results.isEmpty());
		assertEquals(1, results.size());
	}

	@Test
	void getAllBookings_EmptyList() {
		when(bookingRepository.findAll()).thenReturn(Collections.emptyList());

		List<BookingDTO> results = bookingService.getAllBookings();

		assertTrue(results.isEmpty());
	}

	@Test
	void updateBooking_Success() {
		when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
		when(vehicleRepository.findById(1L)).thenReturn(Optional.of(vehicle));
		when(driverRepository.findById(1L)).thenReturn(Optional.of(driver));
		when(bookingRepository.save(any(Booking.class))).thenReturn(booking);

		BookingDTO updatedBooking = bookingService.updateBooking(1L, bookingDTO);

		assertNotNull(updatedBooking);
		assertEquals(1L, updatedBooking.getVehicleId());
	}

	@Test
	void updateBooking_NotFound() {
		when(bookingRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(RuntimeException.class, () -> bookingService.updateBooking(1L, bookingDTO));
	}

	@Test
	void updateBooking_VehicleNotFound() {
		when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
		when(driverRepository.findById(1L)).thenReturn(Optional.of(driver));
		when(vehicleRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(VehicleNotFoundException.class, () -> bookingService.updateBooking(1L, bookingDTO));
	}

	@Test
	void updateBooking_DriverNotFound() {
		when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
		when(driverRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(DriverNotFoundException.class, () -> bookingService.updateBooking(1L, bookingDTO));
	}

	@Test
	void getTotalBookings_Success() {
		when(bookingRepository.countByStatus(BookingStatus.CONFIRMED)).thenReturn(5L);

		long totalBookings = bookingService.getTotalBookings();

		assertEquals(5L, totalBookings);
	}

	@Test
	void getTotalEarnings_Success() {
		when(bookingRepository.getTotalEarnings()).thenReturn(5000L);

		long totalEarnings = bookingService.getTotalEarnings();

		assertEquals(5000L, totalEarnings);
	}

	@Test
	void getEarningsByCategoryType_Success() {
		List<Object[]> mockResults = List.of(new Object[] { "SUV", 3000.0 }, new Object[] { "Sedan", 2000.0 });
		when(bookingRepository.getEarningsByCategoryType()).thenReturn(mockResults);

		List<Object[]> results = bookingService.getEarningsByCategoryType();

		assertNotNull(results);
		assertEquals(2, results.size());
	}

	@Test
	void getBookingCountByCategoryType_Success() {
		List<Object[]> mockResults = List.of(new Object[] { "SUV", 10 }, new Object[] { "Sedan", 5 });
		when(bookingRepository.getBookingCountByCategoryType()).thenReturn(mockResults);

		List<Object[]> results = bookingService.getBookingCountByCategoryType();

		assertNotNull(results);
		assertEquals(2, results.size());
	}

}
