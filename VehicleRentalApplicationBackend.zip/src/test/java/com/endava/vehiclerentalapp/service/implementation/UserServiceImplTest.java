package com.endava.vehiclerentalapp.service.implementation;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import com.endava.vehiclerentalapp.dto.UserDto;
import com.endava.vehiclerentalapp.entity.UserType;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.mapper.UserMapper;
import com.endava.vehiclerentalapp.repository.UserRepository;
import com.endava.vehiclerentalapp.util.jwtTokenUtil;
import jakarta.mail.MessagingException;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

	@Mock
	private UserRepository userRepository;

	@Mock
	private UserMapper userMapper;

	@Mock
	private BCryptPasswordEncoder passwordEncoder;

	@Mock
	private MailService mailService;

	@InjectMocks
	private UserServiceImpl userService;

	private Users user;
	private UserDto userDto;

	@BeforeEach
	void setUp() {
		user = new Users();
		user.setUserId(2L);
		user.setEmail("test@gmail.com");
		user.setPassword("encodedPassword");
		user.setUserType(UserType.CUSTOMER);
		user.setDeleted(false);
		userDto = new UserDto();
		userDto.setEmail("test@gmail.com");
		userDto.setPassword("plainPassword");
	}

	@Test
	void testCheckIfUserExistsByEmail_Positive() {
		when(userRepository.findByEmail("existinguser@gmail.com")).thenReturn(Optional.of(user));
		boolean exists = userService.checkIfUserExistsByEmail("existinguser@gmail.com");
		assertTrue(exists);
	}

	@Test
	void testCheckIfUserExistsByEmail_Negative() {
		when(userRepository.findByEmail("nonexistentuser@gmail.com")).thenReturn(Optional.empty());
		boolean exists = userService.checkIfUserExistsByEmail("nonexistentuser@gmail.com");
		assertFalse(exists);
	}

	@Test
	void testRegisterUser_Positive() {
		when(userMapper.toEntity(any(UserDto.class), anyString())).thenReturn(user);
		when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
		userService.registerUser(userDto, "admin@gmail.com");
		verify(userRepository, times(1)).save(user);
	}

	@Test
	void testLoginUser_Positive() {
		when(userRepository.findByEmail(("test@gmail.com"))).thenReturn(Optional.of(user));
		when(passwordEncoder.matches(eq("plainPassword"), anyString())).thenReturn(true);
		try (MockedStatic<jwtTokenUtil> mockedJwtTokenUtil = mockStatic(jwtTokenUtil.class)) {
			mockedJwtTokenUtil.when(() -> jwtTokenUtil.generateToken(anyString(), anyString())).thenReturn("mockToken");
			Optional<String> token = userService.loginUser("test@gmail.com", "plainPassword");
			assertTrue(token.isPresent());
			assertEquals("mockToken", token.get());
		}
	}

	@Test
	void testLoginUser_Negative_InvalidPassword() {
		when(userRepository.findByEmail("test@gmail.com")).thenReturn(Optional.of(user));
		when(passwordEncoder.matches("wrongPassword", "encodedPassword")).thenReturn(false);
		Optional<String> token = userService.loginUser("test@gmail.com", "wrongPassword");
		assertFalse(token.isPresent());
	}

	@Test
	void testValidateOtp_Positive() {
		String email = "test@gmail.com";
		String otp = "123456";
		userService.saveOtp(email, otp);
		boolean isValid = userService.validateOtp(email, otp);
		assertTrue(isValid);
	}

	@Test
	void testValidateOtp_Negative_WrongOtp() {
		String email = "test@gmail.com";
		userService.saveOtp(email, "123456");
		boolean isValid = userService.validateOtp(email, "654321");
		assertFalse(isValid);
	}
	
	@Test
	void testSendOtpToEmail_Positive() throws MessagingException {
		when(userRepository.findByEmail("newuser@gmail.com")).thenReturn(Optional.empty());
		doNothing().when(mailService).sendHtmlEmail(anyString(), anyString(), anyString());
		String response = userService.sendOtpToEmail("newuser@gmail.com");
		assertEquals("OTP sent successfully.", response);
	}

	@Test
	void testSendOtpToEmail_Negative_EmailExists() {
		when(userRepository.findByEmail("test@gmail.com")).thenReturn(Optional.of(user));
		String response = userService.sendOtpToEmail("test@gmail.com");
		assertEquals("Email is already taken.", response);
	}

	@Test
	void testUpdatePassword_Positive() {
		when(userRepository.findByEmail("test@gmail.com")).thenReturn(Optional.of(user));
		when(passwordEncoder.encode("newPassword")).thenReturn("encodedNewPassword");
		userService.updatePassword("test@gmail.com", "newPassword");
		verify(userRepository, times(1)).save(user);
		assertEquals("encodedNewPassword", user.getPassword());
	}

	@Test
	void testUpdatePassword_Negative_UserNotFound() {
		when(userRepository.findByEmail("notfound@gmail.com")).thenReturn(Optional.empty());
		userService.updatePassword("notfound@gmail.com", "newPassword");
		verify(userRepository, never()).save(any());
	}

	@Test
	void testUpdateProfile_Positive() {
		when(userRepository.findById(1L)).thenReturn(Optional.of(user));
		when(passwordEncoder.encode("newPassword")).thenReturn("encodedNewPassword");

		UserDto updatedUserDto = new UserDto();
		updatedUserDto.setName("Updated Name");
		updatedUserDto.setEmail("updatedemail@gmail.com");
		updatedUserDto.setPassword("newPassword");
		updatedUserDto.setContactNumber("9876543210");
		updatedUserDto.setAddress("Updated Address");
		updatedUserDto.setGender("MALE");
		updatedUserDto.setUserType("CUSTOMER");
		updatedUserDto.setDateOfBirth(LocalDate.of(2000, 1, 1));

		userService.updateProfile(1L, updatedUserDto, "admin@gmail.com");

		verify(userRepository, times(1)).save(any(Users.class));
		assertEquals("Updated Name", user.getName());
		assertEquals("updatedemail@gmail.com", user.getEmail());
		assertEquals("encodedNewPassword", user.getPassword());
		assertEquals("9876543210", user.getContactNumber());
		assertEquals("Updated Address", user.getAddress());
		assertEquals(UserType.CUSTOMER, user.getUserType());
		assertEquals("admin@gmail.com", user.getUpdatedBy());
	}

	@Test
	void testUpdateProfile_Negative_UserNotFound() {
		when(userRepository.findById(99L)).thenReturn(Optional.empty());

		UserDto updatedUserDto = new UserDto();
		updatedUserDto.setName("New Name");
		updatedUserDto.setEmail("newemail@gmail.com");

		userService.updateProfile(99L, updatedUserDto, "admin@gmail.com");

		verify(userRepository, never()).save(any(Users.class));
	}

	@Test
	void testUpdateProfile_Negative_InvalidUserType() {
		when(userRepository.findById(1L)).thenReturn(Optional.of(user));

		UserDto updatedUserDto = new UserDto();
		updatedUserDto.setUserType("INVALID_TYPE");

		assertThrows(IllegalArgumentException.class, () -> {
			userService.updateProfile(1L, updatedUserDto, "admin@gmail.com");
		});

		verify(userRepository, never()).save(any(Users.class));
	}

	@Test
	void testDeleteUser_Positive() {
		when(userRepository.findById(1L)).thenReturn(Optional.of(user));
		userService.deleteUser(1L, "admin@gmail.com");
		assertTrue(user.isDeleted());
		verify(userRepository, times(1)).save(user);
	}

	@Test
	void testDeleteUser_Negative_UserNotFound() {
		when(userRepository.findById(2L)).thenReturn(Optional.empty());
		userService.deleteUser(2L, "admin@gmail.com");
		verify(userRepository, never()).save(any());
	}

	@Test
	void testGetUserById_Positive() {
	    when(userRepository.findById(1L)).thenReturn(Optional.of(user));

	    Optional<Users> foundUser = userService.getUserById(1L);

	    assertTrue(foundUser.isPresent());
	    assertEquals(user, foundUser.get());
	}

	@Test
	void testGetUserById_Negative_UserNotFound() {
	    when(userRepository.findById(99L)).thenReturn(Optional.empty());

	    Optional<Users> foundUser = userService.getUserById(99L);

	    assertFalse(foundUser.isPresent());
	}
	
	@Test
	void testGetUserByEmail_Positive() {
	    when(userRepository.findByEmail("test@gmail.com")).thenReturn(Optional.of(user));

	    Optional<Users> foundUser = userService.getUserByEmail("test@gmail.com");

	    assertTrue(foundUser.isPresent());
	    assertEquals(user, foundUser.get());
	}

	@Test
	void testGetUserByEmail_Negative_EmailNotFound() {
	    when(userRepository.findByEmail("notfound@gmail.com")).thenReturn(Optional.empty());

	    Optional<Users> foundUser = userService.getUserByEmail("notfound@gmail.com");

	    assertFalse(foundUser.isPresent());
	}
	
	@Test
	void testGetAllUsers_Positive() {
	    List<Users> usersList = List.of(user, new Users());
	    when(userRepository.findByIsDeletedFalse()).thenReturn(usersList);

	    List<Users> result = userService.getAllUsers();

	    assertEquals(2, result.size());
	}

	@Test
	void testGetAllUsers_Negative_EmptyList() {
	    when(userRepository.findByIsDeletedFalse()).thenReturn(Collections.emptyList());

	    List<Users> result = userService.getAllUsers();

	    assertTrue(result.isEmpty());
	}
	
	@Test
	void testUpdateUser_Positive() {
	    when(userRepository.findById(1L)).thenReturn(Optional.of(user));

	    UserDto updatedUserDto = new UserDto();
	    updatedUserDto.setName("Updated Name");
	    updatedUserDto.setEmail("updated@gmail.com");
	    updatedUserDto.setContactNumber("9876543210");
	    updatedUserDto.setAddress("Updated Address");
	    updatedUserDto.setGender("MALE");
	    updatedUserDto.setUserType("CUSTOMER");
	    updatedUserDto.setDateOfBirth(LocalDate.of(1995, 1, 1));

	    userService.updateUser(1L, updatedUserDto, "admin@gmail.com");

	    verify(userRepository, times(1)).save(any(Users.class));
	    assertEquals("Updated Name", user.getName());
	    assertEquals("updated@gmail.com", user.getEmail());
	    assertEquals("9876543210", user.getContactNumber());
	    assertEquals("Updated Address", user.getAddress());
	    assertEquals(UserType.CUSTOMER, user.getUserType());
	    assertEquals("admin@gmail.com", user.getUpdatedBy());
	}

	@Test
	void testUpdateUser_Negative_UserNotFound() {
	    when(userRepository.findById(99L)).thenReturn(Optional.empty());

	    UserDto updatedUserDto = new UserDto();
	    updatedUserDto.setName("New Name");

	    userService.updateUser(99L, updatedUserDto, "admin@gmail.com");

	    verify(userRepository, never()).save(any(Users.class));
	}
	
	@Test
	void testGetTotalCustomers_Positive() {
	    when(userRepository.countByUserTypeAndIsDeletedFalse(UserType.CUSTOMER)).thenReturn(10L);

	    long totalCustomers = userService.getTotalCustomers();

	    assertEquals(10L, totalCustomers);
	}

	@Test
	void testGetTotalCustomers_Negative_NoCustomers() {
	    when(userRepository.countByUserTypeAndIsDeletedFalse(UserType.CUSTOMER)).thenReturn(0L);

	    long totalCustomers = userService.getTotalCustomers();

	    assertEquals(0L, totalCustomers);
	}

	@Test
	void testVerifyOtp_Positive() {
	    String email = "test@gmail.com";
	    String otp = "123456";

	    userService.saveOtp(email, otp);
	    boolean isValid = userService.verifyOtp(email, otp);

	    assertTrue(isValid);
	}

	@Test
	void testVerifyOtp_Negative_WrongOtp() {
	    String email = "test@gmail.com";

	    userService.saveOtp(email, "123456");
	    boolean isValid = userService.verifyOtp(email, "654321");

	    assertFalse(isValid);
	}

	@Test
	void testVerifyOtp_Negative_NoOtpStored() {
	    boolean isValid = userService.verifyOtp("test@gmail.com", "123456");

	    assertFalse(isValid);
	}

}