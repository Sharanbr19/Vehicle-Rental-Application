package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.BookingDTO;
import com.endava.vehiclerentalapp.dto.VehicleDTO;
import com.endava.vehiclerentalapp.entity.BookingStatus;
import com.endava.vehiclerentalapp.service.BookingService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class BookingControllerTest {

    private MockMvc mockMvc;

    @Mock
    private BookingService bookingService;

    @InjectMocks
    private BookingController bookingController;

    private BookingDTO bookingDTO;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(bookingController).build();

        bookingDTO = new BookingDTO();
        bookingDTO.setBookingId(1L);
        bookingDTO.setLocation("New York");
        bookingDTO.setFromDate(LocalDate.of(2025, 3, 1));
        bookingDTO.setToDate(LocalDate.of(2025, 3, 5));
        bookingDTO.setTotalCost(500.0);
        bookingDTO.setCustomerAadharNumber("123456789012");
        bookingDTO.setCustomerDrivingLicenseNumber("DL123456");
        bookingDTO.setStatus(BookingStatus.CONFIRMED);
        bookingDTO.setPaymentCompleted(true);
        bookingDTO.setWantsDriver(false);
        bookingDTO.setCustomerId(100L);
        bookingDTO.setVehicleId(200L);
        bookingDTO.setDriverId(null);
        bookingDTO.setCreatedAt(LocalDateTime.now());
        bookingDTO.setUpdatedAt(LocalDateTime.now());
    }

    @Test
    void testCreateBooking_Success() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());

        when(bookingService.createBooking(any(BookingDTO.class))).thenReturn(bookingDTO);

        mockMvc.perform(post("/api/bookings")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(bookingDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.bookingId").value(1L))
                .andExpect(jsonPath("$.location").value("New York"));
    }

    @Test
    void testGetTotalBookings() throws Exception {
        when(bookingService.getTotalBookings()).thenReturn(10L);

        mockMvc.perform(get("/api/bookings/total-bookings"))
                .andExpect(status().isOk())
                .andExpect(content().string("10"));
    }

    @Test
    void testGetTotalEarnings() throws Exception {
        when(bookingService.getTotalEarnings()).thenReturn(50000L);

        mockMvc.perform(get("/api/bookings/total-earnings"))
                .andExpect(status().isOk())
                .andExpect(content().string("50000"));
    }

    @Test
    void testGetEarningsByCategoryType() throws Exception {
        List<Object[]> earnings = Collections.singletonList(new Object[]{"SUV", 20000L});
        when(bookingService.getEarningsByCategoryType()).thenReturn(earnings);

        mockMvc.perform(get("/api/bookings/earnings-by-category"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetBookingCountByCategoryType() throws Exception {
        List<Object[]> counts = Collections.singletonList(new Object[]{"Sedan", 15L});
        when(bookingService.getBookingCountByCategoryType()).thenReturn(counts);

        mockMvc.perform(get("/api/bookings/booking-count-by-category"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetBookingsByCustomerId() throws Exception {
        List<BookingDTO> bookings = Collections.singletonList(bookingDTO);
        when(bookingService.getBookingsByCustomerId(100L)).thenReturn(bookings);

        mockMvc.perform(get("/api/bookings/customer/100"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }

    @Test
    void testGetBookingsByVehicleId() throws Exception {
        List<BookingDTO> bookings = Collections.singletonList(bookingDTO);
        when(bookingService.getBookingsByVehicleId(200L)).thenReturn(bookings);

        mockMvc.perform(get("/api/bookings/vehicle/200"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }

    @Test
    void testUpdateBooking() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());

        when(bookingService.updateBooking(anyLong(), any(BookingDTO.class))).thenReturn(bookingDTO);

        mockMvc.perform(put("/api/bookings/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(bookingDTO)))
                .andExpect(status().isOk());
    }


    @Test
    void testGetAvailableVehiclesBetweenDates() throws Exception {
        List<VehicleDTO> vehicles = Collections.singletonList(new VehicleDTO());
        when(bookingService.getAvailableVehiclesBetweenDates(any(LocalDate.class), any(LocalDate.class))).thenReturn(vehicles);

        mockMvc.perform(get("/api/bookings/available-vehicles")
                        .param("fromDate", "2025-03-01")
                        .param("toDate", "2025-03-05"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }
}