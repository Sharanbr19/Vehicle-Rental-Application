package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.InvoiceDTO;
import com.endava.vehiclerentalapp.service.InvoiceService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.Arrays;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(InvoiceController.class)
@AutoConfigureMockMvc(addFilters = false) // Disable security filters
class InvoiceControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @SuppressWarnings("removal")
	@MockBean
    private InvoiceService invoiceService;

    @Autowired
    private ObjectMapper objectMapper;

    private InvoiceDTO invoiceDTO;

    @BeforeEach
    void setUp() {
        invoiceDTO = new InvoiceDTO();
        invoiceDTO.setInvoiceId(1L);
        invoiceDTO.setBookingId(2L);
        invoiceDTO.setInvoiceDate("01-01-2025");
        invoiceDTO.setTotalAmount(1500.00);
    }

    @Test
    void testCreateInvoice_Success() throws Exception {
        Mockito.when(invoiceService.createInvoice(any(InvoiceDTO.class))).thenReturn(invoiceDTO);

        mockMvc.perform(post("/api/invoices")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invoiceDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.invoiceId").value(1L))
                .andExpect(jsonPath("$.totalAmount").value(1500.00));
    }

    @Test
    void testGetInvoiceById_Success() throws Exception {
        Mockito.when(invoiceService.getInvoiceById(1L)).thenReturn(invoiceDTO);

        mockMvc.perform(get("/api/invoices/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.invoiceId").value(1L))
                .andExpect(jsonPath("$.totalAmount").value(1500.00));
    }

    @Test
    void testGetAllInvoices_Success() throws Exception {
        List<InvoiceDTO> invoices = Arrays.asList(invoiceDTO);
        Mockito.when(invoiceService.getAllInvoices()).thenReturn(invoices);

        mockMvc.perform(get("/api/invoices"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }

    @Test
    void testGetInvoicesByCustomerId_Success() throws Exception {
        List<InvoiceDTO> invoices = Arrays.asList(invoiceDTO);
        Mockito.when(invoiceService.getInvoicesByCustomerId(2L)).thenReturn(invoices);

        mockMvc.perform(get("/api/invoices/customer/2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }

    @Test
    void testDeleteInvoice_Success() throws Exception {
        Mockito.doNothing().when(invoiceService).deleteInvoice(anyLong());

        mockMvc.perform(delete("/api/invoices/1"))
                .andExpect(status().isOk());
    }

}
