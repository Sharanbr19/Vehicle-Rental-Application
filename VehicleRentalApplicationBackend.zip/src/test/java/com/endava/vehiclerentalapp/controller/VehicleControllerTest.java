package com.endava.vehiclerentalapp.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.endava.vehiclerentalapp.dto.VehicleComparisonDTO;
import com.endava.vehiclerentalapp.dto.VehicleDTO;
import com.endava.vehiclerentalapp.dto.VehicleFilterCriteriaDTO;
import com.endava.vehiclerentalapp.service.VehicleService;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

class VehicleControllerTest {

    @Mock
    private VehicleService vehicleService;

    @InjectMocks
    private VehicleController vehicleController;

    private VehicleDTO sampleVehicleDTO;
    private VehicleFilterCriteriaDTO sampleFilterCriteria;
    private List<VehicleDTO> sampleVehicleList;
    private List<VehicleComparisonDTO> sampleComparisonList;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        sampleVehicleDTO = new VehicleDTO();
        sampleVehicleDTO.setVehicleId(1L);
        sampleVehicleDTO.setModelName("Test Model");
        sampleFilterCriteria = new VehicleFilterCriteriaDTO("Sedan","Petrol","1000-1500","Red");
        sampleVehicleList = List.of(sampleVehicleDTO);
        sampleComparisonList = List.of(new VehicleComparisonDTO());
    }

    @Test
    void testAddVehicle_Positive() {
        doNothing().when(vehicleService).addVehicle(sampleVehicleDTO);
        ResponseEntity<String> response = vehicleController.addVehicle(sampleVehicleDTO);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Vehicle added successfully", response.getBody());
    }

    @Test
    void testUpdateVehicle_Positive() {
        when(vehicleService.updateVehicle(1L, sampleVehicleDTO)).thenReturn(Optional.of(sampleVehicleDTO));
        ResponseEntity<VehicleDTO> response = vehicleController.updateVehicle(1L, sampleVehicleDTO);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(sampleVehicleDTO, response.getBody());
    }

    @Test
    void testDeleteVehicle_Positive() {
        doNothing().when(vehicleService).deleteVehicle(1L);
        ResponseEntity<Void> response = vehicleController.deleteVehicle(1L);
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }

    @Test
    void testGetTotalVehicles_Positive() {
        when(vehicleService.getTotalVehicles()).thenReturn(10L);
        long total = vehicleController.getTotalVehicles();
        assertEquals(10L, total);
    }

    @Test
    void testGetVehicleById_Positive() {
        when(vehicleService.getVehicleById(1L)).thenReturn(Optional.of(sampleVehicleDTO));
        ResponseEntity<VehicleDTO> response = vehicleController.getVehicleById(1L);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(sampleVehicleDTO, response.getBody());
    }

    @Test
    void testGetAllVehicles_Positive() {
        when(vehicleService.getAllVehicles()).thenReturn(sampleVehicleList);
        ResponseEntity<List<VehicleDTO>> response = vehicleController.getAllVehicles();
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(sampleVehicleList, response.getBody());
    }

    @Test
    void testSearchVehicles_Positive() {
        when(vehicleService.searchVehicles("Sedan")).thenReturn(sampleVehicleList);
        List<VehicleDTO> result = vehicleController.searchVehicles("Sedan");
        assertEquals(sampleVehicleList, result);
    }

    @Test
    void testFilterVehicles_Positive() {
        when(vehicleService.filterVehicles(sampleFilterCriteria)).thenReturn(sampleVehicleList);
        List<VehicleDTO> result = vehicleController.filterVehicles(sampleFilterCriteria);
        assertEquals(sampleVehicleList, result);
    }

    @Test
    void testSortVehicles_Positive() {
        when(vehicleService.sortVehicles("pricePerDay", true)).thenReturn(sampleVehicleList);
        List<VehicleDTO> result = vehicleController.sortVehicles("pricePerDay", true);
        assertEquals(sampleVehicleList, result);
    }
    
    @Test
    void testCompareVehicles_Positive() {
        List<Long> vehicleIds = List.of(1L, 2L);
        when(vehicleService.compareVehicles(vehicleIds)).thenReturn(sampleComparisonList);
        List<VehicleComparisonDTO> result = vehicleController.compareVehicles(vehicleIds);
        assertEquals(sampleComparisonList, result);
    }
}
