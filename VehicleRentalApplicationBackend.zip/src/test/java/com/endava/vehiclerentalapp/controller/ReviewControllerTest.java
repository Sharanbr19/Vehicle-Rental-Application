package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.ReviewDTO;
import com.endava.vehiclerentalapp.service.ReviewService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.Arrays;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ReviewController.class)
@AutoConfigureMockMvc(addFilters = false)
class ReviewControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @SuppressWarnings("removal")
    @MockBean
    private ReviewService reviewService;

    @Autowired
    private ObjectMapper objectMapper;

    private ReviewDTO reviewDTO;

    @BeforeEach
    void setUp() {
        reviewDTO = new ReviewDTO(1L, "5", "Great Car!", 2L, 3L);
    }

    @Test
    void testCreateReview_Success() throws Exception {
        Mockito.when(reviewService.createReview(any(ReviewDTO.class))).thenReturn(reviewDTO);

        mockMvc.perform(post("/api/reviews")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(reviewDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.rating").value(5));
    }

    @Test
    void testUpdateReview_Success() throws Exception {
        Mockito.when(reviewService.updateReview(anyLong(), anyLong(), any(ReviewDTO.class))).thenReturn(reviewDTO);

        mockMvc.perform(put("/api/reviews/1/2")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(reviewDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.comment").value("Great Car!"));
    }

    @Test
    void testDeleteReview_Success() throws Exception {
        Mockito.doNothing().when(reviewService).deleteReview(anyLong(), anyLong());

        mockMvc.perform(delete("/api/reviews/1/2"))
                .andExpect(status().isNoContent());
    }

    @Test
    void testGetReviewById_Success() throws Exception {
        Mockito.when(reviewService.getReview(1L)).thenReturn(reviewDTO);

        mockMvc.perform(get("/api/reviews/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rating").value(5));
    }

    @Test
    void testGetAllReviews_Success() throws Exception {
        List<ReviewDTO> reviews = Arrays.asList(
                new ReviewDTO(1L, "4", "Good", 2L, 3L),
                new ReviewDTO(2L, "5", "Excellent", 3L, 4L)
        );
        Mockito.when(reviewService.getAllReviews()).thenReturn(reviews);

        mockMvc.perform(get("/api/reviews"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(2));
    }

    @Test
    void testGetReviewsByVehicleId_Success() throws Exception {
        List<ReviewDTO> reviews = Arrays.asList(reviewDTO);
        Mockito.when(reviewService.getReviewsByVehicleId(1L)).thenReturn(reviews);

        mockMvc.perform(get("/api/reviews/vehicle/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }

    @Test
    void testGetReviewsByCustomerId_Success() throws Exception {
        List<ReviewDTO> reviews = Arrays.asList(reviewDTO);
        Mockito.when(reviewService.getReviewsByCustomerId(2L)).thenReturn(reviews);

        mockMvc.perform(get("/api/reviews/customer/2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }

    @Test
    void testGetAverageRating_Success() throws Exception {
        Mockito.when(reviewService.getAverageRatingByVehicleId(1L)).thenReturn(4.5);

        mockMvc.perform(get("/api/reviews/average-rating/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("4.5"));
    }
}
