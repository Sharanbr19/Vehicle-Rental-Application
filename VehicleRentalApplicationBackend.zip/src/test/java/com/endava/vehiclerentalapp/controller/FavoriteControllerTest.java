package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.FavoriteDTO;
import com.endava.vehiclerentalapp.service.FavoriteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.Arrays;
import java.util.List;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class FavoriteControllerTest {

    private MockMvc mockMvc;

    @Mock
    private FavoriteService favoriteService;

    @InjectMocks
    private FavoriteController favoriteController;

    private FavoriteDTO favoriteDTO;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(favoriteController).build();

        favoriteDTO = new FavoriteDTO();
        favoriteDTO.setUserId(1L);
        favoriteDTO.setVehicleId(101L);
    }

    @Test
    void testAddFavorite_Success() throws Exception {
        Mockito.when(favoriteService.addFavorite(Mockito.any(FavoriteDTO.class)))
                .thenReturn(favoriteDTO);

        mockMvc.perform(post("/api/favorites")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(favoriteDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.userId").value(1L))
                .andExpect(jsonPath("$.vehicleId").value(101L));
    }

    @Test
    void testRemoveFavorite_Success() throws Exception {
        doNothing().when(favoriteService).removeFavorite(1L, 101L);

        mockMvc.perform(delete("/api/favorites/1/101"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetFavoritesByCustomer_Success() throws Exception {
        List<FavoriteDTO> favoriteList = Arrays.asList(favoriteDTO);

        Mockito.when(favoriteService.getFavoritesByCustomer(1L))
                .thenReturn(favoriteList);

        mockMvc.perform(get("/api/favorites/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].userId").value(1L))
                .andExpect(jsonPath("$[0].vehicleId").value(101L));
    }
  
}
