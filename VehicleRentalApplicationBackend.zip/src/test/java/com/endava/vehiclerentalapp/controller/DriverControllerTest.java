package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.DriverDTO;
import com.endava.vehiclerentalapp.service.DriverService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.Arrays;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class DriverControllerTest {

    private MockMvc mockMvc;

    @Mock
    private DriverService driverService;

    @InjectMocks
    private DriverController driverController;

    private DriverDTO driverDTO;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(driverController).build();

        driverDTO = new DriverDTO();
        driverDTO.setDriverId(1L);
        driverDTO.setName("John Doe");
        driverDTO.setLicenseNumber("DL12345");
        driverDTO.setDriverCostPerDay(100.0);
        driverDTO.setContactNumber("1234567890");
        driverDTO.setEmail("john.doe@example.com");
        driverDTO.setIsDeleted(false);
    }

    @Test
    void testCreateDriver_Success() throws Exception {
        when(driverService.createDriver(any(DriverDTO.class))).thenReturn(driverDTO);

        mockMvc.perform(post("/api/drivers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(driverDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.driverId").value(1L))
                .andExpect(jsonPath("$.name").value("John Doe"));
    }

    @Test
    void testGetDriverById_Success() throws Exception {
        when(driverService.getDriverById(1L)).thenReturn(driverDTO);

        mockMvc.perform(get("/api/drivers/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.driverId").value(1L))
                .andExpect(jsonPath("$.name").value("John Doe"));
    }

    @Test
    void testGetAllDrivers_Success() throws Exception {
        List<DriverDTO> driverList = Arrays.asList(driverDTO);

        when(driverService.getAllDrivers()).thenReturn(driverList);

        mockMvc.perform(get("/api/drivers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].driverId").value(1L));
    }

    @Test
    void testUpdateDriver_Success() throws Exception {
        when(driverService.updateDriver(eq(1L), any(DriverDTO.class))).thenReturn(driverDTO);

        mockMvc.perform(put("/api/drivers/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(driverDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.driverId").value(1L))
                .andExpect(jsonPath("$.name").value("John Doe"));
    }

    @Test
    void testDeleteDriver_Success() throws Exception {
        doNothing().when(driverService).deleteDriver(1L);

        mockMvc.perform(delete("/api/drivers/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    void testGetTotalDrivers_Success() throws Exception {
        when(driverService.getTotalDrivers()).thenReturn(10L);

        mockMvc.perform(get("/api/drivers/total-drivers"))
                .andExpect(status().isOk())
                .andExpect(content().string("10"));
    }
}
