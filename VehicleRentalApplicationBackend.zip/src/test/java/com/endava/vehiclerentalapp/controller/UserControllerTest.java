package com.endava.vehiclerentalapp.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.endava.vehiclerentalapp.dto.UserDto;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.service.UserService;
import com.endava.vehiclerentalapp.service.implementation.MailService;
import com.endava.vehiclerentalapp.util.Constants;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

class UserControllerTest {

    @Mock
    private UserService userService;
    
    @Mock
    private MailService mailService;
    
    @InjectMocks
    private UserController userController;
    
    private UserDto sampleUserDto;
    private Users sampleUser;
    
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        
        sampleUserDto = new UserDto();
        sampleUserDto.setName("John Doe");
        sampleUserDto.setEmail("john@example.com");
        sampleUserDto.setPassword("pass");
        sampleUserDto.setContactNumber("1234567890");
        sampleUserDto.setAddress("123 Street");
        sampleUserDto.setGender("Male");
        sampleUserDto.setUserType("CUSTOMER");
        sampleUserDto.setDateOfBirth(java.time.LocalDate.of(1990, 1, 1));
        
        sampleUser = new Users();
        sampleUser.setUserId(1L);
        sampleUser.setName("John Doe");
    }
        
    @Test
    void testCheckUserEmailExists_EmailExists() {
        when(userService.checkIfUserExistsByEmail("john@example.com")).thenReturn(true);
        ResponseEntity<String> response = userController.checkUserEmailExists("john@example.com");
        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals(Constants.EMAIL_ALREADY_TAKEN, response.getBody());
    }
    
    @Test
    void testCheckUserEmailExists_EmailNotExists() {
        when(userService.checkIfUserExistsByEmail("john@example.com")).thenReturn(false);
        ResponseEntity<String> response = userController.checkUserEmailExists("john@example.com");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.EMAIL_AVAILABLE, response.getBody());
    }
        
    @Test
    void testRegisterUser_WithCreatedBy() {
        doNothing().when(userService).registerUser(sampleUserDto, "admin@domain.com");
        ResponseEntity<Map<String, String>> response =
                userController.registerUser(sampleUserDto, "admin@domain.com");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.USER_REGISTERED_SUCCESSFULLY,
                     response.getBody().get(Constants.MESSAGE));
    }
    
    @Test
    void testRegisterUser_WithoutCreatedBy() {
        doNothing().when(userService).registerUser(sampleUserDto, Constants.ADMIN_DEFAULT);
        ResponseEntity<Map<String, String>> response =
                userController.registerUser(sampleUserDto, "");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.USER_REGISTERED_SUCCESSFULLY,
                     response.getBody().get(Constants.MESSAGE));
    } 
    @Test
    void testLoginUser_Positive() {
        sampleUserDto.setEmail("john@example.com");
        sampleUserDto.setPassword("pass");
        when(userService.loginUser("john@example.com", "pass"))
                .thenReturn(Optional.of("token123"));
        ResponseEntity<Object> response = userController.loginUser(sampleUserDto);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("token123", response.getBody());
    }
    
    @Test
    void testLoginUser_Negative_InvalidCredentials() {
        sampleUserDto.setEmail("john@example.com");
        sampleUserDto.setPassword("wrong");
        when(userService.loginUser("john@example.com", "wrong"))
                .thenReturn(Optional.empty());
        ResponseEntity<Object> response = userController.loginUser(sampleUserDto);
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertEquals(Constants.INVALID_CREDENTIALS, response.getBody());
    }
         
    @Test
    void testGetUserById_Positive() {
        when(userService.getUserById(1L)).thenReturn(Optional.of(sampleUser));
        ResponseEntity<Object> response = userController.getUserById(1L);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(sampleUser, response.getBody());
    }
        
    @Test
    void testGetUserByEmail_Positive() {
        when(userService.getUserByEmail("john@example.com")).thenReturn(Optional.of(sampleUser));
        ResponseEntity<Object> response = userController.getUserByEmail("john@example.com");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(sampleUser, response.getBody());
    }
        
    @Test
    void testGetAllUsers_Positive() {
        List<Users> userList = List.of(sampleUser);
        when(userService.getAllUsers()).thenReturn(userList);
        ResponseEntity<List<Users>> response = userController.getAllUsers();
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userList, response.getBody());
    }

    @Test
    void testUpdateUser_Positive() {
        doNothing().when(userService).updateUser(1L, sampleUserDto, "admin@example.com");
        ResponseEntity<Map<String, String>> response =
                userController.updateUser(1L, sampleUserDto, "admin@example.com");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.USER_UPDATED_SUCCESSFULLY,
                     response.getBody().get(Constants.MESSAGE));
    }
    
    @Test
    void testUpdateUser_WithoutUpdatedBy() {
        doNothing().when(userService).updateUser(1L, sampleUserDto, Constants.ADMIN_DEFAULT);
        ResponseEntity<Map<String, String>> response =
                userController.updateUser(1L, sampleUserDto, "");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.USER_UPDATED_SUCCESSFULLY,
                     response.getBody().get(Constants.MESSAGE));
    }
    
    @Test
    void testUpdateUser_Negative_ServiceThrowsException() {
        doThrow(new RuntimeException("Update error"))
                .when(userService).updateUser(1L, sampleUserDto, Constants.ADMIN_DEFAULT);
        Exception ex = assertThrows(RuntimeException.class, () ->
                userController.updateUser(1L, sampleUserDto, ""));
        assertEquals("Update error", ex.getMessage());
    }
        
    @Test
    void testUpdateProfile_Positive() {
        doNothing().when(userService).updateProfile(1L, sampleUserDto, "admin@example.com");
        ResponseEntity<Map<String, String>> response =
                userController.updateProfile(1L, sampleUserDto, "admin@example.com");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.USER_UPDATED_SUCCESSFULLY,
                     response.getBody().get(Constants.MESSAGE));
    }
    
    @Test
    void testUpdateProfile_WithoutUpdatedBy() {
        doNothing().when(userService).updateProfile(1L, sampleUserDto, Constants.ADMIN_DEFAULT);
        ResponseEntity<Map<String, String>> response =
                userController.updateProfile(1L, sampleUserDto, "");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.USER_UPDATED_SUCCESSFULLY,
                     response.getBody().get(Constants.MESSAGE));
    }
    
    @Test
    void testUpdateProfile_Negative_ServiceThrowsException() {
        doThrow(new RuntimeException("Profile update error"))
                .when(userService).updateProfile(1L, sampleUserDto, Constants.ADMIN_DEFAULT);
        Exception ex = assertThrows(RuntimeException.class, () ->
                userController.updateProfile(1L, sampleUserDto, ""));
        assertEquals("Profile update error", ex.getMessage());
    }
        
    @Test
    void testDeleteUser_Positive() {
        doNothing().when(userService).deleteUser(1L, "admin@example.com");
        ResponseEntity<Map<String,String>> response = userController.deleteUser(1L, "admin@example.com");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.USER_DELETED_SUCCESSFULLY,
                     response.getBody().get(Constants.MESSAGE));
    }
    
    @Test
    void testDeleteUser_WithoutDeletedBy() {
        doNothing().when(userService).deleteUser(1L, Constants.ADMIN_DEFAULT);
        ResponseEntity<Map<String,String>> response = userController.deleteUser(1L, "");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.USER_DELETED_SUCCESSFULLY,
                     response.getBody().get(Constants.MESSAGE));
    }
    
    @Test
    void testGetTotalCustomers_Positive() {
        when(userService.getTotalCustomers()).thenReturn(5L);
        long count = userController.getTotalCustomers();
        assertEquals(5L, count);
    }
        
    @Test
    void testForgotPassword_Positive() throws Exception {
        when(userService.checkIfUserExistsByEmail("john@example.com")).thenReturn(true);
        doNothing().when(mailService).sendHtmlEmail(eq("john@example.com"), anyString(), anyString());
        doNothing().when(userService).saveOtp(eq("john@example.com"), anyString());
        ResponseEntity<String> response = userController.forgotPassword("john@example.com");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.OTP_SENT_TO_MAIL, response.getBody());
    }
        
    @Test
    void testResetPassword_Positive() {
        when(userService.validateOtp("john@example.com", "123456")).thenReturn(true);
        doNothing().when(userService).updatePassword("john@example.com", "newpass");
        ResponseEntity<String> response = userController.resetPassword("john@example.com", "123456", "newpass");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.PASSWORD_REST_SUCCESSFUL, response.getBody());
    }
    
    @Test
    void testResetPassword_Negative_InvalidOtp() {
        when(userService.validateOtp("john@example.com", "000000")).thenReturn(false);
        ResponseEntity<String> response = userController.resetPassword("john@example.com", "000000", "newpass");
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals(Constants.INVALID_OTP, response.getBody());
    }

    @Test
    void testSendOtpToEmail_Positive() {
        when(userService.sendOtpToEmail("john@example.com")).thenReturn("OTP sent successfully");
        ResponseEntity<String> response = userController.sendOtpToEmail("john@example.com");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("OTP sent successfully", response.getBody());
    }
    
    @Test
    void testSendOtpToEmail_Negative_ServiceThrowsException() {
        when(userService.sendOtpToEmail("john@example.com")).thenThrow(new RuntimeException("OTP send error"));
        Exception ex = assertThrows(RuntimeException.class, () ->
                userController.sendOtpToEmail("john@example.com"));
        assertEquals("OTP send error", ex.getMessage());
    }
        
    @Test
    void testVerifyOtp_Positive() {
        when(userService.verifyOtp("john@example.com", "123456")).thenReturn(true);
        ResponseEntity<String> response = userController.verifyOtp("john@example.com", "123456");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Constants.OTP_VERIFIED_SUCCESSFULLY, response.getBody());
    }
    
    @Test
    void testVerifyOtp_Negative() {
        when(userService.verifyOtp("john@example.com", "000000")).thenReturn(false);
        ResponseEntity<String> response = userController.verifyOtp("john@example.com", "000000");
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals(Constants.INVALID_OTP, response.getBody());
    }
}
