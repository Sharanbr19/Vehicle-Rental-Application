package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.RentalAgreementDTO;
import com.endava.vehiclerentalapp.service.RentalAgreementService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.Arrays;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(RentalAgreementController.class)
@AutoConfigureMockMvc(addFilters = false)
class RentalAgreementControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @SuppressWarnings("removal")
	@MockBean
    private RentalAgreementService rentalAgreementService;

    @Autowired
    private ObjectMapper objectMapper;

    private RentalAgreementDTO rentalAgreementDTO;

    @BeforeEach
    void setUp() {
        rentalAgreementDTO = new RentalAgreementDTO();
        rentalAgreementDTO.setRentalId(1L);
        rentalAgreementDTO.setAgreementDate("2025-01-01");
        rentalAgreementDTO.setBookingId(2L);
        rentalAgreementDTO.setTermsAndConditions("Terms and Conditions");
    }

    @Test
    void testCreateRentalAgreement_Success() throws Exception {
        Mockito.when(rentalAgreementService.createRentalAgreement(any(RentalAgreementDTO.class))).thenReturn(rentalAgreementDTO);

        mockMvc.perform(post("/api/rental-agreements")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(rentalAgreementDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rentalId").value(1L));
    }

    @Test
    void testCreateRentalAgreement_Failure() throws Exception {
        Mockito.when(rentalAgreementService.createRentalAgreement(any(RentalAgreementDTO.class)))
                .thenThrow(new RuntimeException("Invalid Data"));

        mockMvc.perform(post("/api/rental-agreements")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(new RentalAgreementDTO())))
                .andExpect(status().isInternalServerError());
    }

    @Test
    void testGetRentalAgreementById_Success() throws Exception {
        Mockito.when(rentalAgreementService.getRentalAgreementById(1L)).thenReturn(rentalAgreementDTO);

        mockMvc.perform(get("/api/rental-agreements/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rentalId").value(1L));
    }

    @Test
    void testGetAllRentalAgreements_Success() throws Exception {
        List<RentalAgreementDTO> agreements = Arrays.asList(rentalAgreementDTO);
        Mockito.when(rentalAgreementService.getAllRentalAgreements()).thenReturn(agreements);

        mockMvc.perform(get("/api/rental-agreements"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }

    @Test
    void testGetRentalAgreementsByCustomerId_Success() throws Exception {
        List<RentalAgreementDTO> agreements = Arrays.asList(rentalAgreementDTO);
        Mockito.when(rentalAgreementService.getRentalAgreementByCustomerId(1L)).thenReturn(agreements);

        mockMvc.perform(get("/api/rental-agreements/customer/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }

    @Test
    void testDeleteRentalAgreement_Success() throws Exception {
        Mockito.doNothing().when(rentalAgreementService).deleteRentalAgreement(anyLong());

        mockMvc.perform(delete("/api/rental-agreements/1"))
                .andExpect(status().isOk());
    }
}
