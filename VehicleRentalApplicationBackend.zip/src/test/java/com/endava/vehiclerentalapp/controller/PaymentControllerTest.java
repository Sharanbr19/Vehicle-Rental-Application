package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.PaymentDTO;
import com.endava.vehiclerentalapp.service.PaymentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PaymentController.class)
@AutoConfigureMockMvc(addFilters = false)  // Disabling security for tests
class PaymentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @SuppressWarnings("removal")
	@MockBean
    private PaymentService paymentService;

    @Autowired
    private ObjectMapper objectMapper;

    private PaymentDTO paymentDTO;

    @BeforeEach
    void setUp() {
        paymentDTO = new PaymentDTO();
        paymentDTO.setPaymentId(1L);
        paymentDTO.setAmount(5000.0);
        paymentDTO.setBookingId(2L);
        paymentDTO.setPaymentDateAndTime(LocalDateTime.now());
    }

    @Test
    void testGetPaymentById_Success() throws Exception {
        Mockito.when(paymentService.getPaymentById(1L)).thenReturn(paymentDTO);

        mockMvc.perform(get("/api/payments/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.paymentId").value(1L))
                .andExpect(jsonPath("$.amount").value(5000.0));
    }

    @Test
    void testGetAllPayments_Success() throws Exception {
        List<PaymentDTO> payments = Arrays.asList(paymentDTO);
        Mockito.when(paymentService.getAllPayments()).thenReturn(payments);

        mockMvc.perform(get("/api/payments"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }

    @Test
    void testCreatePayment_Success() throws Exception {
        Mockito.when(paymentService.createPayment(any(PaymentDTO.class))).thenReturn("Payment Created Successfully");

        mockMvc.perform(post("/api/payments")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(paymentDTO)))
                .andExpect(status().isOk())
                .andExpect(content().string("Payment Created Successfully"));
    }

    @Test
    void testUpdatePayment_Success() throws Exception {
        Mockito.when(paymentService.updatePayment(anyLong(), any(PaymentDTO.class)))
                .thenReturn("Payment Updated Successfully");

        mockMvc.perform(put("/api/payments/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(paymentDTO)))
                .andExpect(status().isOk())
                .andExpect(content().string("Payment Updated Successfully"));
    }

    @Test
    void testDeletePayment_Success() throws Exception {
        Mockito.when(paymentService.deletePayment(anyLong())).thenReturn("Payment Deleted Successfully");

        mockMvc.perform(delete("/api/payments/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Payment Deleted Successfully"));
    }

}
