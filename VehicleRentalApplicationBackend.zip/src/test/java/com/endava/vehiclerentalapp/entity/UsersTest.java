package com.endava.vehiclerentalapp.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;

class UsersTest {

    private Users user;

    @BeforeEach
    void setUp() {
        user = new Users();
    }

    @Test
    void userCreationShouldSetRequiredFields() {
        user.setEmail("test@gmail.com");
        user.setPassword("securePassword");
        user.setName("Sharan B R");
        user.setDateOfBirth(LocalDate.of(1995, 5, 15));
        user.setGender("Male");
        user.setContactNumber("9876543210");
        user.setAddress("123 Main St, City");
        user.setUserType(UserType.CUSTOMER);
        user.setCreatedBy("Admin");
        user.setUpdatedBy("Admin");
        user.setDeleted(false);

        user.onCreate(); 

        assertNotNull(user.getCreatedAt());
        assertNotNull(user.getUpdatedAt());
        assertEquals("test@gmail.com", user.getEmail());
        assertEquals("Sharan B R", user.getName());
        assertEquals(UserType.CUSTOMER, user.getUserType());
        assertFalse(user.isDeleted());
    }

    @Test
    void updatingUserShouldChangeUpdatedAt() {
        user.onCreate(); 
        LocalDateTime initialUpdatedAt = user.getUpdatedAt();
        try { Thread.sleep(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        user.onUpdate();
        assertTrue(user.getUpdatedAt().isAfter(initialUpdatedAt));
    }

    @Test
    void shouldNotAllowNullEmail() {
        user.setEmail(null);
        assertNull(user.getEmail());
    }

    @Test
    void shouldNotAllowNullContactNumber() {
        user.setContactNumber(null);
        assertNull(user.getContactNumber());
    }

    @Test
    void createdAtShouldNotBeNullAfterCreation() {
        user.onCreate();
        assertNotNull(user.getCreatedAt());
    }

    @Test
    void updatedAtShouldNotBeNullAfterUpdate() {
        user.onUpdate();
        assertNotNull(user.getUpdatedAt());
    }

    @Test
    void shouldNotAllowInvalidUserType() {
        assertThrows(IllegalArgumentException.class, () -> {
            UserType.valueOf("INVALID_TYPE"); // This should throw an exception
        });
    }
}
