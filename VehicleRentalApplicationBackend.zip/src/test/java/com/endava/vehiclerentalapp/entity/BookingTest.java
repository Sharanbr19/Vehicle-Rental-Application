package com.endava.vehiclerentalapp.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class BookingTest {

    private Booking booking;

    @BeforeEach
    void setUp() {
        booking = new Booking();
        booking.setBookingId(1L);
        booking.setLocation("Whitefield");
        booking.setFromDate(LocalDate.of(2025, 3, 1));
        booking.setToDate(LocalDate.of(2025, 3, 10));
        booking.setTotalCost(5000.0);
        booking.setCustomerAadharNumber("123412341234");
        booking.setCustomerDrivingLicenseNumber("KA19 123456789012");
        booking.setWantsDriver(true);
        booking.setStatus(BookingStatus.CONFIRMED);
        booking.setPaymentCompleted(true);
        booking.setCreatedAt(LocalDateTime.now());
        booking.setUpdatedAt(LocalDateTime.now());
    }

    @Test
    void testSetAndGetBookingId() {
        booking.setBookingId(2L);
        assertEquals(2L, booking.getBookingId());
    }

    @Test
    void testSetAndGetLocation() {
        booking.setLocation("Whitefield");
        assertEquals("Whitefield", booking.getLocation());
    }

    @Test
    void testSetAndGetTotalCost() {
        booking.setTotalCost(7000.0);
        assertEquals(7000.0, booking.getTotalCost());
    }

    @Test
    void testSetAndGetCustomerAadharNumber() {
        booking.setCustomerAadharNumber("987698769876");
        assertEquals("987698769876", booking.getCustomerAadharNumber());
    }

    @Test
    void testSetAndGetCustomerDrivingLicenseNumber() {
        booking.setCustomerDrivingLicenseNumber("KA19 123456789012");
        assertEquals("KA19 123456789012", booking.getCustomerDrivingLicenseNumber());
    }

    @Test
    void testSetAndGetWantsDriver() {
        booking.setWantsDriver(false);
        assertFalse(booking.getWantsDriver());
    }

    @Test
    void testSetAndGetStatus() {
        booking.setStatus(BookingStatus.CANCELLED);
        assertEquals(BookingStatus.CANCELLED, booking.getStatus());
    }

    @Test
    void testSetAndGetPaymentCompleted() {
        booking.setPaymentCompleted(false);
        assertFalse(booking.getPaymentCompleted());
    }

    @Test
    void testSetAndGetCreatedAt() {
        assertNotNull(booking.getCreatedAt());
    }

    @Test
    void testSetAndGetUpdatedAt() {
        assertNotNull(booking.getUpdatedAt());
    }

    @Test
    void testIsAvailableBetween_NoOverlap_ShouldReturnTrue() {
        LocalDate from = LocalDate.of(2025, 3, 11);
        LocalDate to = LocalDate.of(2025, 3, 15);
        assertTrue(booking.isAvailableBetween(from, to));
    }

    @Test
    void testIsAvailableBetween_ExactSameDates_ShouldReturnFalse() {
        LocalDate from = LocalDate.of(2025, 3, 1);
        LocalDate to = LocalDate.of(2025, 3, 10);
        assertFalse(booking.isAvailableBetween(from, to));
    }

    @Test
    void testIsAvailableBetween_OverlappingDates_ShouldReturnFalse() {
        LocalDate from = LocalDate.of(2025, 3, 5);
        LocalDate to = LocalDate.of(2025, 3, 15);
        assertFalse(booking.isAvailableBetween(from, to));
    }

    @Test
    void testIsAvailableBetween_BeforeBookingPeriod_ShouldReturnTrue() {
        LocalDate from = LocalDate.of(2025, 2, 20);
        LocalDate to = LocalDate.of(2025, 2, 28);
        assertTrue(booking.isAvailableBetween(from, to));
    }

    @Test
    void testNegativeTotalCost() {
        booking.setTotalCost(-1000.0);
        assertTrue(booking.getTotalCost() < 0, "Total cost should not be negative");
    }

    @Test
    void testInvalidAadharNumber() {
        booking.setCustomerAadharNumber("12345");
        assertTrue(booking.getCustomerAadharNumber().length() < 12, "Aadhar number should be 12 digits");
    }

    @Test
    void testInvalidDrivingLicenseNumber() {
        booking.setCustomerDrivingLicenseNumber("");
        assertTrue(booking.getCustomerDrivingLicenseNumber().isEmpty(), "Driving license number should not be empty");
    }

    @Test
    void testNullLocation() {
        booking.setLocation(null);
        assertNull(booking.getLocation(), "Location should allow null values");
    }

    @Test
    void testFromDateAfterToDate() {
        booking.setFromDate(LocalDate.of(2025, 3, 15));
        booking.setToDate(LocalDate.of(2025, 3, 10));
        assertTrue(booking.getFromDate().isAfter(booking.getToDate()), "FromDate should not be after ToDate");
    }

    @Test
    void testOnCreateSetsTimestamps() {
        assertNotNull(booking.getCreatedAt(), "CreatedAt should be set on creation");
        assertNotNull(booking.getUpdatedAt(), "UpdatedAt should be set on creation");
        assertEquals(booking.getCreatedAt(), booking.getUpdatedAt(), "CreatedAt and UpdatedAt should be equal initially");
    }
}
