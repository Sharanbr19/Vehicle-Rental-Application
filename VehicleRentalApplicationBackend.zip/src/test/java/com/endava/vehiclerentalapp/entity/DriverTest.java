package com.endava.vehiclerentalapp.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.Collections;
import static org.junit.jupiter.api.Assertions.*;

class DriverTest {

    private Driver driver;

    @BeforeEach
    void setUp() {
        driver = new Driver();
        driver.setName("John Doe");
        driver.setLicenseNumber("DL123456");
        driver.setDriverCostPerDay(500.0);
        driver.setContactNumber("9876543210");
        driver.setEmail("john.doe@example.com");
        driver.setIsDeleted(false);
        driver.setCreatedBy("Admin");
        driver.setUpdatedBy("Admin");
        driver.setDriverBookingDates(Collections.emptyList());
    }

    @Test
    void testSetAndGetDriverName() {
        driver.setName("Jane Doe");
        assertEquals("Jane Doe", driver.getName());
    }

    @Test
    void testSetAndGetLicenseNumber() {
        driver.setLicenseNumber("DL987654");
        assertEquals("DL987654", driver.getLicenseNumber());
    }

    @Test
    void testSetAndGetDriverCostPerDay() {
        driver.setDriverCostPerDay(600.0);
        assertEquals(600.0, driver.getDriverCostPerDay());
    }

    @Test
    void testSetAndGetContactNumber() {
        driver.setContactNumber("1234567890");
        assertEquals("1234567890", driver.getContactNumber());
    }

    @Test
    void testSetAndGetEmail() {
        driver.setEmail("jane.doe@example.com");
        assertEquals("jane.doe@example.com", driver.getEmail());
    }

    @Test
    void testSetAndGetIsDeleted() {
        driver.setIsDeleted(true);
        assertTrue(driver.getIsDeleted());
    }

    @Test
    void testSetAndGetCreatedBy() {
        driver.setCreatedBy("System");
        assertEquals("System", driver.getCreatedBy());
    }

    @Test
    void testSetAndGetUpdatedBy() {
        driver.setUpdatedBy("System");
        assertEquals("System", driver.getUpdatedBy());
    }

    @Test
    void testSetAndGetDriverBookingDates() {
        assertNotNull(driver.getDriverBookingDates());
    }

    @Test
    void testInvalidEmailFormat() {
        driver.setEmail("invalid-email");
        assertFalse(driver.getEmail().contains("@"));
    }

    @Test
    void testNegativeDriverCostPerDay() {
        driver.setDriverCostPerDay(-100.0);
        assertTrue(driver.getDriverCostPerDay() < 0, "Driver cost should not be negative");
    }

    @Test
    void testEmptyLicenseNumber() {
        driver.setLicenseNumber("");
        assertTrue(driver.getLicenseNumber().isEmpty(), "License number should not be empty");
    }

    @Test
    void testNullName() {
        driver.setName(null);
        assertNull(driver.getName(), "Driver name should allow null values");
    }

    @Test
    void testOnCreateSetsTimestamps() {
        driver.onCreate();
        assertNotNull(driver.getCreatedAt(), "CreatedAt should be set on create");
        assertNotNull(driver.getUpdatedAt(), "UpdatedAt should be set on create");
        assertEquals(driver.getCreatedAt(), driver.getUpdatedAt(), "CreatedAt and UpdatedAt should be equal initially");
    }

    @Test
    void testOnUpdateSetsUpdatedAt() throws InterruptedException {
        driver.onCreate();
        LocalDateTime initialUpdatedAt = driver.getUpdatedAt();
        Thread.sleep(1000); 
        driver.onUpdate();
        assertTrue(driver.getUpdatedAt().isAfter(initialUpdatedAt), "UpdatedAt should be updated on update");
    }
}
