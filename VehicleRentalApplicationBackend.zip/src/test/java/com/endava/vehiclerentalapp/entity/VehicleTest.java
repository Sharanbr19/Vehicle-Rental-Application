package com.endava.vehiclerentalapp.entity;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;

class VehicleTest {

    private Vehicle vehicle;

    @BeforeEach
    void setUp() {
        vehicle = new Vehicle();
    }

    @Test
    void vehicleCreationShouldSetCreatedAtAndUpdatedAt() {
        vehicle.setModelName("Toyota Corolla");
        vehicle.setRegistrationNumber("XYZ123");
        vehicle.setCategoryType("Sedan");
        vehicle.setFuelType("Petrol");
        vehicle.setColor("Red");
        vehicle.setModelYear("2020");
        vehicle.setPricePerDay(100.0);
        vehicle.setMileage(15.0);
        vehicle.setFeatureDescription("Air conditioning, Bluetooth");
        vehicle.setInsuranceNumber("INS12345");
        vehicle.setVehicleImageURL("http://example.com/car.jpg");
        
        vehicle.onCreate(); 

        assertNotNull(vehicle.getCreatedAt());
        assertNotNull(vehicle.getUpdatedAt());
        assertEquals("Toyota Corolla", vehicle.getModelName());
        assertEquals("XYZ123", vehicle.getRegistrationNumber());
    }

    @Test
    void vehicleUpdateShouldChangeUpdatedAt() {
        vehicle.setModelName("Honda Civic");
        vehicle.setRegistrationNumber("ABC456");

        vehicle.onCreate(); 
        LocalDateTime initialUpdatedAt = vehicle.getUpdatedAt();

        try { Thread.sleep(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }

        vehicle.onUpdate(); 
        assertTrue(vehicle.getUpdatedAt().isAfter(initialUpdatedAt));
    }

    @Test
    void vehicleShouldNotBeDeletedByDefault() {
        assertFalse(vehicle.isDeleted());  
    }

    @Test
    void vehicleShouldAllowDeletion() {
        vehicle.setDeleted(true);
        assertTrue(vehicle.isDeleted()); 
    }

    @Test
    void shouldNotAllowEmptyModelName() {
        vehicle.setModelName("");
        assertThrows(IllegalArgumentException.class, () -> {
            if (vehicle.getModelName().isEmpty()) {
                throw new IllegalArgumentException("Model name cannot be empty");
            }
        });
    }

    @Test
    void shouldNotAllowNullRegistrationNumber() {
        vehicle.setRegistrationNumber(null);
        assertThrows(NullPointerException.class, () -> {
            if (vehicle.getRegistrationNumber() == null) {
                throw new NullPointerException("Registration number cannot be null");
            }
        });
    }

    @Test
    void vehicleUpdateShouldNotResetCreatedAt() {
        vehicle.setModelName("Ford Focus");
        vehicle.setRegistrationNumber("DEF789");

        vehicle.onCreate(); 
        LocalDateTime initialCreatedAt = vehicle.getCreatedAt();

        try { Thread.sleep(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }

        vehicle.onUpdate(); 
        assertEquals(initialCreatedAt, vehicle.getCreatedAt());
    }

    @Test
    void vehiclePricePerDayShouldNotBeNegative() {
        vehicle.setPricePerDay(-10.0);
        assertThrows(IllegalArgumentException.class, () -> {
            if (vehicle.getPricePerDay() < 0) {
                throw new IllegalArgumentException("Price per day cannot be negative");
            }
        });
    }
}

