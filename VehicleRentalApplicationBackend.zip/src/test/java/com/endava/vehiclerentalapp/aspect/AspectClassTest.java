package com.endava.vehiclerentalapp.aspect;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AspectClassTest {

    @Mock
    private ProceedingJoinPoint proceedingJoinPoint;

    @Mock
    private JoinPoint joinPoint;

    @Mock
    private Signature signature;

    @InjectMocks
    private AspectClass aspectClass;

    static class DummyController {}
    static class DummyService {}
    static class DummySecurity {}

    @Test
    void testLogAroundMethodExecution_Controller_Positive() throws Throwable {
        DummyController dummy = new DummyController();
        when(proceedingJoinPoint.getTarget()).thenReturn(dummy);
        when(proceedingJoinPoint.getSignature()).thenReturn(signature);
        when(signature.getName()).thenReturn("dummyControllerMethod");
        when(proceedingJoinPoint.proceed()).thenReturn("Controller Success");

        Object result = aspectClass.logAroundMethodExecution(proceedingJoinPoint);
        assertEquals("Controller Success", result);
        verify(proceedingJoinPoint, times(1)).proceed();
    }

    @Test
    void testLogAroundMethodExecution_Controller_Negative() throws Throwable {
        DummyController dummy = new DummyController();
        when(proceedingJoinPoint.getTarget()).thenReturn(dummy);
        when(proceedingJoinPoint.getSignature()).thenReturn(signature);
        when(signature.getName()).thenReturn("dummyControllerMethod");

        RuntimeException ex = new RuntimeException("Controller exception");
        when(proceedingJoinPoint.proceed()).thenThrow(ex);

        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            aspectClass.logAroundMethodExecution(proceedingJoinPoint);
        });
        assertEquals("Controller exception", thrown.getMessage());
    }

    @Test
    void testLogAfterThrowing_Controller_Positive() {
        DummyController dummy = new DummyController();
        when(joinPoint.getTarget()).thenReturn(dummy);
        when(joinPoint.getSignature()).thenReturn(signature);
        when(signature.getName()).thenReturn("dummyControllerMethod");

        Exception error = new Exception("Controller error");
        // The advice is void; we simply verify that no exception is thrown when invoked.
        assertDoesNotThrow(() -> aspectClass.logAfterThrowing(joinPoint, error));
    }

    @Test
    void testLogAroundServiceMethodExecution_Positive() throws Throwable {
        DummyService dummy = new DummyService();
        when(proceedingJoinPoint.getTarget()).thenReturn(dummy);
        when(proceedingJoinPoint.getSignature()).thenReturn(signature);
        when(signature.getName()).thenReturn("dummyServiceMethod");
        when(proceedingJoinPoint.proceed()).thenReturn("Service Success");

        Object result = aspectClass.logAroundServiceMethodExecution(proceedingJoinPoint);
        assertEquals("Service Success", result);
        verify(proceedingJoinPoint, times(1)).proceed();
    }

    @Test
    void testLogAroundServiceMethodExecution_Negative() throws Throwable {
        DummyService dummy = new DummyService();
        when(proceedingJoinPoint.getTarget()).thenReturn(dummy);
        when(proceedingJoinPoint.getSignature()).thenReturn(signature);
        when(signature.getName()).thenReturn("dummyServiceMethod");

        RuntimeException ex = new RuntimeException("Service exception");
        when(proceedingJoinPoint.proceed()).thenThrow(ex);

        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            aspectClass.logAroundServiceMethodExecution(proceedingJoinPoint);
        });
        assertEquals("Service exception", thrown.getMessage());
    }

    @Test
    void testLogAfterServiceThrowing_Positive() {
        DummyService dummy = new DummyService();
        when(joinPoint.getTarget()).thenReturn(dummy);
        when(joinPoint.getSignature()).thenReturn(signature);
        when(signature.getName()).thenReturn("dummyServiceMethod");

        Exception error = new Exception("Service error");
        assertDoesNotThrow(() -> aspectClass.logAfterServiceThrowing(joinPoint, error));
    }

    @Test
    void testLogAroundSecurityMethodExecution_Positive() throws Throwable {
        DummySecurity dummy = new DummySecurity();
        when(proceedingJoinPoint.getTarget()).thenReturn(dummy);
        when(proceedingJoinPoint.getSignature()).thenReturn(signature);
        when(signature.getName()).thenReturn("dummySecurityMethod");
        when(proceedingJoinPoint.proceed()).thenReturn("Security Success");

        Object result = aspectClass.logAroundSecurityMethodExecution(proceedingJoinPoint);
        assertEquals("Security Success", result);
        verify(proceedingJoinPoint, times(1)).proceed();
    }

    @Test
    void testLogAroundSecurityMethodExecution_Negative() throws Throwable {
        DummySecurity dummy = new DummySecurity();
        when(proceedingJoinPoint.getTarget()).thenReturn(dummy);
        when(proceedingJoinPoint.getSignature()).thenReturn(signature);
        when(signature.getName()).thenReturn("dummySecurityMethod");

        RuntimeException ex = new RuntimeException("Security exception");
        when(proceedingJoinPoint.proceed()).thenThrow(ex);

        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            aspectClass.logAroundSecurityMethodExecution(proceedingJoinPoint);
        });
        assertEquals("Security exception", thrown.getMessage());
    }

    @Test
    void testLogAfterSecurityThrowing_Positive() {
        DummySecurity dummy = new DummySecurity();
        when(joinPoint.getTarget()).thenReturn(dummy);
        when(joinPoint.getSignature()).thenReturn(signature);
        when(signature.getName()).thenReturn("dummySecurityMethod");

        Exception error = new Exception("Security error");
        assertDoesNotThrow(() -> aspectClass.logAfterSecurityThrowing(joinPoint, error));
    }
}
