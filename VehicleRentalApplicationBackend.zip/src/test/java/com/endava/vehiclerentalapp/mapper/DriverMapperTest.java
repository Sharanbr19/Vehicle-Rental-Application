package com.endava.vehiclerentalapp.mapper;

import static org.junit.jupiter.api.Assertions.*;
import com.endava.vehiclerentalapp.dto.DriverDTO;
import com.endava.vehiclerentalapp.dto.DriverBookingDateDTO;
import com.endava.vehiclerentalapp.entity.Driver;
import com.endava.vehiclerentalapp.entity.DriverBookingDate;
import com.endava.vehiclerentalapp.entity.Users;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DriverMapperTest {

    private DriverMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new DriverMapper();
    }

    @Test
    void testToDTO_Positive() {
        Driver driver = new Driver();
        driver.setDriverId(1L);
        driver.setName("Test Driver");
        driver.setEmail("test@driver.com");
        driver.setContactNumber("1234567890");
        driver.setLicenseNumber("LIC123");
        driver.setDriverCostPerDay(100.0);
        Users admin = new Users();
        admin.setUserId(10L);
        driver.setAdmin(admin);
        LocalDate now = LocalDate.now();
        driver.setCreatedAt(LocalDateTime.now());
        driver.setUpdatedAt(LocalDateTime.now());
        driver.setCreatedBy("creator");
        driver.setUpdatedBy("updater");
        driver.setIsDeleted(false);
        DriverBookingDate bookingDate = new DriverBookingDate();
        bookingDate.setId(100L);
        bookingDate.setBookingDate(now.plusDays(1));
        bookingDate.setDriver(driver);
        driver.setDriverBookingDates(List.of(bookingDate));

        DriverDTO dto = mapper.toDTO(driver);
        assertNotNull(dto, "DTO should not be null");
        assertEquals(driver.getDriverId(), dto.getDriverId());
        assertEquals(driver.getName(), dto.getName());
        assertEquals(driver.getEmail(), dto.getEmail());
        assertEquals(driver.getContactNumber(), dto.getContactNumber());
        assertEquals(driver.getLicenseNumber(), dto.getLicenseNumber());
        assertEquals(driver.getDriverCostPerDay(), dto.getDriverCostPerDay());
        assertEquals(admin.getUserId(), dto.getAdminId());
        assertEquals(driver.getCreatedAt(), dto.getCreatedAt());
        assertEquals(driver.getUpdatedAt(), dto.getUpdatedAt());
        assertEquals(driver.getCreatedBy(), dto.getCreatedBy());
        assertEquals(driver.getUpdatedBy(), dto.getUpdatedBy());
        assertEquals(driver.getIsDeleted(), dto.getIsDeleted());
        assertNotNull(dto.getDriverBookingDates(), "Driver booking dates list should not be null");
        assertEquals(1, dto.getDriverBookingDates().size());
        assertEquals(bookingDate.getBookingDate(), dto.getDriverBookingDates().get(0));
    }

    @Test
    void testToDTO_NullAdmin() {
        Driver driver = new Driver();
        driver.setDriverId(2L);
        driver.setName("Driver No Admin");
        driver.setEmail("noadmin@driver.com");
        driver.setContactNumber("0000000000");
        driver.setLicenseNumber("LIC000");
        driver.setDriverCostPerDay(50.0);
        driver.setAdmin(null);
        LocalDateTime now = LocalDateTime.now();
        driver.setCreatedAt(now);
        driver.setUpdatedAt(now);
        driver.setCreatedBy("creator");
        driver.setUpdatedBy("updater");
        driver.setIsDeleted(false);
        driver.setDriverBookingDates(List.of());

        DriverDTO dto = mapper.toDTO(driver);
        assertNotNull(dto);
        assertNull(dto.getAdminId(), "Admin ID should be null when driver's admin is null");
    }

    @Test
    void testToDTO_NullBookingDates() {
        Driver driver = new Driver();
        driver.setDriverId(3L);
        driver.setName("Driver No Bookings");
        driver.setEmail("nobookings@driver.com");
        driver.setContactNumber("1111111111");
        driver.setLicenseNumber("LIC111");
        driver.setDriverCostPerDay(75.0);
        Users admin = new Users();
        admin.setUserId(20L);
        driver.setAdmin(admin);
        LocalDateTime now = LocalDateTime.now();
        driver.setCreatedAt(now);
        driver.setUpdatedAt(now);
        driver.setCreatedBy("creator");
        driver.setUpdatedBy("updater");
        driver.setIsDeleted(false);
        driver.setDriverBookingDates(null);  

        DriverDTO dto = mapper.toDTO(driver);
        assertNotNull(dto);
        assertTrue(dto.getDriverBookingDates().isEmpty(),
                "Driver booking dates in DTO should be empty when source is null");
    }


    @Test
    void testToEntity_Positive() {
        DriverDTO dto = new DriverDTO();
        dto.setDriverId(4L);
        dto.setName("DTO Driver");
        dto.setEmail("dto@driver.com");
        dto.setContactNumber("2222222222");
        dto.setLicenseNumber("LIC222");
        dto.setDriverCostPerDay(120.0);
        dto.setAdminId(30L);
        LocalDate now = LocalDate.now();
        dto.setCreatedAt(LocalDateTime.now());
        dto.setUpdatedAt(LocalDateTime.now());
        dto.setCreatedBy("creatorDTO");
        dto.setUpdatedBy("updaterDTO");
        dto.setIsDeleted(false);
        dto.setDriverBookingDates(List.of(now.plusDays(2), now.plusDays(3)));

        Driver driver = mapper.toEntity(dto);
        assertNotNull(driver);
        assertEquals(dto.getDriverId(), driver.getDriverId());
        assertEquals(dto.getName(), driver.getName());
        assertEquals(dto.getEmail(), driver.getEmail());
        assertEquals(dto.getContactNumber(), driver.getContactNumber());
        assertEquals(dto.getLicenseNumber(), driver.getLicenseNumber());
        assertEquals(dto.getDriverCostPerDay(), driver.getDriverCostPerDay());
        assertEquals(dto.getCreatedAt(), driver.getCreatedAt());
        assertEquals(dto.getUpdatedAt(), driver.getUpdatedAt());
        assertEquals(dto.getCreatedBy(), driver.getCreatedBy());
        assertEquals(dto.getUpdatedBy(), driver.getUpdatedBy());
        assertEquals(dto.getIsDeleted(), driver.getIsDeleted());
        assertNotNull(driver.getDriverBookingDates());
        assertEquals(dto.getDriverBookingDates().size(), driver.getDriverBookingDates().size());
        for (int i = 0; i < dto.getDriverBookingDates().size(); i++) {
            assertEquals(dto.getDriverBookingDates().get(i), driver.getDriverBookingDates().get(i).getBookingDate());
            assertNotNull(driver.getDriverBookingDates().get(i).getDriver());
            assertEquals(driver.getDriverId(), driver.getDriverBookingDates().get(i).getDriver().getDriverId());
        }
    }

    @Test
    void testToEntity_NullBookingDatesInDTO() {
        DriverDTO dto = new DriverDTO();
        dto.setDriverId(5L);
        dto.setName("No Bookings DTO");
        dto.setEmail("nobookingsdto@driver.com");
        dto.setContactNumber("3333333333");
        dto.setLicenseNumber("LIC333");
        dto.setDriverCostPerDay(80.0);
        dto.setAdminId(40L);
        LocalDateTime now = LocalDateTime.now();
        dto.setCreatedAt(now);
        dto.setUpdatedAt(now);
        dto.setCreatedBy("creator");
        dto.setUpdatedBy("updater");
        dto.setIsDeleted(false);
        dto.setDriverBookingDates(null);

        Driver driver = mapper.toEntity(dto);
        assertNotNull(driver);
        assertNull(driver.getDriverBookingDates(), "Driver booking dates should be null when DTO booking dates are null");
    }

    @Test
    void testDriverBookingDateToDTO_Positive() {
        DriverBookingDate driverBookingDate = new DriverBookingDate();
        driverBookingDate.setId(10L);
        LocalDate bookingDate = LocalDate.now().plusDays(5);
        driverBookingDate.setBookingDate(bookingDate);
        Driver driver = new Driver();
        driver.setDriverId(100L);
        driverBookingDate.setDriver(driver);

        DriverBookingDateDTO dto = mapper.toDTO(driverBookingDate);
        assertNotNull(dto);
        assertEquals(driverBookingDate.getId(), dto.getDriverBookingDateId());
        assertEquals(bookingDate, dto.getBookedDate());
        assertEquals(driver.getDriverId(), dto.getDriverId());
    }

    @Test
    void testDriverBookingDateToDTO_NullDriver() {
        DriverBookingDate driverBookingDate = new DriverBookingDate();
        driverBookingDate.setId(20L);
        driverBookingDate.setBookingDate(LocalDate.now().plusDays(3));
        driverBookingDate.setDriver(null);
        assertThrows(NullPointerException.class, () -> mapper.toDTO(driverBookingDate));
    }

    @Test
    void testDriverBookingDateToEntity_Positive() {
        DriverBookingDateDTO dto = new DriverBookingDateDTO();
        dto.setDriverBookingDateId(30L);
        LocalDate bookedDate = LocalDate.now().plusDays(7);
        dto.setBookedDate(bookedDate);
        dto.setDriverId(200L);

        DriverBookingDate entity = mapper.toEntity(dto);
        assertNotNull(entity);
        assertEquals(bookedDate, entity.getBookingDate());
        assertNotNull(entity.getDriver());
        assertEquals(200L, entity.getDriver().getDriverId());
    }


    @Test
    void testDriverBookingDateToEntity_NullDriverId() {
        DriverBookingDateDTO dto = new DriverBookingDateDTO();
        dto.setDriverBookingDateId(40L);
        LocalDate bookedDate = LocalDate.now().plusDays(8);
        dto.setBookedDate(bookedDate);
        dto.setDriverId(null);

        DriverBookingDate entity = mapper.toEntity(dto);
        assertNotNull(entity);
        assertEquals(bookedDate, entity.getBookingDate());
        assertNotNull(entity.getDriver());
        assertNull(entity.getDriver().getDriverId(), "DriverId should be null when DTO driverId is null");
    }
}
