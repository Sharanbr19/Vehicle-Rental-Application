package com.endava.vehiclerentalapp.mapper;

import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import com.endava.vehiclerentalapp.dto.UserDto;
import com.endava.vehiclerentalapp.entity.UserType;
import com.endava.vehiclerentalapp.entity.Users;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UserMapperTest {

    private UserMapper mapper;
    private UserDto validUserDto;
    private String currentAdminEmail;

    @BeforeEach
    void setUp() {
        mapper = new UserMapper();
        currentAdminEmail = "admin@example.com";
        
        validUserDto = new UserDto();
        validUserDto.setName("John Doe");
        validUserDto.setEmail("john.doe@example.com");
        validUserDto.setPassword("password123");
        validUserDto.setContactNumber("1234567890");
        validUserDto.setAddress("123 Main St");
        validUserDto.setGender("Male");
        validUserDto.setUserType("CUSTOMER"); 
        validUserDto.setDateOfBirth(LocalDate.of(1990, 1, 1));
        validUserDto.setDeleted(false);
        validUserDto.setCreatedAt(LocalDateTime.of(2022, 1, 1, 10, 0));
        validUserDto.setUpdatedAt(LocalDateTime.of(2022, 1, 1, 10, 0));
        validUserDto.setCreatedBy(null); 
        validUserDto.setUpdatedBy(null);
    }

    @Test
    void testToEntity_Positive() {
        Users user = mapper.toEntity(validUserDto, currentAdminEmail);
        assertNotNull(user);
        assertEquals(validUserDto.getName(), user.getName());
        assertEquals(validUserDto.getEmail(), user.getEmail());
        assertEquals(validUserDto.getPassword(), user.getPassword());
        assertEquals(validUserDto.getContactNumber(), user.getContactNumber());
        assertEquals(validUserDto.getAddress(), user.getAddress());
        assertEquals(validUserDto.getGender(), user.getGender());
        assertEquals(UserType.CUSTOMER, user.getUserType());
        assertEquals(validUserDto.getDateOfBirth(), user.getDateOfBirth());
        assertFalse(user.isDeleted());
        assertNotNull(user.getCreatedAt());
        assertNotNull(user.getUpdatedAt());
        assertEquals(currentAdminEmail, user.getCreatedBy());
        assertEquals(currentAdminEmail, user.getUpdatedBy());
    }

    @Test
    void testToEntity_NullUserDto_ShouldReturnNullPointerException() {
        assertThrows(NullPointerException.class, () -> mapper.toEntity(null, currentAdminEmail));
    }

    @Test
    void testToEntity_InvalidUserType_ShouldThrowIllegalArgumentException() {
        validUserDto.setUserType("INVALID_TYPE");
        assertThrows(IllegalArgumentException.class, () -> mapper.toEntity(validUserDto, currentAdminEmail));
    }

    @Test
    void testToEntity_NullAdminEmail_ShouldSetCreatedAndUpdatedByToNull() {
        Users user = mapper.toEntity(validUserDto, null);
        assertNull(user.getCreatedBy());
        assertNull(user.getUpdatedBy());
    }

    @Test
    void testToDto_Positive() {
        Users user = new Users();
        user.setName("Jane Smith");
        user.setEmail("jane.smith@example.com");
        user.setPassword("securePass");
        user.setContactNumber("0987654321");
        user.setAddress("456 Secondary St");
        user.setGender("Female");
        user.setUserType(UserType.ADMIN);
        user.setDateOfBirth(LocalDate.of(1985, 5, 20));
        user.setDeleted(false);
        LocalDateTime timestamp = LocalDateTime.now();
        user.setCreatedAt(timestamp);
        user.setUpdatedAt(timestamp);
        user.setCreatedBy("admin@example.com");
        user.setUpdatedBy("admin@example.com");

        UserDto dto = mapper.toDto(user);
        assertNotNull(dto);
        assertEquals(user.getName(), dto.getName());
        assertEquals(user.getEmail(), dto.getEmail());
        assertEquals(user.getPassword(), dto.getPassword());
        assertEquals(user.getContactNumber(), dto.getContactNumber());
        assertEquals(user.getAddress(), dto.getAddress());
        assertEquals(user.getGender(), dto.getGender());
        assertEquals(user.getUserType().name(), dto.getUserType());
        assertEquals(user.getDateOfBirth(), dto.getDateOfBirth());
        assertEquals(user.isDeleted(), dto.isDeleted());
        assertEquals(user.getCreatedAt(), dto.getCreatedAt());
        assertEquals(user.getUpdatedAt(), dto.getUpdatedAt());
        assertEquals(user.getCreatedBy(), dto.getCreatedBy());
        assertEquals(user.getUpdatedBy(), dto.getUpdatedBy());
    }
    
    @Test
    void testToDto_NullUser_ShouldThrowNullPointerException() {
        assertThrows(NullPointerException.class, () -> mapper.toDto(null));
    }

    @Test
    void testToDto_NullUserType_ShouldThrowNullPointerException() {
        Users user = new Users();
        user.setName("Test");
        user.setEmail("test@example.com");
        user.setPassword("pass");
        user.setContactNumber("0001112222");
        user.setAddress("No Address");
        user.setGender("Other");
        user.setUserType(null); // purposely set null
        user.setDateOfBirth(LocalDate.of(2000, 1, 1));
        user.setDeleted(false);
        LocalDateTime now = LocalDateTime.now();
        user.setCreatedAt(now);
        user.setUpdatedAt(now);
        user.setCreatedBy("admin@example.com");
        user.setUpdatedBy("admin@example.com");

        assertThrows(NullPointerException.class, () -> mapper.toDto(user));
    }
}
