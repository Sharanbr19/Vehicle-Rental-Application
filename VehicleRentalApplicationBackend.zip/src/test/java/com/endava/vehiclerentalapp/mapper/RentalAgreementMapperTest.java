package com.endava.vehiclerentalapp.mapper;

import static org.junit.jupiter.api.Assertions.*;
import com.endava.vehiclerentalapp.dto.RentalAgreementDTO;
import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.RentalAgreement;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RentalAgreementMapperTest {

    private RentalAgreementMapper mapper;
    
    private RentalAgreement rentalAgreement;
    private RentalAgreementDTO rentalAgreementDTO;
    private Booking dummyBooking;
    private String now;

    @BeforeEach
    void setUp() {
        mapper = new RentalAgreementMapper();
        now = "2023-01-01T10:00:00";

        dummyBooking = new Booking();
        dummyBooking.setBookingId(500L);

        rentalAgreement = new RentalAgreement();
        rentalAgreement.setRentalId(100L);
        rentalAgreement.setAgreementDate(now);
        rentalAgreement.setTermsAndConditions("Standard Terms");
        rentalAgreement.setBooking(dummyBooking);

        rentalAgreementDTO = new RentalAgreementDTO();
        rentalAgreementDTO.setRentalId(200L);
        rentalAgreementDTO.setAgreementDate("2023-01-02T10:00:00");
        rentalAgreementDTO.setTermsAndConditions("Special Terms");
        rentalAgreementDTO.setBookingId(600L);
    }

    @Test
    void testToDTO_Positive() {
        RentalAgreementDTO dto = mapper.toDTO(rentalAgreement);
        assertNotNull(dto, "Mapped DTO should not be null");
        assertEquals(rentalAgreement.getRentalId(), dto.getRentalId());
        assertEquals(rentalAgreement.getAgreementDate(), dto.getAgreementDate());
        assertEquals(rentalAgreement.getTermsAndConditions(), dto.getTermsAndConditions());
        assertNotNull(rentalAgreement.getBooking(), "Booking in RentalAgreement should not be null");
        assertEquals(rentalAgreement.getBooking().getBookingId(), dto.getBookingId());
    }

    @Test
    void testToDTO_NullRentalAgreement() {
        assertThrows(NullPointerException.class, () -> mapper.toDTO(null));
    }

    @Test
    void testToDTO_NullBookingInRentalAgreement() {
        rentalAgreement.setBooking(null);
        assertThrows(NullPointerException.class, () -> mapper.toDTO(rentalAgreement));
    }

    @Test
    void testToEntity_Positive() {
        RentalAgreement entity = mapper.toEntity(rentalAgreementDTO);
        assertNotNull(entity, "Mapped RentalAgreement entity should not be null");
        assertEquals(rentalAgreementDTO.getRentalId(), entity.getRentalId());
        assertEquals(rentalAgreementDTO.getAgreementDate(), entity.getAgreementDate());
        assertEquals(rentalAgreementDTO.getTermsAndConditions(), entity.getTermsAndConditions());
        assertNull(entity.getBooking(), "Booking should be null when mapping from DTO using toEntity()");
    }

    @Test
    void testToEntity_NullRentalAgreementDTO() {
        assertThrows(NullPointerException.class, () -> mapper.toEntity(null));
    }
}
