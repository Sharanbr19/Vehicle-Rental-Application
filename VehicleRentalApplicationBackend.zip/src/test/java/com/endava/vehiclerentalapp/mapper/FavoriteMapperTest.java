package com.endava.vehiclerentalapp.mapper;

import static org.junit.jupiter.api.Assertions.*;
import com.endava.vehiclerentalapp.dto.FavoriteDTO;
import com.endava.vehiclerentalapp.entity.Favorite;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.entity.Vehicle;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FavoriteMapperTest {

    private FavoriteMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new FavoriteMapper();
    }

    @Test
    void testToDto_Positive() {
        Favorite favorite = new Favorite();
        favorite.setFavoriteId(1L);

        Users customer = new Users();
        customer.setUserId(10L);
        favorite.setCustomer(customer);

        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(100L);
        favorite.setVehicle(vehicle);

        FavoriteDTO dto = mapper.toDto(favorite);
        assertNotNull(dto, "Mapped DTO should not be null");
        assertEquals(1L, dto.getFavoriteId());
        assertEquals(10L, dto.getUserId());
        assertEquals(100L, dto.getVehicleId());
    }

    @Test
    void testToDto_NullFavorite() {
        FavoriteDTO dto = mapper.toDto(null);
        assertNull(dto, "Mapping null Favorite should return null");
    }

    @Test
    void testToDto_NullCustomer() {
        Favorite favorite = new Favorite();
        favorite.setFavoriteId(1L);
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(100L);
        favorite.setVehicle(vehicle);

        assertThrows(NullPointerException.class, () -> mapper.toDto(favorite),
                "Mapping Favorite with null customer should throw NullPointerException");
    }

    @Test
    void testToDto_NullVehicle() {
        Favorite favorite = new Favorite();
        favorite.setFavoriteId(1L);
        Users customer = new Users();
        customer.setUserId(10L);
        favorite.setCustomer(customer);
        assertThrows(NullPointerException.class, () -> mapper.toDto(favorite),
                "Mapping Favorite with null vehicle should throw NullPointerException");
    }

    @Test
    void testToEntity_Positive() {
        FavoriteDTO dto = new FavoriteDTO();
        dto.setFavoriteId(2L);
        dto.setUserId(20L);
        dto.setVehicleId(200L);

        Favorite favorite = mapper.toEntity(dto);
        assertNotNull(favorite, "Mapped Favorite entity should not be null");
        assertEquals(2L, favorite.getFavoriteId());
        assertNotNull(favorite.getCustomer());
        assertEquals(20L, favorite.getCustomer().getUserId());
        assertNotNull(favorite.getVehicle());
        assertEquals(200L, favorite.getVehicle().getVehicleId());
    }

    @Test
    void testToEntity_NullFavoriteDTO() {
        Favorite favorite = mapper.toEntity(null);
        assertNull(favorite, "Mapping null FavoriteDTO should return null");
    }

    @Test
    void testToEntity_NullUserIdOrVehicleId() {
        FavoriteDTO dto = new FavoriteDTO();
        dto.setFavoriteId(3L);
        dto.setUserId(null);
        dto.setVehicleId(null);

        Favorite favorite = mapper.toEntity(dto);
        assertNotNull(favorite, "Mapped Favorite entity should not be null");
        assertEquals(3L, favorite.getFavoriteId());
        assertNotNull(favorite.getCustomer(), "Customer should be instantiated even if userId is null");
        assertNull(favorite.getCustomer().getUserId(), "UserId should be null when DTO's userId is null");
        assertNotNull(favorite.getVehicle(), "Vehicle should be instantiated even if vehicleId is null");
        assertNull(favorite.getVehicle().getVehicleId(), "VehicleId should be null when DTO's vehicleId is null");
    }
}

