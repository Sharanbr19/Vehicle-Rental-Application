package com.endava.vehiclerentalapp.mapper;

import static org.junit.jupiter.api.Assertions.*;

import com.endava.vehiclerentalapp.dto.PaymentDTO;
import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.Payment;
import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PaymentMapperTest {

    private PaymentMapper mapper;
    private PaymentDTO paymentDTO;
    private Payment payment;
    private Booking dummyBooking;
    private LocalDateTime now;

    @BeforeEach
    void setUp() {
        mapper = new PaymentMapper();
        now = LocalDateTime.now();

        dummyBooking = new Booking();
        dummyBooking.setBookingId(500L);

        paymentDTO = new PaymentDTO();
        paymentDTO.setPaymentId(100L);
        paymentDTO.setAmount(250.75);
        paymentDTO.setPaymentDateAndTime(now.plusDays(1));
        paymentDTO.setRazorpayId("razor123");
        paymentDTO.setBookingId(600L);

        payment = new Payment();
        payment.setPaymentId(200L);
        payment.setAmount(500.50);
        payment.setPaymentDateAndTime(now.plusDays(2));
        payment.setRazorPayId("razor456");
        payment.setBooking(dummyBooking);
    }

    @Test
    void testToEntity_Positive_WithValidBooking() {
        Payment entity = mapper.toEntity(paymentDTO, dummyBooking);
        assertNotNull(entity, "Mapped Payment entity should not be null");
        assertEquals(paymentDTO.getPaymentId(), entity.getPaymentId());
        assertEquals(paymentDTO.getAmount(), entity.getAmount());
        assertEquals(paymentDTO.getPaymentDateAndTime(), entity.getPaymentDateAndTime());
        assertEquals(paymentDTO.getRazorpayId(), entity.getRazorPayId());
        assertNotNull(entity.getBooking());
        assertEquals(dummyBooking.getBookingId(), entity.getBooking().getBookingId());
    }

    @Test
    void testToEntity_Positive_WithNullBooking() {
        Payment entity = mapper.toEntity(paymentDTO, null);
        assertNotNull(entity, "Mapped Payment entity should not be null");
        assertNull(entity.getBooking(), "Booking should be null when provided booking is null");
    }

    @Test
    void testToEntity_NullPaymentDTO_ShouldThrowException() {
        assertThrows(NullPointerException.class, () -> mapper.toEntity(null, dummyBooking));
    }
    
    @Test
    void testToDTO_Positive_WithBooking() {
        PaymentDTO dto = mapper.toDTO(payment);
        assertNotNull(dto, "Mapped PaymentDTO should not be null");
        assertEquals(payment.getPaymentId(), dto.getPaymentId());
        assertEquals(payment.getAmount(), dto.getAmount());
        assertEquals(payment.getPaymentDateAndTime(), dto.getPaymentDateAndTime());
        assertEquals(payment.getRazorPayId(), dto.getRazorpayId());
        assertNotNull(payment.getBooking());
        assertEquals(payment.getBooking().getBookingId(), dto.getBookingId());
    }

    @Test
    void testToDTO_Positive_NullBooking() {
        payment.setBooking(null);
        PaymentDTO dto = mapper.toDTO(payment);
        assertNotNull(dto, "Mapped PaymentDTO should not be null");
        assertNull(dto.getBookingId(), "BookingId should be null when Payment's booking is null");
    }

    @Test
    void testToDTO_NullPayment_ShouldThrowException() {
        assertThrows(NullPointerException.class, () -> mapper.toDTO(null));
    }
}

