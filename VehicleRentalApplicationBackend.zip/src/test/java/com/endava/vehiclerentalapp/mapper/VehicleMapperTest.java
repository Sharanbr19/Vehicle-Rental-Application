package com.endava.vehiclerentalapp.mapper;

import static org.junit.jupiter.api.Assertions.*;
import com.endava.vehiclerentalapp.dto.VehicleDTO;
import com.endava.vehiclerentalapp.dto.VehicleBookingDateDTO;
import com.endava.vehiclerentalapp.entity.Vehicle;
import com.endava.vehiclerentalapp.entity.VehicleBookingDate;
import com.endava.vehiclerentalapp.entity.Users;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class VehicleMapperTest {

    private VehicleMapper mapper;
    private Vehicle vehicle;
    private VehicleDTO vehicleDTO;
    private Users admin;
    private VehicleBookingDate bookingDate;

    @BeforeEach
    void setUp() {
        mapper = new VehicleMapper();

        admin = new Users();
        admin.setUserId(1L);
        admin.setEmail("admin@example.com");

        bookingDate = new VehicleBookingDate();
        bookingDate.setVehicleBookingDateId(10L);
        bookingDate.setBookedDate(LocalDate.now());

        vehicle = new Vehicle();
        vehicle.setVehicleId(100L);
        vehicle.setModelName("Test Model");
        vehicle.setRegistrationNumber("ABC123");
        vehicle.setCategoryType("Sedan");
        vehicle.setFuelType("Petrol");
        vehicle.setColor("Red");
        vehicle.setModelYear("2020");
        vehicle.setPricePerDay(150.0);
        vehicle.setMileage(10.5);
        vehicle.setFeatureDescription("Features");
        vehicle.setInsuranceNumber("INS123");
        vehicle.setVehicleImageURL("http://example.com/image.jpg");
        vehicle.setVehicleBookingDates(List.of(bookingDate));
        LocalDateTime now = LocalDateTime.now();
        vehicle.setCreatedAt(now);
        vehicle.setUpdatedAt(now);
        vehicle.setDeleted(false);
        vehicle.setCreatedBy("creator@example.com");
        vehicle.setUpdatedBy("updater@example.com");

        vehicleDTO = new VehicleDTO();
        vehicleDTO.setVehicleId(200L);
        vehicleDTO.setModelName("DTO Model");
        vehicleDTO.setRegistrationNumber("XYZ789");
        vehicleDTO.setCategoryType("SUV");
        vehicleDTO.setFuelType("Diesel");
        vehicleDTO.setColor("Blue");
        vehicleDTO.setModelYear("2019");
        vehicleDTO.setPricePerDay(200.0);
        vehicleDTO.setMileage(12.0);
        vehicleDTO.setFeatureDescription("DTO Features");
        vehicleDTO.setInsuranceNumber("INS789");
        vehicleDTO.setVehicleImageURL("http://example.com/dto.jpg");
        vehicleDTO.setVehicleBookingDates(Collections.emptyList());
        vehicleDTO.setCreatedAt(now);
        vehicleDTO.setUpdatedAt(now);
        vehicleDTO.setIsDeleted(true);
        vehicleDTO.setCreatedBy(null);
        vehicleDTO.setUpdatedBy(null);
    }

    @Test
    void testToDto_Positive() {
        VehicleDTO dto = mapper.toDto(vehicle);
        assertNotNull(dto);
        assertEquals(vehicle.getVehicleId(), dto.getVehicleId());
        assertEquals(vehicle.getModelName(), dto.getModelName());
        assertEquals(vehicle.getRegistrationNumber(), dto.getRegistrationNumber());
        assertEquals(vehicle.getCategoryType(), dto.getCategoryType());
        assertEquals(vehicle.getFuelType(), dto.getFuelType());
        assertEquals(vehicle.getColor(), dto.getColor());
        assertEquals(vehicle.getModelYear(), dto.getModelYear());
        assertEquals(vehicle.getPricePerDay(), dto.getPricePerDay());
        assertEquals(vehicle.getMileage(), dto.getMileage());
        assertEquals(vehicle.getFeatureDescription(), dto.getFeatureDescription());
        assertEquals(vehicle.getInsuranceNumber(), dto.getInsuranceNumber());
        assertEquals(vehicle.getVehicleImageURL(), dto.getVehicleImageURL());
        List<VehicleBookingDateDTO> bookingDates = dto.getVehicleBookingDates();
        assertNotNull(bookingDates);
        assertEquals(1, bookingDates.size());
        VehicleBookingDateDTO bookingDTO = bookingDates.get(0);
        assertEquals(bookingDate.getVehicleBookingDateId(), bookingDTO.getVehicleBookingDateId());
        assertEquals(bookingDate.getBookedDate(), bookingDTO.getBookedDate());
        assertEquals(vehicle.getCreatedAt(), dto.getCreatedAt());
        assertEquals(vehicle.getUpdatedAt(), dto.getUpdatedAt());
        assertEquals(vehicle.isDeleted(), dto.getIsDeleted());
        assertEquals(vehicle.getCreatedBy(), dto.getCreatedBy());
        assertEquals(vehicle.getUpdatedBy(), dto.getUpdatedBy());
    }

    @Test
    void testToDto_NullVehicle() {
        VehicleDTO dto = mapper.toDto(null);
        assertNull(dto);
    }

    @Test
    void testToEntity_Positive() {
        Vehicle entity = mapper.toEntity(vehicleDTO, admin);
        assertNotNull(entity);
        assertEquals(vehicleDTO.getVehicleId(), entity.getVehicleId());
        assertEquals(vehicleDTO.getModelName(), entity.getModelName());
        assertEquals(vehicleDTO.getRegistrationNumber(), entity.getRegistrationNumber());
        assertEquals(vehicleDTO.getCategoryType(), entity.getCategoryType());
        assertEquals(vehicleDTO.getFuelType(), entity.getFuelType());
        assertEquals(vehicleDTO.getColor(), entity.getColor());
        assertEquals(vehicleDTO.getModelYear(), entity.getModelYear());
        assertEquals(vehicleDTO.getPricePerDay(), entity.getPricePerDay());
        assertEquals(vehicleDTO.getMileage(), entity.getMileage());
        assertEquals(vehicleDTO.getFeatureDescription(), entity.getFeatureDescription());
        assertEquals(vehicleDTO.getInsuranceNumber(), entity.getInsuranceNumber());
        assertEquals(vehicleDTO.getVehicleImageURL(), entity.getVehicleImageURL());
        assertEquals(vehicleDTO.getCreatedAt(), entity.getCreatedAt());
        assertEquals(vehicleDTO.getUpdatedAt(), entity.getUpdatedAt());
        assertEquals(vehicleDTO.getIsDeleted(), entity.isDeleted());
        assertEquals(admin.getEmail(), entity.getCreatedBy());
        assertEquals(admin.getEmail(), entity.getUpdatedBy());
    }

    @Test
    void testToEntity_NullVehicleDTO() {
        Vehicle entity = mapper.toEntity(null, admin);
        assertNull(entity);
    }

    @Test
    void testToEntity_NullAdmin() {
        Exception ex = assertThrows(NullPointerException.class, () -> mapper.toEntity(vehicleDTO, null));
        assertNotNull(ex.getMessage());
    }
}
