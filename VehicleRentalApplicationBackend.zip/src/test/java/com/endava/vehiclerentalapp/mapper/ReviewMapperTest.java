package com.endava.vehiclerentalapp.mapper;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.endava.vehiclerentalapp.dto.ReviewDTO;
import com.endava.vehiclerentalapp.entity.Review;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.entity.Vehicle;
import com.endava.vehiclerentalapp.repository.UserRepository;
import com.endava.vehiclerentalapp.repository.VehicleRepository;
import com.endava.vehiclerentalapp.util.Constants;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ReviewMapperTest {

	@Mock
	private UserRepository userRepository;

	@Mock
	private VehicleRepository vehicleRepository;

	@InjectMocks
	private ReviewMapper reviewMapper;

	private Users dummyUser;
	private Vehicle dummyVehicle;
	private Review dummyReview;
	private ReviewDTO dummyReviewDTO;

	@BeforeEach
	void setUp() {
		dummyUser = new Users();
		dummyUser.setUserId(1L);
		dummyUser.setName("Test User");

		dummyVehicle = new Vehicle();
		dummyVehicle.setVehicleId(100L);
		dummyVehicle.setModelName("Test Car");

		dummyReview = new Review();
		dummyReview.setReviewId(10L);
		dummyReview.setRating("4.5");
		dummyReview.setComment("Great vehicle!");
		dummyReview.setCustomer(dummyUser);
		dummyReview.setVehicle(dummyVehicle);

		dummyReviewDTO = new ReviewDTO(20L, "3.5", "Average experience", 1L, 100L);
	}

	@Test
	void testToDTO_Positive() {
		ReviewDTO dto = reviewMapper.toDTO(dummyReview);
		assertNotNull(dto, "DTO should not be null");
		assertEquals(dummyReview.getReviewId(), dto.getReviewId());
		assertEquals(dummyReview.getRating(), dto.getRating());
		assertEquals(dummyReview.getComment(), dto.getComment());
		assertEquals(dummyReview.getCustomer().getUserId(), dto.getCustomerId());
		assertEquals(dummyReview.getVehicle().getVehicleId(), dto.getVehicleId());
	}

	@Test
	void testToDTO_NullReview() {
		assertThrows(NullPointerException.class, () -> reviewMapper.toDTO(null));
	}

	@Test
	void testToEntity_Positive() {
		when(userRepository.findById(dummyReviewDTO.getCustomerId())).thenReturn(Optional.of(dummyUser));
		when(vehicleRepository.findById(dummyReviewDTO.getVehicleId())).thenReturn(Optional.of(dummyVehicle));

		Review review = reviewMapper.toEntity(dummyReviewDTO);
		assertNotNull(review, "Review entity should not be null");
		assertEquals(dummyReviewDTO.getReviewId(), review.getReviewId());
		assertEquals(dummyReviewDTO.getRating(), review.getRating());
		assertEquals(dummyReviewDTO.getComment(), review.getComment());
		assertEquals(dummyUser, review.getCustomer());
		assertEquals(dummyVehicle, review.getVehicle());
	}

	@Test
	void testToEntity_UserNotFound_Negative() {
		when(userRepository.findById(dummyReviewDTO.getCustomerId())).thenReturn(Optional.empty());

		IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
				() -> reviewMapper.toEntity(dummyReviewDTO));
		assertEquals(Constants.USER_NOT_FOUND, ex.getMessage());
	}

	@Test
	void testToEntity_VehicleNotFound_Negative() {
		when(userRepository.findById(dummyReviewDTO.getCustomerId())).thenReturn(Optional.of(dummyUser));
		when(vehicleRepository.findById(dummyReviewDTO.getVehicleId())).thenReturn(Optional.empty());

		IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
				() -> reviewMapper.toEntity(dummyReviewDTO));
		assertEquals(Constants.VEHICLE_NOT_FOUND + dummyReviewDTO.getVehicleId(), ex.getMessage());
	}
}