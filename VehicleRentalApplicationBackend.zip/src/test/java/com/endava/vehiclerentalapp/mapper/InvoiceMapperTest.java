package com.endava.vehiclerentalapp.mapper;

import static org.junit.jupiter.api.Assertions.*;

import com.endava.vehiclerentalapp.dto.InvoiceDTO;
import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.Invoice;
import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class InvoiceMapperTest {

    private InvoiceMapper mapper;
    private Invoice invoice;
    private InvoiceDTO invoiceDTO;
    private Booking dummyBooking;
    private String now;

    @BeforeEach
    void setUp() {
        mapper = new InvoiceMapper();
        now = LocalDateTime.now().toString();

        dummyBooking = new Booking();
        dummyBooking.setBookingId(500L);

        invoice = new Invoice();
        invoice.setInvoiceId(100L);
        invoice.setInvoiceDate(now);
        invoice.setTotalAmount(500.0);
        invoice.setBooking(dummyBooking);

        invoiceDTO = new InvoiceDTO();
        invoiceDTO.setInvoiceId(200L);
        invoiceDTO.setInvoiceDate(LocalDateTime.now().plusDays(1).toString());
        invoiceDTO.setTotalAmount(750.0);
        invoiceDTO.setBookingId(600L);
    }
    
    @Test
    void testToDTO_WithBooking_Positive() {
        InvoiceDTO dto = mapper.toDTO(invoice);
        assertNotNull(dto, "Mapped DTO should not be null");
        assertEquals(invoice.getInvoiceId(), dto.getInvoiceId());
        assertEquals(invoice.getInvoiceDate(), dto.getInvoiceDate());
        assertEquals(invoice.getTotalAmount(), dto.getTotalAmount());
        assertNotNull(invoice.getBooking(), "Booking in Invoice should not be null");
        assertEquals(dummyBooking.getBookingId(), dto.getBookingId());
    }
    
    @Test
    void testToDTO_NullBooking_Positive() {
        invoice.setBooking(null);
        InvoiceDTO dto = mapper.toDTO(invoice);
        assertNotNull(dto, "Mapped DTO should not be null");
        assertEquals(invoice.getInvoiceId(), dto.getInvoiceId());
        assertEquals(invoice.getInvoiceDate(), dto.getInvoiceDate());
        assertEquals(invoice.getTotalAmount(), dto.getTotalAmount());
        assertNull(dto.getBookingId(), "BookingId should be null when Invoice's booking is null");
    }
    
    @Test
    void testToDTO_NullInvoice_Negative() {
        assertThrows(NullPointerException.class, () -> mapper.toDTO(null));
    }
    
    @Test
    void testToEntity_WithBooking_Positive() {
        Invoice entity = mapper.toEntity(invoiceDTO, dummyBooking);
        assertNotNull(entity, "Mapped Invoice entity should not be null");
        assertEquals(invoiceDTO.getInvoiceId(), entity.getInvoiceId());
        assertEquals(invoiceDTO.getInvoiceDate(), entity.getInvoiceDate());
        assertEquals(invoiceDTO.getTotalAmount(), entity.getTotalAmount());
        assertNotNull(entity.getBooking(), "Booking should be set when provided");
        assertEquals(dummyBooking.getBookingId(), entity.getBooking().getBookingId());
    }
    
    @Test
    void testToEntity_NullBooking_Positive() {
        Invoice entity = mapper.toEntity(invoiceDTO, null);
        assertNotNull(entity, "Mapped Invoice entity should not be null");
        assertEquals(invoiceDTO.getInvoiceId(), entity.getInvoiceId());
        assertEquals(invoiceDTO.getInvoiceDate(), entity.getInvoiceDate());
        assertEquals(invoiceDTO.getTotalAmount(), entity.getTotalAmount());
        assertNull(entity.getBooking(), "Booking should be null when a null booking is provided");
    }
    
    @Test
    void testToEntity_NullInvoiceDTO_Negative() {
        assertThrows(NullPointerException.class, () -> mapper.toEntity(null, dummyBooking));
    }
}
