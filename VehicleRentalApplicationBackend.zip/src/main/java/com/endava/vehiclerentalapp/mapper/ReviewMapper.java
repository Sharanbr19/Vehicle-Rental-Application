package com.endava.vehiclerentalapp.mapper;

import com.endava.vehiclerentalapp.dto.ReviewDTO;
import com.endava.vehiclerentalapp.entity.Review;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.entity.Vehicle;
import com.endava.vehiclerentalapp.repository.UserRepository;
import com.endava.vehiclerentalapp.repository.VehicleRepository;
import com.endava.vehiclerentalapp.util.Constants;
import org.springframework.stereotype.Component;

/**
 * Mapper class responsible for converting between Review entities and ReviewDTOs.
 * This class handles the transformation of Review data between entity and DTO layers.
 */
@Component
public class ReviewMapper {

    private final UserRepository usersRepository;

    private final VehicleRepository vehicleRepository;

    public ReviewMapper(UserRepository userRepository, VehicleRepository vehicleRepository) {
    	this.usersRepository = userRepository;
    	this.vehicleRepository = vehicleRepository;
    }
    /**
     * Converts a Review entity to its corresponding ReviewDTO.
     *
     * @param review the Review entity to be converted
     * @return a ReviewDTO containing the review data
     */
    public ReviewDTO toDTO(Review review) {
        return new ReviewDTO(
                review.getReviewId(),
                review.getRating(),
                review.getComment(),
                review.getCustomer().getUserId(),
                review.getVehicle().getVehicleId()
        );
    }

    /**
     * Converts a ReviewDTO to its corresponding Review entity.
     * The method retrieves the associated Customer and Vehicle entities
     * from their respective repositories and sets them in the Review entity.
     *
     * @param reviewDTO the ReviewDTO to be converted
     * @return a Review entity populated with data from the ReviewDTO
     * @throws IllegalArgumentException if Customer or Vehicle cannot be found by their IDs
     */
    public Review toEntity(ReviewDTO reviewDTO) {
        Review review = new Review();
        review.setReviewId(reviewDTO.getReviewId());
        review.setRating(reviewDTO.getRating());
        review.setComment(reviewDTO.getComment());
        
        Users customer = usersRepository.findById(reviewDTO.getCustomerId())
                .orElseThrow(() -> new IllegalArgumentException(Constants.USER_NOT_FOUND));
        Vehicle vehicle = vehicleRepository.findById(reviewDTO.getVehicleId())
                .orElseThrow(() -> new IllegalArgumentException(Constants.VEHICLE_NOT_FOUND+reviewDTO.getVehicleId()));

        review.setCustomer(customer);
        review.setVehicle(vehicle);

        return review;
    }
}
