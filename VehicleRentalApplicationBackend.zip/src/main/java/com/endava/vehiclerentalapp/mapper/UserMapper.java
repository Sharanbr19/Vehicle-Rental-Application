package com.endava.vehiclerentalapp.mapper;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import com.endava.vehiclerentalapp.dto.UserDto;
import com.endava.vehiclerentalapp.entity.UserType;
import com.endava.vehiclerentalapp.entity.Users;

/**
 * Mapper class to convert between UserDto and Users entity in the Vehicle Rental Application.
 * 
 * This class provides methods to map data from UserDto objects to Users entities and vice versa. 
 */
@Component
public class UserMapper {

    /**
     * Converts a UserDto object to a Users entity.
     *
     * @param userDto the UserDto object to be converted
     * @param currentAdminEmail the email of the admin performing the operation
     * @return a Users entity populated with data from the UserDto
     */
    public Users toEntity(UserDto userDto, String currentAdminEmail) {
        Users user = new Users();
        user.setName(userDto.getName());
        user.setEmail(userDto.getEmail());
        user.setPassword(userDto.getPassword());
        user.setContactNumber(userDto.getContactNumber());
        user.setAddress(userDto.getAddress());
        user.setGender(userDto.getGender());
        user.setUserType(UserType.valueOf(userDto.getUserType()));
        user.setDateOfBirth(userDto.getDateOfBirth());
        user.setDeleted(false); 
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        user.setCreatedBy(currentAdminEmail);
        user.setUpdatedBy(currentAdminEmail);
        return user;
    }

    /**
     * Converts a Users entity to a UserDto object.
     *
     * @param user the Users entity to be converted
     * @return a UserDto object populated with data from the Users entity
     */
    public UserDto toDto(Users user) {
        UserDto userDto = new UserDto();
        userDto.setName(user.getName());
        userDto.setEmail(user.getEmail());
        userDto.setPassword(user.getPassword());
        userDto.setContactNumber(user.getContactNumber());
        userDto.setAddress(user.getAddress());
        userDto.setGender(user.getGender());
        userDto.setUserType(user.getUserType().name());
        userDto.setDateOfBirth(user.getDateOfBirth());
        userDto.setDeleted(user.isDeleted()); 
        userDto.setCreatedAt(user.getCreatedAt());
        userDto.setUpdatedAt(user.getUpdatedAt());
        userDto.setCreatedBy(user.getCreatedBy());
        userDto.setUpdatedBy(user.getUpdatedBy());
        return userDto;
    }
}
