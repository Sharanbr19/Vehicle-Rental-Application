package com.endava.vehiclerentalapp.mapper;

import com.endava.vehiclerentalapp.dto.VehicleDTO;
import com.endava.vehiclerentalapp.dto.VehicleBookingDateDTO;
import com.endava.vehiclerentalapp.entity.Vehicle;
import com.endava.vehiclerentalapp.entity.VehicleBookingDate;
import com.endava.vehiclerentalapp.entity.Users;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
public class VehicleMapper {

    /**
     * Converts Vehicle entity to VehicleDTO.
     *
     * @param vehicle the Vehicle entity to convert
     * @return VehicleDTO with the data from the Vehicle entity
     */
    public VehicleDTO toDto(Vehicle vehicle) {  
        if (vehicle == null) {
            return null;
        }
        VehicleDTO vehicleDTO = new VehicleDTO();
        vehicleDTO.setVehicleId(vehicle.getVehicleId());
        vehicleDTO.setModelName(vehicle.getModelName());
        vehicleDTO.setRegistrationNumber(vehicle.getRegistrationNumber());
        vehicleDTO.setCategoryType(vehicle.getCategoryType());
        vehicleDTO.setFuelType(vehicle.getFuelType());
        vehicleDTO.setColor(vehicle.getColor());
        vehicleDTO.setModelYear(vehicle.getModelYear());
        vehicleDTO.setPricePerDay(vehicle.getPricePerDay());
        vehicleDTO.setMileage(vehicle.getMileage());
        vehicleDTO.setFeatureDescription(vehicle.getFeatureDescription());
        vehicleDTO.setInsuranceNumber(vehicle.getInsuranceNumber());
        vehicleDTO.setVehicleImageURL(vehicle.getVehicleImageURL());
        List<VehicleBookingDateDTO> bookingDateDTOs = vehicle.getVehicleBookingDates().stream()
                .map(this::toBookingDateDTO)
                .toList();
        vehicleDTO.setVehicleBookingDates(bookingDateDTOs);
        vehicleDTO.setCreatedAt(vehicle.getCreatedAt());
        vehicleDTO.setUpdatedAt(vehicle.getUpdatedAt());
        vehicleDTO.setIsDeleted(vehicle.isDeleted());
        vehicleDTO.setCreatedBy(vehicle.getCreatedBy());
        vehicleDTO.setUpdatedBy(vehicle.getUpdatedBy());

        return vehicleDTO;
    }

    /**
     * Converts VehicleBookingDate entity to VehicleBookingDateDTO.
     *
     * @param bookingDate the VehicleBookingDate entity to convert
     * @return VehicleBookingDateDTO with the data from the VehicleBookingDate entity
     */
    private VehicleBookingDateDTO toBookingDateDTO(VehicleBookingDate bookingDate) {
        if (bookingDate == null) {
            return null;
        }
        VehicleBookingDateDTO bookingDateDTO = new VehicleBookingDateDTO();
        bookingDateDTO.setVehicleBookingDateId(bookingDate.getVehicleBookingDateId());
        bookingDateDTO.setBookedDate(bookingDate.getBookedDate());
        return bookingDateDTO;
    }

    /**
     * Converts VehicleDTO to Vehicle entity.
     *
     * @param vehicleDTO the VehicleDTO to convert
     * @param admin the admin user responsible for the creation
     * @return Vehicle entity with data from the VehicleDTO
     */
    public Vehicle toEntity(VehicleDTO vehicleDTO, Users admin) {
        if (vehicleDTO == null) {
            return null;
        }
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(vehicleDTO.getVehicleId());
        vehicle.setModelName(vehicleDTO.getModelName());
        vehicle.setRegistrationNumber(vehicleDTO.getRegistrationNumber());
        vehicle.setCategoryType(vehicleDTO.getCategoryType());
        vehicle.setFuelType(vehicleDTO.getFuelType());
        vehicle.setColor(vehicleDTO.getColor());
        vehicle.setModelYear(vehicleDTO.getModelYear());
        vehicle.setPricePerDay(vehicleDTO.getPricePerDay());
        vehicle.setMileage(vehicleDTO.getMileage());
        vehicle.setFeatureDescription(vehicleDTO.getFeatureDescription());
        vehicle.setInsuranceNumber(vehicleDTO.getInsuranceNumber());
        vehicle.setVehicleImageURL(vehicleDTO.getVehicleImageURL());
        vehicle.setCreatedAt(vehicleDTO.getCreatedAt());
        vehicle.setUpdatedAt(vehicleDTO.getUpdatedAt());
        vehicle.setDeleted(vehicleDTO.getIsDeleted());
        vehicle.setCreatedBy(vehicleDTO.getCreatedBy() != null ? vehicleDTO.getCreatedBy() : admin.getEmail());  // Set createdBy as admin email
        vehicle.setUpdatedBy(vehicleDTO.getUpdatedBy() != null ? vehicleDTO.getUpdatedBy() : admin.getEmail());  // Set updatedBy as admin email
        return vehicle;
    }
}
