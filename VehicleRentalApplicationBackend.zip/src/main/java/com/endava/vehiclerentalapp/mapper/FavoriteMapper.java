package com.endava.vehiclerentalapp.mapper;

import com.endava.vehiclerentalapp.dto.FavoriteDTO;
import com.endava.vehiclerentalapp.entity.Favorite;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.entity.Vehicle;
import org.springframework.stereotype.Component;

/**
 * Mapper class for converting between Favorite entity and FavoriteDTO.
 */
@Component
public class FavoriteMapper {

    /**
     * Converts a Favorite entity to a FavoriteDTO.
     *
     * @param favorite the Favorite entity
     * @return the corresponding FavoriteDTO
     */
    public FavoriteDTO toDto(Favorite favorite) {
        if (favorite == null) {
            return null;
        }

        FavoriteDTO favoriteDTO = new FavoriteDTO();
        favoriteDTO.setFavoriteId(favorite.getFavoriteId());
        favoriteDTO.setUserId(favorite.getCustomer().getUserId());  
        favoriteDTO.setVehicleId(favorite.getVehicle().getVehicleId());

        return favoriteDTO;
    }

    /**
     * Converts a FavoriteDTO to a Favorite entity.
     *
     * @param favoriteDTO the FavoriteDTO
     * @return the corresponding Favorite entity
     */
    public Favorite toEntity(FavoriteDTO favoriteDTO) {
        if (favoriteDTO == null) {
            return null;
        }

        Favorite favorite = new Favorite();
        favorite.setFavoriteId(favoriteDTO.getFavoriteId());

        Users customer = new Users();
        customer.setUserId(favoriteDTO.getUserId()); 
        favorite.setCustomer(customer);

        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(favoriteDTO.getVehicleId());
        favorite.setVehicle(vehicle);

        return favorite;
    }
}
