package com.endava.vehiclerentalapp.mapper;

import com.endava.vehiclerentalapp.dto.PaymentDTO;
import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.Payment;
import org.springframework.stereotype.Component;

/**
 * Mapper class responsible for converting between Payment entities and PaymentDTOs.
 * This class handles the transformation of Payment data between entity and DTO layers.
 */
@Component
public class PaymentMapper {

    /**
     * Converts a PaymentDTO to its corresponding Payment entity.
     *
     * @param paymentDTO the PaymentDTO to be converted
     * @param booking the associated Booking entity
     * @return a Payment entity populated with data from the PaymentDTO
     */
    public Payment toEntity(PaymentDTO paymentDTO, Booking booking) {
        Payment payment = new Payment();
        payment.setPaymentId(paymentDTO.getPaymentId());
        payment.setAmount(paymentDTO.getAmount());
        payment.setPaymentDateAndTime(paymentDTO.getPaymentDateAndTime());
        payment.setRazorPayId(paymentDTO.getRazorpayId());
        payment.setBooking(booking);
        return payment;
    }

    /**
     * Converts a Payment entity to its corresponding PaymentDTO.
     *
     * @param payment the Payment entity to be converted
     * @return a PaymentDTO containing the payment data
     */
    public PaymentDTO toDTO(Payment payment) {
        PaymentDTO paymentDTO = new PaymentDTO();
        paymentDTO.setPaymentId(payment.getPaymentId());
        paymentDTO.setAmount(payment.getAmount());
        paymentDTO.setPaymentDateAndTime(payment.getPaymentDateAndTime());
        paymentDTO.setRazorpayId(payment.getRazorPayId());
        paymentDTO.setBookingId(payment.getBooking() != null ? payment.getBooking().getBookingId() : null);
        return paymentDTO;
    }
}
