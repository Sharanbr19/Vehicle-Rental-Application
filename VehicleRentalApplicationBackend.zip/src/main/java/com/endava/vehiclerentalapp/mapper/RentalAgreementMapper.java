package com.endava.vehiclerentalapp.mapper;

import com.endava.vehiclerentalapp.dto.RentalAgreementDTO;
import com.endava.vehiclerentalapp.entity.RentalAgreement;
import org.springframework.stereotype.Component;

/**
 * Mapper class responsible for converting between RentalAgreement entities and RentalAgreementDTOs.
 * This class handles the transformation of RentalAgreement data between entity and DTO layers.
 */
@Component
public class RentalAgreementMapper {

    /**
     * Converts a RentalAgreement entity to its corresponding RentalAgreementDTO.
     *
     * @param rentalAgreement the RentalAgreement entity to be converted
     * @return a RentalAgreementDTO containing the rental agreement data
     */
    public RentalAgreementDTO toDTO(RentalAgreement rentalAgreement) {
        RentalAgreementDTO dto = new RentalAgreementDTO();
        dto.setRentalId(rentalAgreement.getRentalId());
        dto.setAgreementDate(rentalAgreement.getAgreementDate());
        dto.setTermsAndConditions(rentalAgreement.getTermsAndConditions());
        dto.setBookingId(rentalAgreement.getBooking().getBookingId());
        return dto;
    }

    /**
     * Converts a RentalAgreementDTO to its corresponding RentalAgreement entity.
     * 
     * @param dto the RentalAgreementDTO to be converted
     * @return a RentalAgreement entity populated with data from the RentalAgreementDTO
     */
    public RentalAgreement toEntity(RentalAgreementDTO dto) {
        RentalAgreement rentalAgreement = new RentalAgreement();
        rentalAgreement.setRentalId(dto.getRentalId());
        rentalAgreement.setAgreementDate(dto.getAgreementDate());
        rentalAgreement.setTermsAndConditions(dto.getTermsAndConditions());
        return rentalAgreement;
    }
}
