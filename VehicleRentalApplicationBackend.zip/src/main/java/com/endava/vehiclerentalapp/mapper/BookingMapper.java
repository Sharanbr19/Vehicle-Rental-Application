package com.endava.vehiclerentalapp.mapper;

import org.springframework.stereotype.Component;

import com.endava.vehiclerentalapp.dto.BookingDTO;
import com.endava.vehiclerentalapp.dto.VehicleDTO;
import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.Driver;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.entity.Vehicle;

/**
 * Utility class to map between Booking entity and BookingDTO data transfer object.
 * Also provides a method to map a Vehicle entity to a VehicleDTO.
 * This class helps in transforming between entities and DTOs for use in service layers,
 * making the interaction between the persistence layer and the API layer easier and cleaner.
 */
@Component
public class BookingMapper {

	/**
     * Maps a Booking entity to a BookingDTO object.
     * This method is typically used to convert a Booking entity retrieved from the database
     * to a form suitable for sending to the client.
     * 
     * @param booking The `Booking` entity to be mapped to a DTO.
     * @return A `BookingDTO` containing the data from the Booking entity.
     */
    public static BookingDTO toDTO(Booking booking) {
        BookingDTO dto = new BookingDTO();
        dto.setBookingId(booking.getBookingId());
        dto.setLocation(booking.getLocation());
        dto.setFromDate(booking.getFromDate());
        dto.setToDate(booking.getToDate());
        dto.setTotalCost(booking.getTotalCost());
        dto.setCustomerAadharNumber(booking.getCustomerAadharNumber());
        dto.setCustomerDrivingLicenseNumber(booking.getCustomerDrivingLicenseNumber());
        dto.setStatus(booking.getStatus());
        dto.setPaymentCompleted(booking.getPaymentCompleted());
        dto.setWantsDriver(booking.getWantsDriver());
        if (booking.getCustomer() != null) {
            dto.setCustomerId(booking.getCustomer().getUserId());
        }
        if (booking.getVehicle() != null) {
            dto.setVehicleId(booking.getVehicle().getVehicleId());
        }
        if (booking.getDriver() != null) {
            dto.setDriverId(booking.getDriver().getDriverId());
        }
        dto.setCreatedAt(booking.getCreatedAt());
        dto.setUpdatedAt(booking.getUpdatedAt());
        return dto;
    }

    /**
     * Maps a BookingDTO object to a Booking entity.
     * This method is typically used to convert data received from the client
     * (in the form of a DTO) into a `Booking` entity suitable for persisting in the database.
     * 
     * @param dto The BookingDTO object containing the data to be mapped to an entity.
     * @param customer The `Users` entity representing the customer who made the booking.
     * @param vehicle The `Vehicle` entity representing the vehicle being booked.
     * @param driver The `Driver` entity representing the driver (optional).
     * @return A `Booking` entity containing the data from the `BookingDTO`.
     */
    public static Booking toEntity(BookingDTO dto, Users customer, Vehicle vehicle, Driver driver) {
        Booking booking = new Booking();
        booking.setBookingId(dto.getBookingId());
        booking.setLocation(dto.getLocation());
        booking.setFromDate(dto.getFromDate());
        booking.setToDate(dto.getToDate());
        booking.setTotalCost(dto.getTotalCost());
        booking.setCustomerAadharNumber(dto.getCustomerAadharNumber());
        booking.setCustomerDrivingLicenseNumber(dto.getCustomerDrivingLicenseNumber());
        booking.setStatus(dto.getStatus());
        booking.setPaymentCompleted(dto.getPaymentCompleted());
        booking.setWantsDriver(dto.getWantsDriver());
        booking.setCustomer(customer);
        booking.setVehicle(vehicle);
        booking.setDriver(driver);
        booking.setCreatedAt(dto.getCreatedAt());
        booking.setUpdatedAt(dto.getUpdatedAt());
        return booking;
    }
    
    /**
     * Maps a Vehicle entity to a VehicleDTO object.
     * This method is used to transform a `Vehicle` entity into a DTO that can be returned
     * to the client, providing necessary vehicle details such as model, registration number, and price.
     * 
     * @param vehicle The `Vehicle` entity to be mapped to a DTO.
     * @return A `VehicleDTO` containing the vehicle's data.
     */
    public static VehicleDTO toVehicleDto(Vehicle vehicle) {  
        if (vehicle == null) {
            return null;
        }
        VehicleDTO vehicleDTO = new VehicleDTO();
        vehicleDTO.setVehicleId(vehicle.getVehicleId());
        vehicleDTO.setModelName(vehicle.getModelName());
        vehicleDTO.setRegistrationNumber(vehicle.getRegistrationNumber());
        vehicleDTO.setCategoryType(vehicle.getCategoryType());
        vehicleDTO.setFuelType(vehicle.getFuelType());
        vehicleDTO.setColor(vehicle.getColor());
        vehicleDTO.setModelYear(vehicle.getModelYear());
        vehicleDTO.setPricePerDay(vehicle.getPricePerDay());
        vehicleDTO.setMileage(vehicle.getMileage());
        vehicleDTO.setFeatureDescription(vehicle.getFeatureDescription());
        vehicleDTO.setInsuranceNumber(vehicle.getInsuranceNumber());
        vehicleDTO.setVehicleImageURL(vehicle.getVehicleImageURL());
        vehicleDTO.setCreatedAt(vehicle.getCreatedAt());
        vehicleDTO.setUpdatedAt(vehicle.getUpdatedAt());
        vehicleDTO.setCreatedBy(vehicle.getCreatedBy());
        vehicleDTO.setUpdatedBy(vehicle.getUpdatedBy());

        return vehicleDTO;
    }
}
