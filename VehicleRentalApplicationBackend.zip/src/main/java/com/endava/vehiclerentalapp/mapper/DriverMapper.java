package com.endava.vehiclerentalapp.mapper;

import com.endava.vehiclerentalapp.dto.DriverDTO;
import com.endava.vehiclerentalapp.dto.DriverBookingDateDTO;
import com.endava.vehiclerentalapp.entity.Driver;
import com.endava.vehiclerentalapp.entity.DriverBookingDate;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
public class DriverMapper {

	/**
     * Converts Driver entity to DriverDTO.
     */
    public DriverDTO toDTO(Driver driver) {
        if (driver == null) {
            return null;
        }
        DriverDTO driverDTO = new DriverDTO();
        driverDTO.setDriverId(driver.getDriverId());
        driverDTO.setName(driver.getName());
        driverDTO.setEmail(driver.getEmail());
        driverDTO.setContactNumber(driver.getContactNumber());
        driverDTO.setLicenseNumber(driver.getLicenseNumber());
        driverDTO.setDriverCostPerDay(driver.getDriverCostPerDay());
        driverDTO.setAdminId(driver.getAdmin() != null ? driver.getAdmin().getUserId() : null);
        driverDTO.setCreatedAt(driver.getCreatedAt());
        driverDTO.setUpdatedAt(driver.getUpdatedAt());
        driverDTO.setCreatedBy(driver.getCreatedBy());
        driverDTO.setUpdatedBy(driver.getUpdatedBy());
        driverDTO.setIsDeleted(driver.getIsDeleted());

        if (driver.getDriverBookingDates() != null) {
            driverDTO.setDriverBookingDates(driver.getDriverBookingDates().stream()
                    .map(DriverBookingDate::getBookingDate)
                    .toList());
        }

        return driverDTO;
    }


    /**
     * Converts DriverDTO to Driver entity.
     */
    public Driver toEntity(DriverDTO driverDTO) {
        if (driverDTO == null) {
            return null;
        }
        Driver driver = new Driver();
        driver.setDriverId(driverDTO.getDriverId());
        driver.setName(driverDTO.getName());
        driver.setLicenseNumber(driverDTO.getLicenseNumber());
        driver.setEmail(driverDTO.getEmail());
        driver.setContactNumber(driverDTO.getContactNumber());
        driver.setDriverCostPerDay(driverDTO.getDriverCostPerDay());
        driver.setCreatedAt(driverDTO.getCreatedAt());
        driver.setUpdatedAt(driverDTO.getUpdatedAt());
        driver.setCreatedBy(driverDTO.getCreatedBy());
        driver.setUpdatedBy(driverDTO.getUpdatedBy());
        driver.setIsDeleted(driverDTO.getIsDeleted());

        if (driverDTO.getDriverBookingDates() != null) {
            List<DriverBookingDate> bookingDates = driverDTO.getDriverBookingDates().stream()
                    .map(date -> {
                        DriverBookingDate driverBookingDate = new DriverBookingDate();
                        driverBookingDate.setBookingDate(date);
                        driverBookingDate.setDriver(driver);
                        return driverBookingDate;
                    })
                    .toList();
            driver.setDriverBookingDates(bookingDates);
        }

        return driver;
    }


    /**
     * Converts DriverBookingDate entity to DriverBookingDateDTO.
     */
    public DriverBookingDateDTO toDTO(DriverBookingDate driverBookingDate) {
        if (driverBookingDate == null) {
            return null;
        }
        DriverBookingDateDTO driverBookingDateDTO = new DriverBookingDateDTO();
        driverBookingDateDTO.setDriverBookingDateId(driverBookingDate.getId());
        driverBookingDateDTO.setBookedDate(driverBookingDate.getBookingDate());
        driverBookingDateDTO.setDriverId(driverBookingDate.getDriver().getDriverId());
        return driverBookingDateDTO;
    }

    /**
     * Converts DriverBookingDateDTO to DriverBookingDate entity.
     * This method now fetches Driver and Booking entities from DTO.
     */
    public DriverBookingDate toEntity(DriverBookingDateDTO driverBookingDateDTO) {
        if (driverBookingDateDTO == null) {
            return null;
        }
        DriverBookingDate driverBookingDate = new DriverBookingDate();
        driverBookingDate.setBookingDate(driverBookingDateDTO.getBookedDate());
        Driver driver = new Driver();
        driver.setDriverId(driverBookingDateDTO.getDriverId()); 
        driverBookingDate.setDriver(driver);
        return driverBookingDate;
    }

}
