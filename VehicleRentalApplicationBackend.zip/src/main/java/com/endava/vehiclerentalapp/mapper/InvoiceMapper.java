package com.endava.vehiclerentalapp.mapper;

import com.endava.vehiclerentalapp.dto.InvoiceDTO;
import com.endava.vehiclerentalapp.entity.Invoice;
import com.endava.vehiclerentalapp.entity.Booking;
import org.springframework.stereotype.Component;

/**
 * Mapper class responsible for converting between Invoice entities and InvoiceDTOs.
 * This class handles the transformation of Invoice data between entity and DTO layers.
 */
@Component
public class InvoiceMapper {

    /**
     * Converts an Invoice entity to its corresponding InvoiceDTO.
     *
     * @param invoice the Invoice entity to be converted
     * @return an InvoiceDTO containing the invoice data
     */
    public InvoiceDTO toDTO(Invoice invoice) {
        InvoiceDTO dto = new InvoiceDTO();
        dto.setInvoiceId(invoice.getInvoiceId());
        dto.setInvoiceDate(invoice.getInvoiceDate());
        dto.setTotalAmount(invoice.getTotalAmount());

        if (invoice.getBooking() != null) {
            dto.setBookingId(invoice.getBooking().getBookingId());
        }

        return dto;
    }

    /**
     * Converts an InvoiceDTO to its corresponding Invoice entity.
     *
     * @param dto the InvoiceDTO to be converted
     * @param booking the associated Booking entity
     * @return an Invoice entity populated with data from the InvoiceDTO
     */
    public Invoice toEntity(InvoiceDTO dto, Booking booking) {
        Invoice invoice = new Invoice();
        invoice.setInvoiceId(dto.getInvoiceId());
        invoice.setInvoiceDate(dto.getInvoiceDate());
        invoice.setTotalAmount(dto.getTotalAmount());
        invoice.setBooking(booking);

        return invoice;
    }
}
