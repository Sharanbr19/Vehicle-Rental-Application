package com.endava.vehiclerentalapp.mapper;

import com.endava.vehiclerentalapp.dto.DiscountDTO;
import com.endava.vehiclerentalapp.entity.Discount;
import com.endava.vehiclerentalapp.entity.Vehicle;
import org.springframework.stereotype.Component;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class DiscountMapper {

    public DiscountDTO toDTO(Discount discount) {
        DiscountDTO dto = new DiscountDTO();
        dto.setDiscountId(discount.getDiscountId());
        dto.setDiscountPercentage(discount.getDiscountPercentage());
        dto.setCategoryType(discount.getCategoryType());
        dto.setStartDate(discount.getStartDate());
        dto.setEndDate(discount.getEndDate());

        if (discount.getVehicles() != null) {
            dto.setVehicleIds(discount.getVehicles().stream()
                    .map(Vehicle::getVehicleId)
                    .collect(Collectors.toSet()));
        }
        return dto;
    }

    public Discount toEntity(DiscountDTO dto, Set<Vehicle> vehicles) {
        Discount discount = new Discount();
        discount.setDiscountId(dto.getDiscountId());
        discount.setDiscountPercentage(dto.getDiscountPercentage());
        discount.setCategoryType(dto.getCategoryType());
        discount.setStartDate(dto.getStartDate());
        discount.setEndDate(dto.getEndDate());
        discount.setVehicles(vehicles);
        return discount;
    }
}
