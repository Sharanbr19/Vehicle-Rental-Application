package com.endava.vehiclerentalapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *  Contains main method to run the Vehicle Rental Application
 *  
 *  @author Sharan Bangaradka Raja
 */
@SpringBootApplication
public class VehicleRentalApplication  {

	/**
	 * Launches the application
	 * 
	 * @param args - Application startup arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(VehicleRentalApplication.class, args);
	}
}
