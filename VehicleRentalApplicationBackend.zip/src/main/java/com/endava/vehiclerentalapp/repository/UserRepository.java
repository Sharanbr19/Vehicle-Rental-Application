package com.endava.vehiclerentalapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.endava.vehiclerentalapp.entity.UserType;
import com.endava.vehiclerentalapp.entity.Users;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for performing CRUD operations on the Users entity in the Vehicle Rental Application.
 * 
 * This interface extends JpaRepository, providing built-in methods to manage Users in the database, 
 * such as saving, deleting, and querying Users by various criteria.
 * Custom query methods to find Users by email and user ID are also defined here.
 */
public interface UserRepository extends JpaRepository<Users, Long> {
	Optional<Users> findByEmail(String email);
	Optional<Users> findByUserId(long userId);
	List<Users> findByIsDeletedFalse();
	long countByUserTypeAndIsDeletedFalse(UserType userType);
}