package com.endava.vehiclerentalapp.repository;

import com.endava.vehiclerentalapp.entity.Favorite;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.entity.Vehicle;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for performing CRUD operations on the Favorite entity.
 */
@Repository
public interface FavoriteRepository extends JpaRepository<Favorite, Long> {
    Optional<Favorite> findByCustomer_UserIdAndVehicle_VehicleId(Long userId, Long vehicleId);
    List<Favorite> findByCustomer(Users customer);
    boolean existsByCustomerAndVehicle(Users customer, Vehicle vehicle);

}
