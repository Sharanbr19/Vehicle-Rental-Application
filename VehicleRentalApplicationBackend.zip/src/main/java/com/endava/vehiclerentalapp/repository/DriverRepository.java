package com.endava.vehiclerentalapp.repository;

import com.endava.vehiclerentalapp.entity.Driver;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DriverRepository extends JpaRepository<Driver, Long> {

	@Query("""
		    SELECT d FROM Driver d 
		    WHERE d.isDeleted = false 
		      AND d.driverId NOT IN (
		        SELECT dbd.driver.driverId FROM DriverBookingDate dbd 
		        WHERE dbd.bookingDate BETWEEN :fromDate AND :toDate
		      )
		    """)
	List<Driver> findAvailableDrivers(LocalDate fromDate, LocalDate toDate);

	long countByIsDeletedFalse();
}
