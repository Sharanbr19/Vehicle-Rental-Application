package com.endava.vehiclerentalapp.repository;

import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.BookingStatus;
import com.endava.vehiclerentalapp.entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

/**
 * Repository interface for performing CRUD operations on the Booking entity.
 * This interface also contains custom queries to retrieve bookings and
 * available vehicles based on date ranges, providing methods for checking
 * vehicle availability during specific periods.
 * 
 * The methods in this repository are used by service classes to interact with
 * the Booking data in the database, and the custom queries help filter the
 * bookings based on specific criteria, such as vehicle availability and date
 * range.
 */
@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

	@Query("""
		    SELECT b FROM Booking b WHERE b.vehicle.vehicleId = :vehicleId 
		      AND b.fromDate <= :toDate AND b.toDate >= :fromDate
			""")
	List<Booking> findBookingsByVehicleAndDateRange(Long vehicleId, LocalDate fromDate, LocalDate toDate);

	@Query("SELECT b.vehicle FROM Booking b WHERE b.fromDate <= :toDate AND b.toDate >= :fromDate")
	List<Vehicle> findAvailableVehiclesBetweenDates(LocalDate fromDate, LocalDate toDate);

	List<Booking> findByCustomer_UserId(Long customerId);

	@Query("SELECT SUM(b.totalCost) FROM Booking b WHERE b.paymentCompleted = true")
	long getTotalEarnings();

	@Query("SELECT b.vehicle.categoryType, SUM(b.totalCost) FROM Booking b WHERE b.paymentCompleted = true GROUP BY b.vehicle.categoryType")
	List<Object[]> getEarningsByCategoryType();

	@Query("SELECT b.vehicle.categoryType, COUNT(b) FROM Booking b WHERE b.paymentCompleted = true GROUP BY b.vehicle.categoryType")
	List<Object[]> getBookingCountByCategoryType();

	long countByStatus(BookingStatus confirmed);

	boolean existsByVehicle_VehicleIdAndToDateAfter(Long vehicleId, LocalDate now);

	boolean existsByDriver_DriverIdAndToDateAfter(Long driverId, LocalDate now);

	@Query("""
			SELECT COUNT(b) FROM Booking b
			WHERE b.vehicle.vehicleId = :vehicleId
			  AND (:fromDate < b.toDate AND :toDate > b.fromDate)
			  AND b.status != 'CANCELLED'
			""")
	Long countOverlappingBookings(@Param("vehicleId") Long vehicleId, @Param("fromDate") LocalDate fromDate,
			@Param("toDate") LocalDate toDate);

	@Query("""
			SELECT COUNT(b) FROM Booking b
			WHERE b.driver.driverId = :driverId
			  AND (:fromDate < b.toDate AND :toDate > b.fromDate)
			  AND b.status != 'CANCELLED'
			""")
	Long countOverlappingDriverBookings(@Param("driverId") Long driverId, @Param("fromDate") LocalDate fromDate,
			@Param("toDate") LocalDate toDate);

}
