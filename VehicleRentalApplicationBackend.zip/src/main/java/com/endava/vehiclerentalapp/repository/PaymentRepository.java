package com.endava.vehiclerentalapp.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.endava.vehiclerentalapp.entity.Payment;

/**
 * Repository interface for managing Payment entities.
 * Provides methods to perform CRUD operations and custom queries for payments.
 */
public interface PaymentRepository extends JpaRepository<Payment, Long>{
	Optional<Payment> findByPaymentId(Long id);
}
