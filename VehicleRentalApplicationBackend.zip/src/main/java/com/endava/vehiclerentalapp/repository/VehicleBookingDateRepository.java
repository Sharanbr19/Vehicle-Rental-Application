package com.endava.vehiclerentalapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.endava.vehiclerentalapp.entity.VehicleBookingDate;

/**
 * Repository interface for managing vehicle booking dates.
 * Provides methods for CRUD operations on VehicleBookingDate entities.
 */
@Repository
public interface VehicleBookingDateRepository extends JpaRepository<VehicleBookingDate, Long> {
    void deleteByVehicle_VehicleIdAndBooking_BookingId(Long vehicleId, Long bookingId);
}

