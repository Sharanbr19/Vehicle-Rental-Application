package com.endava.vehiclerentalapp.repository;

import com.endava.vehiclerentalapp.entity.RentalAgreement;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for RentalAgreement entity.
 */
@Repository
public interface RentalAgreementRepository extends JpaRepository<RentalAgreement, Long> {
	List<RentalAgreement> findByBooking_Customer_UserId(Long customerId);
}
