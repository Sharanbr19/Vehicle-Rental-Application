package com.endava.vehiclerentalapp.repository;

import com.endava.vehiclerentalapp.entity.Invoice;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for managing Invoice entities.
 * Provides methods to perform CRUD operations and custom queries related to invoices.
 */
@Repository
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
	List<Invoice> findByBooking_Customer_UserId(Long customerId);
}
