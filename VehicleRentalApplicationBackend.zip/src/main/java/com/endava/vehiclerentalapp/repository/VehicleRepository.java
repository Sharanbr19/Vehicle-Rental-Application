package com.endava.vehiclerentalapp.repository;

import com.endava.vehiclerentalapp.entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for performing CRUD operations on the Vehicle entity in the Vehicle Rental Application.
 *
 * This interface extends JpaRepository, providing built-in methods to manage vehicles in the database,
 * such as saving, deleting, and querying vehicles by various criteria.
 * Custom query methods to find vehicles by registration number, model name, and availability status are defined here.
 */
@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
    Optional<Vehicle> findByRegistrationNumber(String registrationNumber);
    List<Vehicle> findByModelNameIgnoreCase(String modelName);
	long countByIsDeletedFalse();
	List<Vehicle> findByIsDeletedFalse();
	List<Vehicle> findByCategoryType(String categoryType);
}

