package com.endava.vehiclerentalapp.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.endava.vehiclerentalapp.entity.Discount;
import com.endava.vehiclerentalapp.entity.Vehicle;

@Repository
public interface DiscountRepository extends JpaRepository<Discount, Long> {

	List<Vehicle> findByCategoryType(String categoryType);

	List<Discount> findByVehicles_VehicleId(Long vehicleId);

	@Query("""
		    SELECT d FROM Discount d JOIN d.vehicles v 
		    WHERE v.vehicleId = :vehicleId 
		    AND CURRENT_DATE BETWEEN d.startDate AND d.endDate 
		    ORDER BY d.discountPercentage DESC 
		    LIMIT 1
		    """)
	Optional<Discount> findHighestDiscountForVehicle(@Param("vehicleId") Long vehicleId);

	@Modifying
	@Query("DELETE FROM Discount d WHERE d.endDate < CURRENT_DATE")
	void deleteExpiredDiscounts();

}
