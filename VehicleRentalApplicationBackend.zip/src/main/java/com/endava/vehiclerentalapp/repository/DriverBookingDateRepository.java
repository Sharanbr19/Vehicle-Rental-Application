package com.endava.vehiclerentalapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.endava.vehiclerentalapp.entity.DriverBookingDate;

@Repository
public interface DriverBookingDateRepository extends JpaRepository<DriverBookingDate, Long> {

	void deleteByBooking_BookingId(Long bookingId);

	void deleteByDriver_DriverIdAndBooking_BookingId(Long driverId, Long bookingId);
}