package com.endava.vehiclerentalapp.repository;

import com.endava.vehiclerentalapp.entity.Review;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for managing Review entities.
 * Provides methods to perform CRUD operations and custom queries for reviews.
 */
@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
	List<Review> findByVehicle_VehicleId(Long vehicleId);
    List<Review> findByCustomer_UserId(Long customerId); 
    
    Optional<Review> findByCustomer_UserIdAndVehicle_VehicleId(Long userId, Long vehicleId); 

    @Query("SELECT AVG(CAST(r.rating AS double)) FROM Review r WHERE r.vehicle.vehicleId = :vehicleId")
    Double findAverageRatingByVehicleId(Long vehicleId);
	
    boolean existsByCustomer_UserIdAndVehicle_VehicleId(Long customerId, Long vehicleId);
}
