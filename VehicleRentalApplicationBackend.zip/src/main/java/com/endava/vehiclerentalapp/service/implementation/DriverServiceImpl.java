package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.DriverDTO;
import com.endava.vehiclerentalapp.entity.Driver;
import com.endava.vehiclerentalapp.exceptions.DriverNotFoundException;
import com.endava.vehiclerentalapp.mapper.DriverMapper;
import com.endava.vehiclerentalapp.repository.BookingRepository;
import com.endava.vehiclerentalapp.repository.DriverRepository;
import com.endava.vehiclerentalapp.service.DriverService;
import com.endava.vehiclerentalapp.util.Constants;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

/**
 * Service implementation for managing drivers.
 * Provides methods to create, read, update, and delete driver records.
 */
@Service
public class DriverServiceImpl implements DriverService {

    private final DriverRepository driverRepository;
    private final DriverMapper driverMapper;
    private final BookingRepository bookingRepository;

    /**
     * Constructor for DriverServiceImpl.
     * 
     * @param driverRepository the repository for interacting with the driver data.
     * @param driverMapper the mapper for converting between DriverDTO and Driver entities.
     */
    public DriverServiceImpl(DriverRepository driverRepository, DriverMapper driverMapper, BookingRepository bookingRepository) {
        this.driverRepository = driverRepository;
        this.driverMapper = driverMapper;
        this.bookingRepository = bookingRepository;
    }

    /**
     * Creates a new driver and saves it to the repository.
     * 
     * @param driverDTO the data transfer object containing the driver details.
     * @return the created DriverDTO.
     */
    @Override
    public DriverDTO createDriver(DriverDTO driverDTO) {
        Driver driver = driverMapper.toEntity(driverDTO);
        driver.setIsDeleted(false);
        Driver savedDriver = driverRepository.save(driver);
        return driverMapper.toDTO(savedDriver);
    }

    /**
     * Retrieves a driver by its ID.
     * 
     * @param driverId the ID of the driver to retrieve.
     * @return the DriverDTO for the requested driver.
     * @throws DriverNotFoundException if the driver with the given ID is not found.
     */
    @Override
    public DriverDTO getDriverById(Long driverId) {
        Driver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new DriverNotFoundException(Constants.DRIVER_NOT_FOUND + driverId));
        return driverMapper.toDTO(driver);
    }

    /**
     * Retrieves all drivers, excluding soft-deleted ones.
     * 
     * @return a list of DriverDTOs representing all active drivers.
     */
    @Override
    public List<DriverDTO> getAllDrivers() {
        return driverRepository.findAll().stream()
                .map(driverMapper::toDTO)
                .filter(d -> !d.getIsDeleted()) 
                .toList();
    }

    /**
     * Updates an existing driver's details.
     * 
     * @param driverId the ID of the driver to update.
     * @param driverDTO the data transfer object containing the new driver details.
     * @return the updated DriverDTO.
     * @throws DriverNotFoundException if the driver with the given ID is not found.
     */
    @Override
    public DriverDTO updateDriver(Long driverId, DriverDTO driverDTO) {
        Driver existingDriver = driverRepository.findById(driverId)
                .orElseThrow(() -> new DriverNotFoundException(Constants.DRIVER_NOT_FOUND + driverId));
        
        existingDriver.setName(driverDTO.getName());
        existingDriver.setLicenseNumber(driverDTO.getLicenseNumber());
        existingDriver.setDriverCostPerDay(driverDTO.getDriverCostPerDay());
        existingDriver.setIsDeleted(false);
        existingDriver.setContactNumber(driverDTO.getContactNumber());
        
        Driver updatedDriver = driverRepository.save(existingDriver);
        return driverMapper.toDTO(updatedDriver);
    }

    /**
     * Soft deletes a driver by marking it as deleted.
     * 
     * @param driverId the ID of the driver to delete.
     * @throws DriverNotFoundException if the driver with the given ID is not found.
     */
    @Override
    public void deleteDriver(Long driverId) {
        Driver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new DriverNotFoundException(Constants.DRIVER_NOT_FOUND + driverId));
        if (bookingRepository.existsByDriver_DriverIdAndToDateAfter(driverId, LocalDate.now())) {
            throw new IllegalStateException(Constants.CANNOT_DELETE_DRIVER);
        }
        driver.setIsDeleted(true);
        driverRepository.save(driver); 
    }

    /**
     * Retrieves the total count of active (non-deleted) drivers.
     *
     * @return the number of drivers who are not marked as deleted.
     */
    @Override
    public long getTotalDrivers() {
        return driverRepository.countByIsDeletedFalse();
    }

}
