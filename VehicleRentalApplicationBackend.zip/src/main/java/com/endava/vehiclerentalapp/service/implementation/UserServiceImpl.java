package com.endava.vehiclerentalapp.service.implementation;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.endava.vehiclerentalapp.dto.UserDto;
import com.endava.vehiclerentalapp.entity.UserType;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.mapper.UserMapper;
import com.endava.vehiclerentalapp.repository.UserRepository;
import com.endava.vehiclerentalapp.service.UserService;
import com.endava.vehiclerentalapp.util.Constants;
import com.endava.vehiclerentalapp.util.OtpEntry;
import com.endava.vehiclerentalapp.util.jwtTokenUtil;

import jakarta.mail.MessagingException;

/**
 * Implementation of the {@link UserService} interface.
 * 
 * This class provides functionality for managing user-related operations,
 * including registration, login, OTP generation/validation, and password
 * updates.
 */
@Service
public class UserServiceImpl implements UserService {

	private final UserRepository userRepository;

	private final UserMapper userMapper;

	private final BCryptPasswordEncoder passwordEncoder;

	private final MailService mailService;

	public UserServiceImpl(UserRepository userRepository, UserMapper userMapper, BCryptPasswordEncoder passwordEncoder,
			MailService mailService) {
		this.userRepository = userRepository;
		this.userMapper = userMapper;
		this.passwordEncoder = passwordEncoder;
		this.mailService = mailService;
	}

	private Map<String, OtpEntry> otpCache = new HashMap<>();

	private final Random random = new Random();

	/**
	 * Checks if a user exists in the system by their email.
	 *
	 * @param email the email to check
	 * @return true if a user with the given email exists, false otherwise
	 */
	@Override
	public boolean checkIfUserExistsByEmail(String email) {
		Optional<Users> userOptional = userRepository.findByEmail(email);
		return userOptional.isPresent();
	}

	/**
	 * Registers a new user in the system.
	 * 
	 * Converts the {@link UserDto} to a {@link Users} entity, encodes the password,
	 * and saves the user in the database.
	 *
	 * @param userDto           the user data transfer object containing
	 *                          registration details
	 * @param currentAdminEmail the email of the admin performing the operation
	 */
	@Override
	public void registerUser(UserDto userDto, String currentAdminEmail) {
		Users user = userMapper.toEntity(userDto, currentAdminEmail);
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		userRepository.save(user);
	}

	/**
	 * Logs in a user by validating their email and password.
	 * 
	 * If the login is successful, generates and returns a JWT token.
	 *
	 * @param email    the user's email
	 * @param password the user's password
	 * @return an {@link Optional} containing the JWT token if login is successful,
	 *         or an empty {@link Optional} otherwise
	 */
	@Override
	public Optional<String> loginUser(String email, String password) {
		Optional<Users> userOptional = userRepository.findByEmail(email);
		if (userOptional.isPresent()) {
			Users user = userOptional.get();
			if (user.isDeleted() == false && passwordEncoder.matches(password, user.getPassword())) {
				String token = jwtTokenUtil.generateToken(user.getEmail(), user.getUserType().name());
				return Optional.of(token);
			}
		}
		return Optional.empty();
	}

	/**
	 * Saves an OTP for a user in the OTP cache.
	 * 
	 * The OTP is stored along with its expiration time.
	 *
	 * @param email the email of the user
	 * @param otp   the OTP to save
	 */
	@Override
	public void saveOtp(String email, String otp) {
		LocalDateTime expirationTime = LocalDateTime.now().plusMinutes(5);
		otpCache.put(email, new OtpEntry(otp, expirationTime));
	}

	/**
	 * Validates an OTP for a user.
	 * 
	 * Checks if the OTP is correct and not expired. Removes expired OTPs from the
	 * cache.
	 *
	 * @param email the email of the user
	 * @param otp   the OTP to validate
	 * @return true if the OTP is valid, false otherwise
	 */
	@Override
	public boolean validateOtp(String email, String otp) {
		OtpEntry storedOtpEntry = otpCache.get(email);
		if (storedOtpEntry != null) {
			if (storedOtpEntry.isExpired()) {
				otpCache.remove(email);
				return false;
			}
			return storedOtpEntry.getOtp().equals(otp);
		}
		return false;
	}

	/**
	 * Updates a user's password.
	 * 
	 * Encodes the new password and saves it in the database.
	 *
	 * @param email       the email of the user
	 * @param newPassword the new password to set
	 */
	@Override
	public void updatePassword(String email, String newPassword) {
		Optional<Users> userOptional = userRepository.findByEmail(email);
		if (userOptional.isPresent()) {
			Users user = userOptional.get();
			user.setPassword(passwordEncoder.encode(newPassword));
			userRepository.save(user);
		}
	}

	/**
	 * Retrieves a user by their ID.
	 * 
	 * @param userId the ID of the user to retrieve
	 * @return an {@link Optional} containing the user if found, or empty otherwise
	 */
	@Override
	public Optional<Users> getUserById(Long userId) {
		return userRepository.findById(userId);
	}

	/**
	 * Retrieves a user by their email.
	 * 
	 * @param email the email of the user to retrieve
	 * @return an {@link Optional} containing the user if found, or empty otherwise
	 */
	@Override
	public Optional<Users> getUserByEmail(String email) {
		return userRepository.findByEmail(email);
	}

	/**
	 * Retrieves all users in the system who are not marked as deleted.
	 * 
	 * @return a list of all users
	 */
	@Override
	public List<Users> getAllUsers() {
		return userRepository.findByIsDeletedFalse();
	}

	/**
	 * Updates the details of an existing user.
	 * 
	 * Updates user attributes such as name, email, password, contact number, and
	 * address.
	 *
	 * @param userId            the ID of the user to update
	 * @param userDto           the updated user details
	 * @param currentAdminEmail the email of the admin performing the update
	 */
	@Override
	public void updateUser(Long userId, UserDto userDto, String currentAdminEmail) {
		Optional<Users> userOptional = userRepository.findById(userId);
		if (userOptional.isPresent()) {
			Users user = userOptional.get();
			user.setName(userDto.getName());
			user.setEmail(userDto.getEmail());
			user.setContactNumber(userDto.getContactNumber());
			user.setAddress(userDto.getAddress());
			user.setGender(userDto.getGender());
			user.setUserType(UserType.valueOf(userDto.getUserType()));
			user.setDateOfBirth(userDto.getDateOfBirth());
			user.setUpdatedBy(currentAdminEmail);
			user.setUpdatedAt(LocalDateTime.now());
			userRepository.save(user);
		}
	}

	/**
	 * Updates the profile information of a user.
	 * 
	 * This method retrieves a user by their ID, updates the user's profile with the
	 * provided data from the {@link UserDto} object, and saves the updated
	 * information back to the repository. The updated information includes the
	 * user's name, email, password (encoded), contact number, address, gender, user
	 * type, and date of birth. Additionally, the `updatedBy` field is set to the
	 * email of the current admin making the changes, and the `updatedAt` field is
	 * set to the current timestamp.
	 * 
	 * @param userId            The ID of the user whose profile is to be updated.
	 * @param userDto           The DTO containing the updated profile information.
	 * @param currentAdminEmail The email of the current admin making the changes.
	 * @throws UserNotFoundException If the user with the specified ID is not found.
	 */
	@Override
	public void updateProfile(Long userId, UserDto userDto, String currentAdminEmail) {
		Optional<Users> userOptional = userRepository.findById(userId);
		if (userOptional.isPresent()) {
			Users user = userOptional.get();
			user.setName(userDto.getName());
			user.setEmail(userDto.getEmail());
			if (userDto.getPassword() != null && !userDto.getPassword().isEmpty()) {
				String encodedPassword = passwordEncoder.encode(userDto.getPassword());
				user.setPassword(encodedPassword);
			}
			user.setContactNumber(userDto.getContactNumber());
			user.setAddress(userDto.getAddress());
			user.setGender(userDto.getGender());
			user.setUserType(UserType.valueOf(userDto.getUserType()));
			user.setDateOfBirth(userDto.getDateOfBirth());
			user.setUpdatedBy(currentAdminEmail);
			user.setUpdatedAt(LocalDateTime.now());
			userRepository.save(user);
		}
	}

	/**
	 * Marks a user as deleted in the system.
	 * 
	 * Updates the user's status to indicate they are deleted without removing their
	 * record from the database.
	 *
	 * @param userId            the ID of the user to delete
	 * @param currentAdminEmail the email of the admin performing the deletion
	 */
	@Override
	public void deleteUser(Long userId, String currentAdminEmail) {
		Optional<Users> userOptional = userRepository.findById(userId);
		if (userOptional.isPresent()) {
			Users user = userOptional.get();
			user.setDeleted(true);
			user.setUpdatedBy(currentAdminEmail);
			user.setUpdatedAt(LocalDateTime.now());
			userRepository.save(user);
		}
	}

	/**
	 * Retrieves the total number of customers in the system.
	 * 
	 * This method counts the number of users whose user type is {@link UserType
	 * #CUSTOMER} and whose record is not marked as deleted (i.e., {@code isDeleted}
	 * is false). The count is returned as a long value.
	 * 
	 * @return The total number of customers who are not marked as deleted.
	 */
	@Override
	public long getTotalCustomers() {
		return userRepository.countByUserTypeAndIsDeletedFalse(UserType.CUSTOMER);
	}

	/**
	 * Sends an OTP to the provided email address for verification.
	 * 
	 * @param email the email address to send the OTP to.
	 * @return a message indicating whether the OTP was sent successfully.
	 */
	@Override
	public String sendOtpToEmail(String email) {
		boolean userExists = checkIfUserExistsByEmail(email);
		if (userExists) {
			return Constants.EMAIL_ALREADY_TAKEN;
		}
		String otp = generateOtp();
		String subject = Constants.EMAIL_VERIFICATION_OTP;
		String content = Constants.OTP_EMAIL_TEMPLATE.replace("{otp}", otp);
		try {
			mailService.sendHtmlEmail(email, subject, content);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		saveOtp(email, otp);
		return Constants.OTP_SENT_SUCCESSFULLY;
	}

	/**
	 * Verifies the OTP entered by the user.
	 * 
	 * @param email the email address of the user.
	 * @param otp   the OTP to validate.
	 * @return true if the OTP is valid, false otherwise.
	 */
	@Override
	public boolean verifyOtp(String email, String otp) {
		return validateOtp(email, otp);
	}

	/**
	 * Generates a 6-digit One-Time Password (OTP).
	 * 
	 * This method generates a random integer between 100000 and 999999 (inclusive)
	 * using the {@link Random} class, ensuring that the OTP is always a 6-digit
	 * number.
	 * 
	 * @return A randomly generated 6-digit OTP as a {@code String}.
	 */
	private String generateOtp() {
		int otp = 100000 + random.nextInt(900000);
		return String.valueOf(otp);
	}

}