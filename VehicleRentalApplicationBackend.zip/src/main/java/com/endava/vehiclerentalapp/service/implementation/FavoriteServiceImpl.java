package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.FavoriteDTO;
import com.endava.vehiclerentalapp.entity.Favorite;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.entity.Vehicle;
import com.endava.vehiclerentalapp.exceptions.CustomerNotFoundException;
import com.endava.vehiclerentalapp.exceptions.FavoriteAlreadyExistsException;
import com.endava.vehiclerentalapp.exceptions.FavoriteNotFoundException;
import com.endava.vehiclerentalapp.exceptions.VehicleNotFoundException;
import com.endava.vehiclerentalapp.mapper.FavoriteMapper;
import com.endava.vehiclerentalapp.repository.FavoriteRepository;
import com.endava.vehiclerentalapp.repository.UserRepository;
import com.endava.vehiclerentalapp.repository.VehicleRepository;
import com.endava.vehiclerentalapp.service.FavoriteService;
import com.endava.vehiclerentalapp.util.Constants;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Implementation of the {@link FavoriteService} interface.
 * 
 * Provides functionality to manage user favorite vehicles, including
 * adding, removing, and fetching favorite vehicles for a specific user.
 */
@Service
public class FavoriteServiceImpl implements FavoriteService {

    private FavoriteRepository favoriteRepository;

    private UserRepository usersRepository;

    private VehicleRepository vehicleRepository;

    private FavoriteMapper favoriteMapper;

    public FavoriteServiceImpl(FavoriteRepository favoriteRepository, UserRepository usersRepository,
			VehicleRepository vehicleRepository, FavoriteMapper favoriteMapper) {
		this.favoriteRepository = favoriteRepository;
		this.usersRepository = usersRepository;
		this.vehicleRepository = vehicleRepository;
		this.favoriteMapper = favoriteMapper;
	}

	/**
     * Adds a vehicle to the user's favorites.
     *
     * @param favoriteDTO the DTO containing the user ID and vehicle ID to be added to favorites
     * @return the created {@link FavoriteDTO} object
     * @throws CustomerNotFoundException if the user with the given ID does not exist
     * @throws VehicleNotFoundException if the vehicle with the given ID does not exist
     * @throws FavoriteAlreadyExistsException if the favorite already exists for the given user and vehicle
     */
    @Override
    public FavoriteDTO addFavorite(FavoriteDTO favoriteDTO) {
        Users customer = usersRepository.findById(favoriteDTO.getUserId())
                .orElseThrow(() -> new CustomerNotFoundException(Constants.USER_NOT_FOUND + favoriteDTO.getUserId()));
        Vehicle vehicle = vehicleRepository.findById(favoriteDTO.getVehicleId())
                .orElseThrow(() -> new VehicleNotFoundException(Constants.VEHICLE_NOT_FOUND + favoriteDTO.getVehicleId()));
        boolean exists = favoriteRepository.existsByCustomerAndVehicle(customer, vehicle);
        if (exists) {
            throw new FavoriteAlreadyExistsException(Constants.FAVORITE_ALREADY_EXIST + favoriteDTO.getUserId() +
                    " and Vehicle ID: " + favoriteDTO.getVehicleId());
        }
        Favorite favorite = new Favorite();
        favorite.setCustomer(customer);
        favorite.setVehicle(vehicle);

        Favorite savedFavorite = favoriteRepository.save(favorite);
        return favoriteMapper.toDto(savedFavorite);
    }

    /**
     * Removes a vehicle from the user's favorites.
     *
     * @param userId    the ID of the user
     * @param vehicleId the ID of the vehicle to be removed from favorites
     * @throws FavoriteNotFoundException if the favorite does not exist for the given user and vehicle
     */
    @Override
    public void removeFavorite(Long userId, Long vehicleId) {
        Favorite favorite = favoriteRepository.findByCustomer_UserIdAndVehicle_VehicleId(userId, vehicleId)
                .orElseThrow(() -> new FavoriteNotFoundException(Constants.FAVORITE_NOT_FOUND + userId + " and Vehicle ID: " + vehicleId));

        favoriteRepository.delete(favorite);
    }

    /**
     * Retrieves a list of all vehicles in the user's favorites.
     *
     * @param customerId the ID of the user
     * @return a list of {@link FavoriteDTO} objects representing the user's favorite vehicles
     * @throws CustomerNotFoundException if the user with the given ID does not exist
     */
    @Override
    public List<FavoriteDTO> getFavoritesByCustomer(Long customerId) {
        Users customer = usersRepository.findById(customerId)
                .orElseThrow(() -> new CustomerNotFoundException(Constants.USER_NOT_FOUND + customerId));
        List<Favorite> favorites = favoriteRepository.findByCustomer(customer);
        return favorites.stream()
                .map(favoriteMapper::toDto)
                .toList();
    }
}
