package com.endava.vehiclerentalapp.service;

import com.endava.vehiclerentalapp.dto.DriverDTO;
import java.util.List;

/**
 * Service interface for managing drivers.
 */
public interface DriverService {
    DriverDTO createDriver(DriverDTO driverDTO);
    DriverDTO getDriverById(Long driverId);
    List<DriverDTO> getAllDrivers();
    DriverDTO updateDriver(Long driverId, DriverDTO driverDTO);
    void deleteDriver(Long driverId);
    long getTotalDrivers();
}
