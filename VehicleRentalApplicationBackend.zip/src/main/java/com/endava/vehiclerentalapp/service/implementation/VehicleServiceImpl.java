package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.VehicleBookingDateDTO;
import com.endava.vehiclerentalapp.dto.VehicleComparisonDTO;
import com.endava.vehiclerentalapp.dto.VehicleDTO;
import com.endava.vehiclerentalapp.dto.VehicleFilterCriteriaDTO;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.entity.Vehicle;
import com.endava.vehiclerentalapp.entity.VehicleBookingDate;
import com.endava.vehiclerentalapp.exceptions.AdminNotFoundException;
import com.endava.vehiclerentalapp.exceptions.VehicleNotFoundException;
import com.endava.vehiclerentalapp.mapper.VehicleMapper;
import com.endava.vehiclerentalapp.repository.BookingRepository;
import com.endava.vehiclerentalapp.repository.UserRepository;
import com.endava.vehiclerentalapp.repository.VehicleRepository;
import com.endava.vehiclerentalapp.service.VehicleService;
import com.endava.vehiclerentalapp.util.Constants;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.*;

/**
 * Service implementation for managing vehicle-related operations. Provides
 * methods to add, update, delete, retrieve, filter, sort, compare, and manage
 * vehicle booking dates. Implements the
 * {@link com.endava.vehiclerentalapp.service.VehicleService} interface.
 */
@Service
public class VehicleServiceImpl implements VehicleService {

	private final VehicleRepository vehicleRepository;

	private final UserRepository userRepository;

	private final VehicleMapper vehicleMapper;

	private final BookingRepository bookingRepository;

	public VehicleServiceImpl(VehicleRepository vehicleRepository, UserRepository userRepository,
			VehicleMapper vehicleMapper, BookingRepository bookingRepository) {
		this.vehicleRepository = vehicleRepository;
		this.userRepository = userRepository;
		this.vehicleMapper = vehicleMapper;
		this.bookingRepository = bookingRepository;
	}

	/**
	 * Adds a new vehicle to the system.
	 * 
	 * @param vehicleDTO the data transfer object containing vehicle details
	 * @throws AdminNotFoundException if the admin specified in the DTO is not found
	 */
	@Override
	public void addVehicle(VehicleDTO vehicleDTO) {
		Optional<Users> admin = userRepository.findById(vehicleDTO.getAdminId());
		if (admin.isPresent()) {
			Vehicle vehicle = vehicleMapper.toEntity(vehicleDTO, admin.get());
			vehicle.setCreatedBy(admin.get().getEmail());
			vehicle.setUpdatedBy(admin.get().getEmail());
			vehicleRepository.save(vehicle);
		} else {
			throw new AdminNotFoundException(Constants.ADMIN_NOT_FOUND + vehicleDTO.getAdminId());
		}
	}

	/**
	 * Updates an existing vehicle's details.
	 * 
	 * @param vehicleId  the ID of the vehicle to update
	 * @param vehicleDTO the updated vehicle details
	 * @return an {@link Optional} containing the updated vehicle details as a DTO
	 * @throws VehicleNotFoundException if the vehicle with the given ID is not
	 *                                  found
	 */
	@Override
	public Optional<VehicleDTO> updateVehicle(Long vehicleId, VehicleDTO vehicleDTO) {
		Optional<Vehicle> vehicle = vehicleRepository.findById(vehicleId);
		if (vehicle.isPresent()) {
			Vehicle updatedVehicle = vehicle.get();
			updatedVehicle.setModelName(vehicleDTO.getModelName());
			updatedVehicle.setRegistrationNumber(vehicleDTO.getRegistrationNumber());
			updatedVehicle.setCategoryType(vehicleDTO.getCategoryType());
			updatedVehicle.setFuelType(vehicleDTO.getFuelType());
			updatedVehicle.setColor(vehicleDTO.getColor());
			updatedVehicle.setModelYear(vehicleDTO.getModelYear());
			updatedVehicle.setPricePerDay(vehicleDTO.getPricePerDay());
			updatedVehicle.setFeatureDescription(vehicleDTO.getFeatureDescription());
			updatedVehicle.setInsuranceNumber(vehicleDTO.getInsuranceNumber());
			Optional<Users> admin = userRepository.findById(vehicleDTO.getAdminId());
			admin.ifPresent(value -> updatedVehicle.setUpdatedBy(value.getEmail()));
			vehicleRepository.save(updatedVehicle);
			return Optional.of(vehicleMapper.toDto(updatedVehicle));
		} else {
			throw new VehicleNotFoundException(Constants.VEHICLE_NOT_FOUND + vehicleId);
		}
	}

	/**
	 * Marks a vehicle as deleted in the system.
	 * 
	 * @param vehicleId the ID of the vehicle to delete
	 * @throws VehicleNotFoundException if the vehicle with the given ID is not
	 *                                  found
	 */
	@Override
	public void deleteVehicle(Long vehicleId) {
		Optional<Vehicle> vehicle = vehicleRepository.findById(vehicleId);
		if (vehicle.isPresent()) {
			Vehicle existingVehicle = vehicle.get();

			if (bookingRepository.existsByVehicle_VehicleIdAndToDateAfter(vehicleId, LocalDate.now())) {
				throw new IllegalStateException(Constants.CANNOT_DELETE_VEHICLE);
			}

			existingVehicle.setDeleted(true);
			existingVehicle.setUpdatedAt(LocalDateTime.now());
			if (existingVehicle.getAdmin() != null) {
				existingVehicle.setUpdatedBy(existingVehicle.getAdmin().getEmail());
			} else {
				existingVehicle.setUpdatedBy(Constants.ADMIN_DEFAULT);
			}
			vehicleRepository.save(existingVehicle);
		} else {
			throw new VehicleNotFoundException(Constants.VEHICLE_NOT_FOUND + vehicleId);
		}
	}

	/**
	 * Retrieves the details of a vehicle by its ID.
	 * 
	 * @param vehicleId the ID of the vehicle to retrieve
	 * @return an {@link Optional} containing the vehicle details as a DTO if found
	 */
	@Override
	public Optional<VehicleDTO> getVehicleById(Long vehicleId) {
		Optional<Vehicle> vehicle = vehicleRepository.findById(vehicleId).filter(v -> !v.isDeleted());
		return vehicle.map(vehicleMapper::toDto);
	}

	/**
	 * Retrieves all vehicles in the system that are not marked as deleted.
	 * 
	 * @return a list of vehicle details as DTOs
	 */
	@Override
	public List<VehicleDTO> getAllVehicles() {
		List<Vehicle> vehicles = vehicleRepository.findAll().stream().filter(v -> !v.isDeleted()).toList();
		return vehicles.stream().map(vehicleMapper::toDto).toList();
	}

	/**
	 * Checks if a vehicle exists based on its registration number.
	 * 
	 * @param registrationNumber the registration number of the vehicle
	 * @return true if the vehicle exists, false otherwise
	 */
	@Override
	public boolean checkIfVehicleExistsByRegistrationNumber(String registrationNumber) {
		return vehicleRepository.findByRegistrationNumber(registrationNumber).isPresent();
	}

	/**
	 * Retrieves a vehicle by its model name.
	 * 
	 * @param modelName the model name of the vehicle
	 * @return an {@link Optional} containing the vehicle details as a DTO if found
	 */
	@Override
	public Optional<VehicleDTO> getVehicleByModelName(String modelName) {
		List<Vehicle> vehicles = vehicleRepository.findByModelNameIgnoreCase(modelName);
		if (!vehicles.isEmpty()) {
			return Optional.of(vehicleMapper.toDto(vehicles.get(0)));
		}
		return Optional.empty();
	}

	/**
	 * Searches vehicles based on a keyword in their model name or category type.
	 * 
	 * @param keyword the keyword to search for
	 * @return a list of vehicles matching the keyword as DTOs
	 */
	@Override
	public List<VehicleDTO> searchVehicles(String keyword) {
		List<Vehicle> vehicles = vehicleRepository.findByIsDeletedFalse();
		return vehicles.stream()
				.filter(vehicle -> vehicle.getModelName().toLowerCase().contains(keyword.toLowerCase())
						|| vehicle.getCategoryType().toLowerCase().contains(keyword.toLowerCase()))
				.map(vehicleMapper::toDto).toList();
	}

	/**
	 * Filters vehicles based on the provided filter criteria.
	 * 
	 * @param filterCriteria the criteria for filtering vehicles
	 * @return a list of filtered vehicles as DTOs
	 */
	@Override
	public List<VehicleDTO> filterVehicles(VehicleFilterCriteriaDTO filterCriteria) {
		List<Vehicle> vehicles = vehicleRepository.findByIsDeletedFalse();
		return vehicles.stream()
				.filter(vehicle -> isPriceFilterApplicable(filterCriteria.priceRange())
						? filterByPrice(vehicle, filterCriteria.priceRange())
						: true)
				.filter(vehicle -> isCategoryFilterApplicable(filterCriteria.categoryType())
						? filterByCategory(vehicle, filterCriteria.categoryType())
						: true)
				.filter(vehicle -> isFuelTypeFilterApplicable(filterCriteria.fuelType())
						? filterByFuelType(vehicle, filterCriteria.fuelType())
						: true)
				.filter(vehicle -> isColorFilterApplicable(filterCriteria.color())
						? filterByColor(vehicle, filterCriteria.color())
						: true)
				.map(vehicleMapper::toDto).toList();
	}

	/**
	 * Checks if the price range filter is applicable.
	 * 
	 * @param priceRange The price range as a String.
	 * @return true if the price range is not null or empty, otherwise false.
	 */
	private boolean isPriceFilterApplicable(String priceRange) {
		return priceRange != null && !priceRange.isEmpty();
	}

	/**
	 * Checks if the category filter is applicable.
	 * 
	 * @param categoryType The category type as a String.
	 * @return true if the category type is not null or empty, otherwise false.
	 */
	private boolean isCategoryFilterApplicable(String categoryType) {
		return categoryType != null && !categoryType.isEmpty();
	}

	/**
	 * Checks if the fuel type filter is applicable.
	 * 
	 * @param fuelType The fuel type as a String.
	 * @return true if the fuel type is not null or empty, otherwise false.
	 */
	private boolean isFuelTypeFilterApplicable(String fuelType) {
		return fuelType != null && !fuelType.isEmpty();
	}

	/**
	 * Checks if the color filter is applicable.
	 * 
	 * @param color The color as a String.
	 * @return true if the color is not null or empty, otherwise false.
	 */
	private boolean isColorFilterApplicable(String color) {
		return color != null && !color.isEmpty();
	}

	/**
	 * Filters a vehicle by color.
	 * 
	 * @param vehicle The vehicle to check.
	 * @param color   The color to filter by.
	 * @return true if the vehicle's color matches the specified color
	 *         (case-insensitive), otherwise false.
	 */
	private boolean filterByColor(Vehicle vehicle, String color) {
		return vehicle.getColor().equalsIgnoreCase(color);
	}

	/**
	 * Sorts vehicles based on a specified attribute and order.
	 * 
	 * @param sortBy    the attribute to sort by pricePerDay, modelYear
	 * @param ascending true for ascending order, false for descending order
	 * @return a list of sorted vehicles as DTOs
	 */
	@Override
	public List<VehicleDTO> sortVehicles(String sortBy, boolean ascending) {
		List<Vehicle> vehicles = vehicleRepository.findByIsDeletedFalse();

		Comparator<Vehicle> comparator = switch (sortBy.toLowerCase()) {
		case "priceperday" -> Comparator.comparing(Vehicle::getPricePerDay);
		case "modelyear" -> Comparator.comparing(Vehicle::getModelYear);
		default -> throw new IllegalArgumentException(Constants.INVALID_SORT_ATTRIBUTE + sortBy);
		};

		if (!ascending) {
			comparator = comparator.reversed();
		}

		return vehicles.stream().sorted(comparator).map(vehicleMapper::toDto).toList();
	}

	/**
	 * Compares two vehicles based on specific attributes.
	 * 
	 * @param vehicleIds the IDs of the two vehicles to compare
	 * @return a list of {@link VehicleComparisonDTO} objects containing comparison
	 *         details
	 * @throws IllegalArgumentException if the number of vehicle IDs is not exactly
	 *                                  two or if either vehicle does not exist
	 */
	@Override
	public List<VehicleComparisonDTO> compareVehicles(List<Long> vehicleIds) {
		if (vehicleIds.size() != 2) {
			throw new IllegalArgumentException(Constants.TWO_VEHICLES_REQUIRED);
		}
		List<Vehicle> vehicles = vehicleRepository.findAllById(vehicleIds);
		if (vehicles.size() != 2) {
			throw new IllegalArgumentException(Constants.BOTH_VEHICLES_MUST_EXIST);
		}
		Vehicle firstVehicle = vehicles.get(0);
		Vehicle secondVehicle = vehicles.get(1);
		List<String> attributes = List.of(Constants.VEHICLE_MODEL_NAME, Constants.VEHICLE_CATEGORY_TYPE,
				Constants.VEHICLE_FUEL_TYPE, Constants.VEHICLE_PRICE_PER_DAY, Constants.VEHICLE_MILEAGE,
				Constants.VEHICLE_MODEL_YEAR);
		return compareVehicleAttributes(firstVehicle, secondVehicle, attributes);
	}

	/**
	 * Compares the specified attributes of two vehicles and returns a list of
	 * comparisons.
	 * 
	 * @param firstVehicle  The first vehicle to compare.
	 * @param secondVehicle The second vehicle to compare.
	 * @param attributes    A list of attribute names to compare between the
	 *                      vehicles.
	 * @return A list of VehicleComparisonDTO objects representing the comparison
	 *         results for each attribute.
	 */
	private List<VehicleComparisonDTO> compareVehicleAttributes(Vehicle firstVehicle, Vehicle secondVehicle,
			List<String> attributes) {
		List<VehicleComparisonDTO> comparisons = new ArrayList<>();
		for (String attribute : attributes) {
			comparisons.add(compareVehicles(firstVehicle, secondVehicle, attribute));
		}
		return comparisons;
	}

	/**
	 * Filters a vehicle based on its price compared to the specified price range.
	 * 
	 * @param vehicle    The vehicle to filter.
	 * @param priceRange The price range to filter by. It can be one of the
	 *                   following values: "<500", "500-1000", "1000-1500",
	 *                   "1500-2000", ">2000".
	 * @return true if the vehicle's price falls within the specified price range,
	 *         otherwise false.
	 */
	private boolean filterByPrice(Vehicle vehicle, String priceRange) {
		double price = vehicle.getPricePerDay();

		return switch (priceRange) {
		case "<500" -> price < 500;
		case "500-1000" -> price >= 500 && price <= 1000;
		case "1000-1500" -> price >= 1000 && price <= 1500;
		case "1500-2000" -> price >= 1500 && price <= 2000;
		case ">2000" -> price > 2000;
		default -> true;
		};
	}

	/**
	 * Filters a vehicle based on its category type.
	 * 
	 * @param vehicle      The vehicle to filter.
	 * @param categoryType The category type to filter by. If null or empty, no
	 *                     filtering is applied.
	 * @return true if the vehicle's category matches the specified categoryType, or
	 *         if categoryType is null or empty.
	 */
	private boolean filterByCategory(Vehicle vehicle, String categoryType) {
		return categoryType == null || categoryType.isEmpty()
				|| vehicle.getCategoryType().equalsIgnoreCase(categoryType);
	}

	/**
	 * Filters a vehicle based on its fuel type.
	 * 
	 * @param vehicle  The vehicle to filter.
	 * @param fuelType The fuel type to filter by. If null or empty, no filtering is
	 *                 applied.
	 * @return true if the vehicle's fuel type matches the specified fuelType, or if
	 *         fuelType is null or empty.
	 */
	private boolean filterByFuelType(Vehicle vehicle, String fuelType) {
		return fuelType == null || fuelType.isEmpty() || vehicle.getFuelType().equalsIgnoreCase(fuelType);
	}

	/**
	 * Compares the specified attribute of two vehicles and creates a comparison DTO
	 * with the results.
	 * 
	 * @param firstVehicle  The first vehicle to compare.
	 * @param secondVehicle The second vehicle to compare.
	 * @param attribute     The attribute to compare between the two vehicles.
	 *                      Supported attributes include: "modelName",
	 *                      "categoryType", "fuelType", "pricePerDay", "mileage",
	 *                      and "modelYear".
	 * @return A VehicleComparisonDTO object containing the comparison results for
	 *         the specified attribute.
	 * @throws IllegalArgumentException If the provided attribute is not supported.
	 */
	private VehicleComparisonDTO compareVehicles(Vehicle firstVehicle, Vehicle secondVehicle, String attribute) {
		VehicleComparisonDTO comparisonDTO = new VehicleComparisonDTO();
		comparisonDTO.setVehicleId1(firstVehicle.getVehicleId());
		comparisonDTO.setVehicleId2(secondVehicle.getVehicleId());
		comparisonDTO.setAttribute(attribute);

		switch (attribute) {
		case Constants.VEHICLE_MODEL_NAME ->
			setComparisonValues(comparisonDTO, firstVehicle.getModelName(), secondVehicle.getModelName());
		case Constants.VEHICLE_CATEGORY_TYPE ->
			setComparisonValues(comparisonDTO, firstVehicle.getCategoryType(), secondVehicle.getCategoryType());
		case Constants.VEHICLE_FUEL_TYPE ->
			setComparisonValues(comparisonDTO, firstVehicle.getFuelType(), secondVehicle.getFuelType());
		case Constants.VEHICLE_PRICE_PER_DAY -> setComparisonValues(comparisonDTO,
				firstVehicle.getPricePerDay().toString(), secondVehicle.getPricePerDay().toString(), true);
		case Constants.VEHICLE_MILEAGE -> setComparisonValues(comparisonDTO, firstVehicle.getMileage().toString(),
				secondVehicle.getMileage().toString(), true);
		case Constants.VEHICLE_MODEL_YEAR ->
			setComparisonValues(comparisonDTO, firstVehicle.getModelYear(), secondVehicle.getModelYear());
		default -> throw new IllegalArgumentException(Constants.UNSUPPORTED_ATTRIBUTE + attribute);
		}

		Map<String, String> attributeDisplayNames = Map.of(Constants.VEHICLE_MODEL_NAME, "Model Name",
				Constants.VEHICLE_CATEGORY_TYPE, "Category Type", Constants.VEHICLE_FUEL_TYPE, "Fuel Type",
				Constants.VEHICLE_PRICE_PER_DAY, "Price Per Day", Constants.VEHICLE_MILEAGE, "Mileage",
				Constants.VEHICLE_MODEL_YEAR, "Model Year");

		comparisonDTO.setAttribute(attributeDisplayNames.getOrDefault(attribute, attribute));

		return comparisonDTO;
	}

	/**
	 * Sets the comparison values for a non-numeric attribute.
	 * 
	 * @param comparisonDTO The VehicleComparisonDTO object to store the comparison
	 *                      results.
	 * @param value1        The value of the attribute for the first vehicle.
	 * @param value2        The value of the attribute for the second vehicle.
	 */
	private void setComparisonValues(VehicleComparisonDTO comparisonDTO, String value1, String value2) {
		comparisonDTO.setValue1(value1);
		comparisonDTO.setValue2(value2);
		comparisonDTO.setDifference(value1.equals(value2) ? Constants.NO_DIFFERENCE : Constants.DIFFERENT);
	}

	/**
	 * Sets the comparison values for a numeric attribute and calculates the
	 * difference.
	 * 
	 * @param comparisonDTO The VehicleComparisonDTO object to store the comparison
	 *                      results.
	 * @param value1        The value of the numeric attribute for the first
	 *                      vehicle.
	 * @param value2        The value of the numeric attribute for the second
	 *                      vehicle.
	 * @param isNumeric     A flag indicating whether the values are numeric (used
	 *                      for calculating the difference).
	 */
	private void setComparisonValues(VehicleComparisonDTO comparisonDTO, String value1, String value2,
			boolean isNumeric) {
		comparisonDTO.setValue1(value1);
		comparisonDTO.setValue2(value2);
		String printIsDifferencePresent = value1.equals(value2) ? Constants.NO_DIFFERENCE : Constants.DIFFERENT;
		String difference = isNumeric
				? String.valueOf(Math.abs(Double.parseDouble(value1) - Double.parseDouble(value2)))
				: printIsDifferencePresent;
		comparisonDTO.setDifference(difference);
	}

	/**
	 * Adds a booking date for a specific vehicle.
	 * 
	 * This method retrieves a vehicle by its ID and checks if the vehicle exists
	 * and is not marked as deleted. If the vehicle is found, a new booking date is
	 * added to the vehicle's list of booking dates and the vehicle is saved back to
	 * the repository.
	 * 
	 * @param vehicleId             The ID of the vehicle for which the booking date
	 *                              is being added.
	 * @param vehicleBookingDateDTO The DTO containing the booking date to be added
	 *                              to the vehicle.
	 * @throws VehicleNotFoundException If the vehicle with the specified ID is not
	 *                                  found or is deleted.
	 */
	@Override
	public void addVehicleBookingDate(Long vehicleId, VehicleBookingDateDTO vehicleBookingDateDTO) {
		Optional<Vehicle> vehicleOptional = vehicleRepository.findById(vehicleId).filter(v -> !v.isDeleted());
		if (!vehicleOptional.isPresent()) {
			throw new VehicleNotFoundException(Constants.VEHICLE_NOT_FOUND + vehicleId);
		}
		Vehicle vehicle = vehicleOptional.get();
		VehicleBookingDate vehicleBookingDate = new VehicleBookingDate();
		vehicleBookingDate.setBookedDate(vehicleBookingDateDTO.getBookedDate());
		vehicle.getVehicleBookingDates().add(vehicleBookingDate);
		vehicleRepository.save(vehicle);
	}

	/**
	 * Retrieves the total number of vehicles that are not marked as deleted.
	 * 
	 * This method counts all vehicles in the repository where the `isDeleted` flag
	 * is set to `false`, indicating that the vehicle is active and not deleted.
	 * 
	 * @return The total number of vehicles that are not deleted.
	 */
	@Override
	public long getTotalVehicles() {
		return vehicleRepository.countByIsDeletedFalse();
	}

}
