package com.endava.vehiclerentalapp.service;

import com.endava.vehiclerentalapp.dto.VehicleBookingDateDTO;
import com.endava.vehiclerentalapp.dto.VehicleComparisonDTO;
import com.endava.vehiclerentalapp.dto.VehicleDTO;
import com.endava.vehiclerentalapp.dto.VehicleFilterCriteriaDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service interface for vehicle management in the Vehicle Rental Application.
 * 
 * This interface defines methods for handling vehicle-related actions such as adding, updating,
 * deleting, and retrieving vehicles. The methods involve interactions with the underlying data
 * layer to manage vehicle information and availability.
 */
public interface VehicleService {

    void addVehicle(VehicleDTO vehicleDTO);
    Optional<VehicleDTO> updateVehicle(Long vehicleId, VehicleDTO vehicleDTO);
    void deleteVehicle(Long vehicleId);
    Optional<VehicleDTO> getVehicleById(Long vehicleId);
    List<VehicleDTO> getAllVehicles();
    boolean checkIfVehicleExistsByRegistrationNumber(String registrationNumber);
    Optional<VehicleDTO> getVehicleByModelName(String modelName);
    List<VehicleDTO> searchVehicles(String keyword);
    List<VehicleDTO> filterVehicles(VehicleFilterCriteriaDTO filterCriteria);
    List<VehicleDTO> sortVehicles(String sortBy, boolean ascending);
    List<VehicleComparisonDTO> compareVehicles(List<Long> vehicleIds);
    void addVehicleBookingDate(Long vehicleId, VehicleBookingDateDTO vehicleBookingDateDTO);
    long getTotalVehicles();
}
