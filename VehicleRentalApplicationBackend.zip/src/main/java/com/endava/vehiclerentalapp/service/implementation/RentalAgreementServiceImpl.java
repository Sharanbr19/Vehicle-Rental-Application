package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.RentalAgreementDTO;
import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.RentalAgreement;
import com.endava.vehiclerentalapp.mapper.RentalAgreementMapper;
import com.endava.vehiclerentalapp.repository.BookingRepository;
import com.endava.vehiclerentalapp.repository.RentalAgreementRepository;
import com.endava.vehiclerentalapp.service.RentalAgreementService;
import com.endava.vehiclerentalapp.util.Constants;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Implementation of RentalAgreementService.
 * Provides functionalities to manage rental agreements, including creation, retrieval, and deletion.
 */
@Service
public class RentalAgreementServiceImpl implements RentalAgreementService {

    private final RentalAgreementRepository rentalAgreementRepository;
    
    private final BookingRepository bookingRepository;
    
    private final RentalAgreementMapper rentalAgreementMapper;

    public RentalAgreementServiceImpl(RentalAgreementRepository rentalAgreementRepository,
			BookingRepository bookingRepository, RentalAgreementMapper rentalAgreementMapper) {
		this.rentalAgreementRepository = rentalAgreementRepository;
		this.bookingRepository = bookingRepository;
		this.rentalAgreementMapper = rentalAgreementMapper;
	}
    
    /**
     * Creates a new rental agreement based on the provided DTO.
     * Associates the rental agreement with an existing booking.
     *
     * @param rentalAgreementDTO the rental agreement details
     * @return the created rental agreement as a DTO
     * @throws RuntimeException if the corresponding booking is not found
     */
    @Override
    public RentalAgreementDTO createRentalAgreement(RentalAgreementDTO rentalAgreementDTO) {
        RentalAgreement rentalAgreement = rentalAgreementMapper.toEntity(rentalAgreementDTO);
        Booking booking = bookingRepository.findById(rentalAgreementDTO.getBookingId())
                .orElseThrow(() -> new RuntimeException(Constants.BOOKING_NOT_FOUND));

        rentalAgreement.setBooking(booking);
        RentalAgreement savedRentalAgreement = rentalAgreementRepository.save(rentalAgreement);
        return rentalAgreementMapper.toDTO(savedRentalAgreement);
    }

    /**
     * Retrieves a rental agreement by its ID.
     *
     * @param rentalId the ID of the rental agreement
     * @return the rental agreement details as a DTO
     * @throws RuntimeException if the rental agreement is not found
     */
    @Override
    public RentalAgreementDTO getRentalAgreementById(Long rentalId) {
        RentalAgreement rentalAgreement = rentalAgreementRepository.findById(rentalId)
                .orElseThrow(() -> new RuntimeException(Constants.RENTAL_AGREEMENT_NOT_FOUND));
        return rentalAgreementMapper.toDTO(rentalAgreement);
    }

    /**
     * Retrieves all rental agreements.
     *
     * @return a list of all rental agreements as DTOs
     */
    @Override
    public List<RentalAgreementDTO> getAllRentalAgreements() {
        return rentalAgreementRepository.findAll().stream()
                .map(rentalAgreementMapper::toDTO)
                .toList();
    }

    /**
     * Retrieves all rental agreements associated with a specific customer.
     *
     * @param customerId the ID of the customer
     * @return a list of rental agreements for the specified customer as DTOs
     */
    @Override
    public List<RentalAgreementDTO> getRentalAgreementByCustomerId(Long customerId) {
        return rentalAgreementRepository.findByBooking_Customer_UserId(customerId).stream()
                .map(rentalAgreementMapper::toDTO)
                .toList();
    }

    /**
     * Deletes a rental agreement by its ID.
     *
     * @param rentalId the ID of the rental agreement to delete
     */
    @Override
    public void deleteRentalAgreement(Long rentalId) {
        rentalAgreementRepository.deleteById(rentalId);
    }

}
