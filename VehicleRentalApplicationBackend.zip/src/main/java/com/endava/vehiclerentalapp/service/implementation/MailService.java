package com.endava.vehiclerentalapp.service.implementation;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import com.endava.vehiclerentalapp.util.Constants;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

/**
 * Service for sending emails.
 * This class is responsible for composing and sending emails such as password reset requests.
 */
@Service
public class MailService {

	private JavaMailSender mailSender;

	public MailService(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}
	
    /**
     * Sends an HTML email with the specified subject and HTML content to the recipient.
     *
     * @param to          the recipient email address
     * @param subject     the subject of the email
     * @param htmlContent the HTML content of the email
     * @throws MessagingException if there is an error while creating or sending the email
     */
    public void sendHtmlEmail(String to, String subject, String htmlContent) throws MessagingException {
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        helper.setTo(to);
        helper.setSubject(subject);
        helper.setText(htmlContent, true);
        helper.setFrom(Constants.ADMIN_EMAIL);
        mailSender.send(mimeMessage);
    }
}
