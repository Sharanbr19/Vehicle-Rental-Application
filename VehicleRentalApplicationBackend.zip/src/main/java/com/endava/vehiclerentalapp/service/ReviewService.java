package com.endava.vehiclerentalapp.service;

import com.endava.vehiclerentalapp.dto.ReviewDTO;
import java.util.List;

/**
 * Service interface for Customer Review operations.
 */
public interface ReviewService {
    ReviewDTO createReview(ReviewDTO reviewDTO);
    ReviewDTO updateReview(Long userId, Long vehicleId, ReviewDTO reviewDTO);  
    void deleteReview(Long userId, Long vehicleId);  
    ReviewDTO getReview(Long reviewId);
    List<ReviewDTO> getAllReviews();
    List<ReviewDTO> getReviewsByVehicleId(Long vehicleId);
    List<ReviewDTO> getReviewsByCustomerId(Long customerId);
    Double getAverageRatingByVehicleId(Long vehicleId);
}
