package com.endava.vehiclerentalapp.service;

import com.endava.vehiclerentalapp.dto.UserDto;
import com.endava.vehiclerentalapp.entity.Users;
import java.util.List;
import java.util.Optional;

/**
 * Service interface for user management in the Vehicle Rental Application.
 * Defines methods for handling user-related actions such as registration, login, OTP validation, password reset, and CRUD operations.
 */
public interface UserService {
    void registerUser(UserDto userDto, String currentAdminEmail);
    Optional<String> loginUser(String email, String password);
    boolean checkIfUserExistsByEmail(String email);
    void saveOtp(String email, String otp);
    boolean validateOtp(String email, String otp);
    void updatePassword(String email, String newPassword);
    Optional<Users> getUserById(Long userId);
    Optional<Users> getUserByEmail(String email);
    List<Users> getAllUsers();
    void updateUser(Long userId, UserDto userDto, String currentAdminEmail);
    void deleteUser(Long userId, String currentAdminEmail);
    long getTotalCustomers();
	boolean verifyOtp(String email, String otp);
	String sendOtpToEmail(String email);
	void updateProfile(Long userId, UserDto userDto, String currentAdminEmail);
}
