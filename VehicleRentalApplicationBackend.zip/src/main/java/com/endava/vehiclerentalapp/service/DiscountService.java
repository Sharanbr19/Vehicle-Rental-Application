package com.endava.vehiclerentalapp.service;

import com.endava.vehiclerentalapp.dto.DiscountDTO;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

public interface DiscountService {
    
    DiscountDTO createDiscount(DiscountDTO discountDTO);
    
    DiscountDTO updateDiscount(Long discountId, DiscountDTO discountDTO);
    
    void deleteDiscount(Long discountId);
    
    DiscountDTO getDiscountById(Long discountId);
    
    List<DiscountDTO> getAllDiscounts();
    
    void applyBulkDiscountByCategory(String categoryType, double discountPercentage, LocalDate startDate, LocalDate endDate);

	void applyBulkDiscountFromExcel(MultipartFile file);

	void deleteExpiredDiscounts();

	Optional<DiscountDTO> getHighestDiscountForVehicle(Long vehicleId);
    
}
