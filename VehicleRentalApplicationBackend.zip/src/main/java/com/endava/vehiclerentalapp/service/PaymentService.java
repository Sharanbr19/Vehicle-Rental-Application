package com.endava.vehiclerentalapp.service;

import com.razorpay.RazorpayException;
import com.endava.vehiclerentalapp.dto.PaymentDTO;

import java.util.List;

/**
 * Service interface for Payment for bookings.
 */
public interface PaymentService {

    PaymentDTO getPaymentById(Long id);

    List<PaymentDTO> getAllPayments();

    String createPayment(PaymentDTO paymentDTO) throws RazorpayException;

    String updatePayment(Long id, PaymentDTO paymentDTO);

    String deletePayment(Long id);
}
