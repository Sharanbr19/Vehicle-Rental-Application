package com.endava.vehiclerentalapp.service;

import com.endava.vehiclerentalapp.dto.InvoiceDTO;
import java.util.List;

/**
 * Service interface for InvoiceService operations.
 */
public interface InvoiceService {
    InvoiceDTO createInvoice(InvoiceDTO invoiceDTO);
    InvoiceDTO getInvoiceById(Long invoiceId);
    List<InvoiceDTO> getAllInvoices();
    void deleteInvoice(Long invoiceId);
    List<InvoiceDTO> getInvoicesByCustomerId(Long customerId);  
}
