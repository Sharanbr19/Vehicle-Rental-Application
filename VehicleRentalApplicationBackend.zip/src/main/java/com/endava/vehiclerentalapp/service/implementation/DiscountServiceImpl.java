package com.endava.vehiclerentalapp.service.implementation;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.scheduling.annotation.Scheduled;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import com.endava.vehiclerentalapp.dto.DiscountDTO;
import com.endava.vehiclerentalapp.entity.Discount;
import com.endava.vehiclerentalapp.entity.Vehicle;
import com.endava.vehiclerentalapp.exceptions.DiscountNotFoundException;
import com.endava.vehiclerentalapp.exceptions.ExcelParsingFailedException;
import com.endava.vehiclerentalapp.exceptions.VehicleNotFoundException;
import com.endava.vehiclerentalapp.mapper.DiscountMapper;
import com.endava.vehiclerentalapp.repository.DiscountRepository;
import com.endava.vehiclerentalapp.repository.VehicleRepository;
import com.endava.vehiclerentalapp.service.DiscountService;
import com.endava.vehiclerentalapp.util.Constants;

@Service
public class DiscountServiceImpl implements DiscountService {

	private final DiscountRepository discountRepository;
	private final VehicleRepository vehicleRepository;
	private final DiscountMapper discountMapper;

	public DiscountServiceImpl(DiscountRepository discountRepository, VehicleRepository vehicleRepository,
			DiscountMapper discountMapper) {
		this.discountRepository = discountRepository;
		this.vehicleRepository = vehicleRepository;
		this.discountMapper = discountMapper;
	}

	@Override
	@Transactional
	public DiscountDTO createDiscount(DiscountDTO discountDTO) {
		Set<Vehicle> vehicles = new HashSet<>();

		if (discountDTO.getVehicleIds() != null) {
			vehicles = new HashSet<>(vehicleRepository.findAllById(discountDTO.getVehicleIds()));
		}

		Discount discount = new Discount();
		discount.setDiscountPercentage(discountDTO.getDiscountPercentage());
		discount.setCategoryType(discountDTO.getCategoryType());
		discount.setStartDate(discountDTO.getStartDate());
		discount.setEndDate(discountDTO.getEndDate());
		discount.setVehicles(vehicles);

		discount = discountRepository.save(discount);
		return discountMapper.toDTO(discount);
	}

	@Override
	@Transactional
	public DiscountDTO updateDiscount(Long discountId, DiscountDTO discountDTO) {
		Discount discount = discountRepository.findById(discountId)
				.orElseThrow(() -> new DiscountNotFoundException(Constants.DISCOUNT_NOT_FOUND));

		discount.setDiscountPercentage(discountDTO.getDiscountPercentage());
		discount.setCategoryType(discountDTO.getCategoryType());
		discount.setStartDate(discountDTO.getStartDate());
		discount.setEndDate(discountDTO.getEndDate());

		if (discountDTO.getVehicleIds() != null) {
			Set<Vehicle> vehicles = new HashSet<>(vehicleRepository.findAllById(discountDTO.getVehicleIds()));
			discount.setVehicles(vehicles);
		}

		discount = discountRepository.save(discount);
		return discountMapper.toDTO(discount);
	}

	@Override
	public Optional<DiscountDTO> getHighestDiscountForVehicle(Long vehicleId) {
	    return discountRepository.findHighestDiscountForVehicle(vehicleId)
	            .map(discount -> {
	                DiscountDTO dto = new DiscountDTO();
	                dto.setDiscountId(discount.getDiscountId());
	                dto.setDiscountPercentage(discount.getDiscountPercentage());
	                dto.setCategoryType(discount.getCategoryType());
	                dto.setStartDate(discount.getStartDate());
	                dto.setEndDate(discount.getEndDate());
	                dto.setVehicleIds(discount.getVehicles()
	                        .stream()
	                        .map(Vehicle::getVehicleId)
	                        .collect(Collectors.toSet()));
	                return dto;
	            });
	}

	@Override
	@Transactional
	@Scheduled(cron = "0 0 11 * * ?")
	public void deleteExpiredDiscounts() {
		discountRepository.deleteExpiredDiscounts();
	}

	@Override
	@Transactional
	public void deleteDiscount(Long discountId) {
		if (!discountRepository.existsById(discountId)) {
			throw new DiscountNotFoundException(Constants.DISCOUNT_NOT_FOUND);
		}
		discountRepository.deleteById(discountId);
	}

	@Override
	public DiscountDTO getDiscountById(Long discountId) {
		Discount discount = discountRepository.findById(discountId)
				.orElseThrow(() -> new DiscountNotFoundException(Constants.DISCOUNT_NOT_FOUND));
		return discountMapper.toDTO(discount);
	}

	@Override
	@Transactional
	public List<DiscountDTO> getAllDiscounts() {
		List<Discount> discounts = discountRepository.findAll();
		return discounts.stream().map(discountMapper::toDTO).toList();
	}

	@Override
	@Transactional
	public void applyBulkDiscountByCategory(String categoryType, double discountPercentage, LocalDate startDate, LocalDate endDate) {
		List<Vehicle> vehicles = vehicleRepository.findByCategoryType(categoryType);
		if (vehicles.isEmpty()) {
			throw new VehicleNotFoundException(Constants.VEHICLE_NOT_FOUND_CATEGORY + categoryType);
		}

		Discount discount = new Discount();
		discount.setDiscountPercentage(discountPercentage);
		discount.setCategoryType(categoryType);
		discount.setStartDate(startDate);
		discount.setEndDate(endDate);
		discount.setVehicles(new HashSet<>(vehicles));

		discountRepository.save(discount);
	}

	@Override
	@Transactional
	public void applyBulkDiscountFromExcel(MultipartFile file) {
		List<Discount> discounts = parseExcelFile(file);
		discountRepository.saveAll(discounts);
	}

	private List<Discount> parseExcelFile(MultipartFile file) {
		List<Discount> discounts = new ArrayList<>();
		try (InputStream inputStream = file.getInputStream(); Workbook workbook = new XSSFWorkbook(inputStream)) {
			Sheet sheet = workbook.getSheetAt(0);
			for (Row row : sheet) {
				if (row.getRowNum() == 0)
					continue;
				Long vehicleId = (long) row.getCell(0).getNumericCellValue();
				double discountPercentage = row.getCell(1).getNumericCellValue();
				Cell startDateCell = row.getCell(2);
				Cell endDateCell = row.getCell(3);
				LocalDate startDate = startDateCell != null ? startDateCell.getLocalDateTimeCellValue().toLocalDate()
						: null;
				LocalDate endDate = endDateCell != null ? endDateCell.getLocalDateTimeCellValue().toLocalDate() : null;
				Vehicle vehicle = vehicleRepository.findById(vehicleId)
						.orElseThrow(() -> new VehicleNotFoundException(Constants.VEHICLE_NOT_FOUND + vehicleId));
				Discount discount = new Discount();
				discount.setDiscountPercentage(discountPercentage);
				discount.setStartDate(startDate);
				discount.setEndDate(endDate);
				discount.setVehicles(Collections.singleton(vehicle));
				discounts.add(discount);
			}
		} catch (IOException e) {
			throw new ExcelParsingFailedException(Constants.EXCEL_PARSE_FAILED, e);
		}
		return discounts;
	}

}
