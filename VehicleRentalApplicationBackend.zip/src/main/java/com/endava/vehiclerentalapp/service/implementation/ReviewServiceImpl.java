package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.ReviewDTO;
import com.endava.vehiclerentalapp.entity.Review;
import com.endava.vehiclerentalapp.mapper.ReviewMapper;
import com.endava.vehiclerentalapp.repository.ReviewRepository;
import com.endava.vehiclerentalapp.service.ReviewService;
import com.endava.vehiclerentalapp.util.Constants;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Service implementation for handling Review-related operations.
 * This class provides methods to create, update, delete, retrieve, and calculate review-related data.
 */
@Service
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository reviewRepository;
    
    private final ReviewMapper reviewMapper;

    /**
     * Constructs a ReviewServiceImpl with the specified repository and mapper.
     *
     * @param reviewRepository the repository for managing review data
     * @param reviewMapper     the mapper for converting between entity and DTO
     */
    public ReviewServiceImpl(ReviewRepository reviewRepository, ReviewMapper reviewMapper) {
        this.reviewRepository = reviewRepository;
        this.reviewMapper = reviewMapper;
    }

    /**
     * Creates a new review for a vehicle by a customer.
     * Ensures that a customer cannot submit multiple reviews for the same vehicle.
     *
     * @param reviewDTO the review details
     * @return the created review as a DTO
     * @throws IllegalStateException if the customer has already reviewed the vehicle
     */
    @Override
    public ReviewDTO createReview(ReviewDTO reviewDTO) {
        boolean exists = reviewRepository.existsByCustomer_UserIdAndVehicle_VehicleId(
            reviewDTO.getCustomerId(), reviewDTO.getVehicleId()
        );
        if (exists) {
            throw new IllegalStateException(Constants.USER_ALREADY_REVIEWED);
        }
        Review review = reviewMapper.toEntity(reviewDTO);
        Review savedReview = reviewRepository.save(review);
        return reviewMapper.toDTO(savedReview);
    }

    /**
     * Updates an existing review for a given customer and vehicle.
     *
     * @param userId    the ID of the customer
     * @param vehicleId the ID of the vehicle
     * @param reviewDTO the updated review details
     * @return the updated review as a DTO
     * @throws IllegalArgumentException if the review does not exist
     */
    @Override
    public ReviewDTO updateReview(Long userId, Long vehicleId, ReviewDTO reviewDTO) {
        Review review = reviewRepository.findByCustomer_UserIdAndVehicle_VehicleId(userId, vehicleId)
                .orElseThrow(() -> new IllegalArgumentException(Constants.REVIEW_NOT_FOUND));
        review.setRating(reviewDTO.getRating());
        review.setComment(reviewDTO.getComment()); 
        Review updatedReview = reviewRepository.save(review);
        return reviewMapper.toDTO(updatedReview);
    }

    /**
     * Deletes a review for a given customer and vehicle.
     *
     * @param userId    the ID of the customer
     * @param vehicleId the ID of the vehicle
     * @throws IllegalArgumentException if the review does not exist
     */
    @Override
    public void deleteReview(Long userId, Long vehicleId) {
        Review review = reviewRepository.findByCustomer_UserIdAndVehicle_VehicleId(userId, vehicleId)
                .orElseThrow(() -> new IllegalArgumentException(Constants.REVIEW_NOT_FOUND));
        
        reviewRepository.delete(review);
    }

    /**
     * Retrieves a review by its ID.
     *
     * @param reviewId the ID of the review
     * @return the review details as a DTO
     * @throws IllegalArgumentException if the review is not found
     */
    @Override
    public ReviewDTO getReview(Long reviewId) {
        return reviewRepository.findById(reviewId)
                .map(reviewMapper::toDTO)
                .orElseThrow(() -> new IllegalArgumentException(Constants.REVIEW_NOT_FOUND));
    }

    /**
     * Retrieves all reviews from the database.
     *
     * @return a list of all reviews as DTOs
     */
    @Override
    public List<ReviewDTO> getAllReviews() {
        return reviewRepository.findAll().stream()
                .map(reviewMapper::toDTO)
                .toList();
    }
    
    /**
     * Retrieves all reviews for a given vehicle.
     *
     * @param vehicleId the ID of the vehicle
     * @return a list of reviews for the vehicle as DTOs
     */
    @Override
    public List<ReviewDTO> getReviewsByVehicleId(Long vehicleId) {
        return reviewRepository.findByVehicle_VehicleId(vehicleId).stream()
                .map(reviewMapper::toDTO)
                .toList();
    }

    /**
     * Retrieves all reviews submitted by a specific customer.
     *
     * @param customerId the ID of the customer
     * @return a list of reviews submitted by the customer as DTOs
     */
    @Override
    public List<ReviewDTO> getReviewsByCustomerId(Long customerId) {
        return reviewRepository.findByCustomer_UserId(customerId).stream()
                .map(reviewMapper::toDTO)
                .toList();
    }
    
    /**
     * Calculates the average rating for a given vehicle based on all submitted reviews.
     * If no reviews exist, returns 0.0.
     *
     * @param vehicleId the ID of the vehicle
     * @return the average rating for the vehicle
     */
    @Override
    public Double getAverageRatingByVehicleId(Long vehicleId) {
        Double averageRating = reviewRepository.findAverageRatingByVehicleId(vehicleId);
        return (averageRating != null) ? averageRating : 0.0; 
    }
}
