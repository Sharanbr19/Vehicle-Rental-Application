package com.endava.vehiclerentalapp.service;

import com.endava.vehiclerentalapp.dto.RentalAgreementDTO;
import java.util.List;

/**
 * Service interface for RentalAgreement operations.
 */
public interface RentalAgreementService {
    RentalAgreementDTO createRentalAgreement(RentalAgreementDTO rentalAgreementDTO);
    RentalAgreementDTO getRentalAgreementById(Long rentalId);
    List<RentalAgreementDTO> getAllRentalAgreements();
    void deleteRentalAgreement(Long rentalId);
	List<RentalAgreementDTO> getRentalAgreementByCustomerId(Long customerId);
}
