package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.InvoiceDTO;
import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.Invoice;
import com.endava.vehiclerentalapp.mapper.InvoiceMapper;
import com.endava.vehiclerentalapp.repository.BookingRepository;
import com.endava.vehiclerentalapp.repository.InvoiceRepository;
import com.endava.vehiclerentalapp.service.InvoiceService;
import com.endava.vehiclerentalapp.util.Constants;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Service implementation for handling invoice operations.
 * Manages invoice creation, retrieval, and deletion for vehicle rental bookings.
 */
@Service
public class InvoiceServiceImpl implements InvoiceService {

    private final InvoiceRepository invoiceRepository;

    private final BookingRepository bookingRepository;

    private final InvoiceMapper invoiceMapper;

    public InvoiceServiceImpl(InvoiceRepository invoiceRepository, BookingRepository bookingRepository,
			InvoiceMapper invoiceMapper) {
		super();
		this.invoiceRepository = invoiceRepository;
		this.bookingRepository = bookingRepository;
		this.invoiceMapper = invoiceMapper;
	}
    
    /**
     * Creates an invoice for a given booking.
     *
     * @param invoiceDTO the invoice details.
     * @return the created invoice as a DTO.
     * @throws RuntimeException if the associated booking is not found.
     */
    @Override
    public InvoiceDTO createInvoice(InvoiceDTO invoiceDTO) {
        Booking booking = bookingRepository.findById(invoiceDTO.getBookingId())
                .orElseThrow(() -> new RuntimeException(Constants.BOOKING_NOT_FOUND));

        Invoice invoice = invoiceMapper.toEntity(invoiceDTO, booking);
        invoice = invoiceRepository.save(invoice);

        return invoiceMapper.toDTO(invoice);
    }

    /**
     * Retrieves an invoice by its ID.
     *
     * @param invoiceId the ID of the invoice.
     * @return the invoice details as a DTO.
     * @throws RuntimeException if no invoice is found with the given ID.
     */
    @Override
    public InvoiceDTO getInvoiceById(Long invoiceId) {
        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new RuntimeException(Constants.INVOICE_NOT_FOUND));

        return invoiceMapper.toDTO(invoice);
    }

    /**
     * Retrieves a list of invoices associated with a given customer.
     *
     * @param customerId the ID of the customer.
     * @return a list of InvoiceDTO objects.
     */
    @Override
    public List<InvoiceDTO> getInvoicesByCustomerId(Long customerId) {
        return invoiceRepository.findByBooking_Customer_UserId(customerId).stream()
                .map(invoiceMapper::toDTO)
                .toList();
    }

    /**
     * Retrieves all invoices in the system.
     *
     * @return a list of all InvoiceDTO objects.
     */
    @Override
    public List<InvoiceDTO> getAllInvoices() {
        List<Invoice> invoices = invoiceRepository.findAll();
        return invoices.stream()
                .map(invoiceMapper::toDTO)
                .toList();
    }

    /**
     * Deletes an invoice by its ID.
     *
     * @param invoiceId the ID of the invoice to be deleted.
     */
    @Override
    public void deleteInvoice(Long invoiceId) {
        invoiceRepository.deleteById(invoiceId);
    }


}
