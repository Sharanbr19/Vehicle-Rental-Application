package com.endava.vehiclerentalapp.service;

import com.endava.vehiclerentalapp.dto.BookingDTO;
import com.endava.vehiclerentalapp.dto.VehicleDTO;

import java.time.LocalDate;
import java.util.List;

/**
 * Service interface for managing vehicle bookings.
 * Defines methods for creating, retrieving, updating, and deleting bookings.
 * Also includes methods for checking vehicle availability within a specified date range.
 * 
 * The methods in this service are used by controllers to interact with booking data,
 * providing an abstraction layer between the controller and the underlying persistence layer.
 */
public interface BookingService {
    BookingDTO createBooking(BookingDTO bookingDTO);
    BookingDTO getBookingById(Long bookingId);
    List<BookingDTO> getAllBookings();
    BookingDTO updateBooking(Long bookingId, BookingDTO bookingDTO);
    void deleteBooking(Long bookingId);
    List<BookingDTO> getBookingsByVehicleId(Long vehicleId);
    List<BookingDTO> getBookingsByCustomerId(Long customerId);
    List<VehicleDTO> getAvailableVehiclesBetweenDates(LocalDate fromDate, LocalDate toDate);
    long getTotalBookings();
    long getTotalEarnings();
	List<Object[]> getEarningsByCategoryType();
	List<Object[]> getBookingCountByCategoryType();
}
