package com.endava.vehiclerentalapp.service;

import com.endava.vehiclerentalapp.dto.FavoriteDTO;
import java.util.List;

/**
 * Service interface for handling the business logic related to favorites.
 */
public interface FavoriteService {
    FavoriteDTO addFavorite(FavoriteDTO favoriteDTO);
    void removeFavorite(Long userId, Long vehicleId);
	List<FavoriteDTO> getFavoritesByCustomer(Long customerId);
}
