package com.endava.vehiclerentalapp.service.implementation;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.endava.vehiclerentalapp.dto.BookingDTO;
import com.endava.vehiclerentalapp.dto.VehicleDTO;
import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.BookingStatus;
import com.endava.vehiclerentalapp.entity.Discount;
import com.endava.vehiclerentalapp.entity.Driver;
import com.endava.vehiclerentalapp.entity.DriverBookingDate;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.entity.Vehicle;
import com.endava.vehiclerentalapp.entity.VehicleBookingDate;
import com.endava.vehiclerentalapp.exceptions.CustomerNotFoundException;
import com.endava.vehiclerentalapp.exceptions.DriverNotFoundException;
import com.endava.vehiclerentalapp.exceptions.VehicleNotFoundException;
import com.endava.vehiclerentalapp.mapper.BookingMapper;
import com.endava.vehiclerentalapp.repository.BookingRepository;
import com.endava.vehiclerentalapp.repository.DiscountRepository;
import com.endava.vehiclerentalapp.repository.DriverBookingDateRepository;
import com.endava.vehiclerentalapp.repository.DriverRepository;
import com.endava.vehiclerentalapp.repository.UserRepository;
import com.endava.vehiclerentalapp.repository.VehicleBookingDateRepository;
import com.endava.vehiclerentalapp.repository.VehicleRepository;
import com.endava.vehiclerentalapp.service.BookingService;
import com.endava.vehiclerentalapp.util.Constants;

import jakarta.transaction.Transactional;

/**
 * Service implementation for managing bookings in the vehicle rental system.
 * Provides methods to create, retrieve, update, delete, and check for
 * overlapping bookings.
 */
@Service
public class BookingServiceImpl implements BookingService {

	private final BookingRepository bookingRepository;

	private final UserRepository userRepository;

	private final VehicleRepository vehicleRepository;

	private final DriverRepository driverRepository;

	private final DiscountRepository discountRepository;

	private final VehicleBookingDateRepository vehicleBookingDateRepository;

	private final DriverBookingDateRepository driverBookingDateRepository;

	public BookingServiceImpl(BookingRepository bookingRepository, UserRepository userRepository,
			VehicleRepository vehicleRepository, DriverRepository driverRepository,
			DiscountRepository discountRepository, VehicleBookingDateRepository vehicleBookingDateRepository,
			DriverBookingDateRepository driverBookingDateRepository) {
		this.bookingRepository = bookingRepository;
		this.userRepository = userRepository;
		this.vehicleRepository = vehicleRepository;
		this.driverRepository = driverRepository;
		this.discountRepository = discountRepository;
		this.vehicleBookingDateRepository = vehicleBookingDateRepository;
		this.driverBookingDateRepository = driverBookingDateRepository;
	}

	private double calculateTotalCost(Vehicle vehicle, Driver driver, LocalDate fromDate, LocalDate toDate) {
		Optional<Discount> discountDTO = discountRepository.findHighestDiscountForVehicle(vehicle.getVehicleId());
		double discountPercentage = discountDTO.map(Discount::getDiscountPercentage).orElse(0.0);

		long numberOfDays = java.time.temporal.ChronoUnit.DAYS.between(fromDate, toDate) + 1;

		double totalVehicleCostBeforeDiscount = vehicle.getPricePerDay() * numberOfDays;
		double totalDiscountApplied = totalVehicleCostBeforeDiscount * (discountPercentage / 100);
		double totalDriverCost = (driver != null) ? driver.getDriverCostPerDay() * numberOfDays : 0.0;

		return totalVehicleCostBeforeDiscount + totalDriverCost - totalDiscountApplied;
	}

	private Driver getAvailableDriver(BookingDTO dto) {
		if (dto.getDriverId() != null) {
			return driverRepository.findById(dto.getDriverId())
					.orElseThrow(() -> new DriverNotFoundException(Constants.DRIVER_NOT_FOUND));
		} else {
			List<Driver> availableDrivers = driverRepository.findAvailableDrivers(dto.getFromDate(), dto.getToDate());
			return availableDrivers.isEmpty() ? null : availableDrivers.get(0);
		}
	}

	/**
	 * Creates a new booking, validates available vehicle and driver (if needed),
	 * and saves the booking to the repository.
	 * 
	 * @param dto the data transfer object containing booking details.
	 * @return the created BookingDTO.
	 * @throws CustomerNotFoundException if the customer is not found.
	 * @throws VehicleNotFoundException  if the vehicle is not found.
	 * @throws DriverNotFoundException   if the driver is not found (if required).
	 */
	@Override
	public BookingDTO createBooking(BookingDTO dto) {
		Users customer = userRepository.findById(dto.getCustomerId())
				.orElseThrow(() -> new CustomerNotFoundException(Constants.USER_NOT_FOUND));
		Vehicle vehicle = vehicleRepository.findById(dto.getVehicleId())
				.orElseThrow(() -> new VehicleNotFoundException(Constants.VEHICLE_NOT_FOUND));

		if (bookingRepository.countOverlappingBookings(vehicle.getVehicleId(), dto.getFromDate(),
				dto.getToDate()) > 0) {
			throw new IllegalArgumentException(Constants.VEHICLE_ALREADY_BOOKED);
		}

		dto.setPaymentCompleted(false);
		Driver driver = null;
		if (Boolean.TRUE.equals(dto.getWantsDriver())) {
			driver = getAvailableDriver(dto);
		}

		double totalCost = calculateTotalCost(vehicle, driver, dto.getFromDate(), dto.getToDate());
		Booking booking = BookingMapper.toEntity(dto, customer, vehicle, driver);
		booking.setTotalCost(totalCost);
		booking.setStatus(
				Boolean.TRUE.equals(dto.getPaymentCompleted()) ? BookingStatus.CONFIRMED : BookingStatus.PENDING);

		Booking savedBooking = bookingRepository.save(booking);
		addVehicleBookingDates(savedBooking);
		if (driver != null) {
			addDriverBookingDates(savedBooking, driver);
		}

		return BookingMapper.toDTO(savedBooking);
	}

	/**
	 * Retrieves a booking by its ID.
	 * 
	 * @param bookingId the ID of the booking to retrieve.
	 * @return the BookingDTO for the requested booking.
	 * @throws RuntimeException if the booking with the given ID is not found.
	 */
	@Override
	public BookingDTO getBookingById(Long bookingId) {
		Booking booking = bookingRepository.findById(bookingId)
				.orElseThrow(() -> new RuntimeException(Constants.BOOKING_NOT_FOUND + bookingId));
		return BookingMapper.toDTO(booking);
	}

	/**
	 * Retrieves all bookings associated with a specific customer ID, sorted by
	 * booking date (latest to oldest).
	 * 
	 * @param customerId the ID of the customer for which to retrieve bookings.
	 * @return a list of BookingDTOs associated with the specified customer, sorted
	 *         by booking date.
	 */
	@Override
	public List<BookingDTO> getBookingsByCustomerId(Long customerId) {
		List<Booking> bookings = bookingRepository.findByCustomer_UserId(customerId);
		return bookings.stream().map(BookingMapper::toDTO).toList();
	}

	/**
	 * Retrieves all bookings associated with a specific vehicle ID.
	 * 
	 * @param vehicleId the ID of the vehicle for which to retrieve bookings.
	 * @return a list of BookingDTOs associated with the specified vehicle.
	 * @throws VehicleNotFoundException if no bookings are found for the given
	 *                                  vehicle ID.
	 */
	@Override
	public List<BookingDTO> getBookingsByVehicleId(Long vehicleId) {
		List<Booking> bookings = bookingRepository.findAll().stream()
				.filter(booking -> booking.getVehicle().getVehicleId().equals(vehicleId)).toList();

		if (bookings.isEmpty()) {
			throw new VehicleNotFoundException(Constants.BOOKING_NOT_FOUND + vehicleId);
		}

		return bookings.stream().map(BookingMapper::toDTO).toList();
	}

	/**
	 * Retrieves all bookings in the system.
	 * 
	 * @return a list of all BookingDTOs.
	 */
	@Override
	public List<BookingDTO> getAllBookings() {
		return bookingRepository.findAll().stream().map(BookingMapper::toDTO).toList();
	}

	/**
	 * Updates an existing booking with the provided details.
	 * 
	 * @param bookingId  the ID of the booking to update.
	 * @param bookingDTO the updated booking details.
	 * @return the updated BookingDTO.
	 * @throws RuntimeException if the booking with the given ID is not found.
	 */
	@Override
	@Transactional
	public BookingDTO updateBooking(Long bookingId, BookingDTO bookingDTO) {
		Booking existingBooking = bookingRepository.findById(bookingId)
				.orElseThrow(() -> new RuntimeException(Constants.BOOKING_NOT_FOUND + bookingId));

		existingBooking.setLocation(bookingDTO.getLocation());
		existingBooking.setCustomerAadharNumber(bookingDTO.getCustomerAadharNumber());
		existingBooking.setCustomerDrivingLicenseNumber(bookingDTO.getCustomerDrivingLicenseNumber());
		existingBooking.setFromDate(bookingDTO.getFromDate());
		existingBooking.setToDate(bookingDTO.getToDate());
		existingBooking.setUpdatedAt(LocalDateTime.now());
		existingBooking.setWantsDriver(bookingDTO.getWantsDriver());

		driverBookingDateRepository.deleteByBooking_BookingId(bookingId);
		Driver driver = null;
		if (Boolean.TRUE.equals(bookingDTO.getWantsDriver())) {
			driver = getAvailableDriver(bookingDTO);
		}
		Vehicle vehicle = vehicleRepository.findById(bookingDTO.getVehicleId())
				.orElseThrow(() -> new VehicleNotFoundException(Constants.VEHICLE_NOT_FOUND));

		double totalCost = calculateTotalCost(vehicle, driver, bookingDTO.getFromDate(), bookingDTO.getToDate());
		existingBooking.setVehicle(vehicle);
		existingBooking.setDriver(driver);
		existingBooking.setTotalCost(totalCost);

		if (driver != null) {
			addDriverBookingDates(existingBooking, driver);
		}

		Booking updatedBooking = bookingRepository.save(existingBooking);
		return BookingMapper.toDTO(updatedBooking);
	}

	/**
	 * Deletes a booking by its ID.
	 * 
	 * @param bookingId the ID of the booking to delete.
	 * @throws RuntimeException if the booking with the given ID is not found.
	 */
	@Override
	@Transactional
	public void deleteBooking(Long bookingId) {
		Booking existingBooking = bookingRepository.findById(bookingId)
				.orElseThrow(() -> new RuntimeException(Constants.BOOKING_NOT_FOUND + bookingId));
		Long vehicleId = existingBooking.getVehicle().getVehicleId();
		Long driverId = existingBooking.getDriver() != null ? existingBooking.getDriver().getDriverId() : null;
		vehicleBookingDateRepository.deleteByVehicle_VehicleIdAndBooking_BookingId(vehicleId, bookingId);
		if (driverId != null) {
			driverBookingDateRepository.deleteByDriver_DriverIdAndBooking_BookingId(driverId, bookingId);
		}
		existingBooking.setStatus(BookingStatus.CANCELLED);
		bookingRepository.save(existingBooking);
	}

	/**
	 * Adds booking dates for a vehicle to the VehicleBookingDate table.
	 *
	 * @param booking The booking entity.
	 */
	private void addVehicleBookingDates(Booking booking) {
		LocalDate startDate = booking.getFromDate();
		LocalDate endDate = booking.getToDate();
		while (!startDate.isAfter(endDate)) {
			VehicleBookingDate vehicleBookingDate = new VehicleBookingDate();
			vehicleBookingDate.setBookedDate(startDate);
			vehicleBookingDate.setVehicle(booking.getVehicle());
			vehicleBookingDate.setBooking(booking);
			vehicleBookingDateRepository.save(vehicleBookingDate);
			startDate = startDate.plusDays(1);
		}
	}

	/**
	 * Adds booking dates for a driver to the DriverBookingDate table.
	 *
	 * @param booking The booking entity.
	 * @param driver  The driver entity.
	 */
	private void addDriverBookingDates(Booking booking, Driver driver) {
		LocalDate startDate = booking.getFromDate();
		LocalDate endDate = booking.getToDate();
		while (!startDate.isAfter(endDate)) {
			DriverBookingDate driverBookingDate = new DriverBookingDate();
			driverBookingDate.setBookingDate(startDate);
			driverBookingDate.setDriver(driver);
			driverBookingDate.setBooking(booking);
			driverBookingDateRepository.save(driverBookingDate);
			startDate = startDate.plusDays(1);
		}
	}

	/**
	 * Retrieves all vehicles available within the given date range.
	 * 
	 * @param fromDate The start date of the availability period.
	 * @param toDate   The end date of the availability period.
	 * @return A list of `VehicleDTO` objects representing available vehicles.
	 */
	@Override
	public List<VehicleDTO> getAvailableVehiclesBetweenDates(LocalDate fromDate, LocalDate toDate) {
		List<Vehicle> allVehicles = vehicleRepository.findByIsDeletedFalse();
		List<VehicleBookingDate> allBookingDates = vehicleBookingDateRepository.findAll();
		return allVehicles.stream()
				.filter(vehicle -> allBookingDates.stream()
						.filter(vehicleBookingDate -> vehicleBookingDate.getVehicle().equals(vehicle))
						.noneMatch(vehicleBookingDate -> !vehicleBookingDate.getBookedDate().isBefore(fromDate)
								&& !vehicleBookingDate.getBookedDate().isAfter(toDate)))
				.map(BookingMapper::toVehicleDto).toList();
	}

	/**
	 * Retrieves the total number of confirmed bookings.
	 *
	 * @return the count of bookings with status CONFIRMED.
	 */
	@Override
	public long getTotalBookings() {
		return bookingRepository.countByStatus(BookingStatus.CONFIRMED);
	}

	/**
	 * Retrieves the total earnings from all bookings.
	 *
	 * @return the total earnings as a long value.
	 */
	@Override
	public long getTotalEarnings() {
		return bookingRepository.getTotalEarnings();
	}

	/**
	 * Retrieves earnings grouped by vehicle category type.
	 *
	 * @return a list of objects representing earnings categorized by vehicle type.
	 */
	@Override
	public List<Object[]> getEarningsByCategoryType() {
		return bookingRepository.getEarningsByCategoryType();
	}

	/**
	 * Retrieves the booking count grouped by vehicle category type.
	 *
	 * @return a list of objects representing the count of bookings per vehicle
	 *         category.
	 */
	@Override
	public List<Object[]> getBookingCountByCategoryType() {
		return bookingRepository.getBookingCountByCategoryType();
	}

}
