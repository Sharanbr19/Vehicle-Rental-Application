package com.endava.vehiclerentalapp.service.implementation;

import com.endava.vehiclerentalapp.dto.PaymentDTO;
import com.endava.vehiclerentalapp.entity.Booking;
import com.endava.vehiclerentalapp.entity.BookingStatus;
import com.endava.vehiclerentalapp.entity.Payment;
import com.endava.vehiclerentalapp.exceptions.NoPaymentFoundException;
import com.endava.vehiclerentalapp.mapper.PaymentMapper;
import com.endava.vehiclerentalapp.repository.BookingRepository;
import com.endava.vehiclerentalapp.repository.PaymentRepository;
import com.endava.vehiclerentalapp.service.PaymentService;
import com.endava.vehiclerentalapp.util.Constants;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import jakarta.annotation.PostConstruct;
import jakarta.mail.MessagingException;
import java.util.List;

/**
 * Service implementation for handling payment operations.
 * Integrates with Razorpay to process transactions and manages payments related to bookings.
 */
@Service
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;

    private final PaymentMapper paymentMapper;

    private final BookingRepository bookingRepository;

    private final MailService mailService;

	private RazorpayClient razorpayClient;

    @Value("${razorpay.key.id}")
    private String razorpayKeyId;

    @Value("${razorpay.key.secret}")
    private String razorpayKeySecret;

    /**
     * Constructor for PaymentServiceImpl.
     *
     * @param paymentRepository  Repository for Payment entities.
     * @param paymentMapper      Mapper for converting Payment entities to DTOs and vice versa.
     * @param bookingRepository  Repository for Booking entities.
     */
    public PaymentServiceImpl(PaymentRepository paymentRepository, PaymentMapper paymentMapper, BookingRepository bookingRepository, MailService mailService) {
        this.paymentRepository = paymentRepository;
        this.paymentMapper = paymentMapper;
        this.bookingRepository = bookingRepository;
        this.mailService = mailService;
    }

    /**
     * Initializes the Razorpay client using API credentials.
     *
     * @throws RazorpayException if there is an error initializing the Razorpay client.
     */
    @PostConstruct
    public void init() throws RazorpayException {
        this.razorpayClient = new RazorpayClient(razorpayKeyId, razorpayKeySecret);
    }

    /**
     * Retrieves a payment by its ID.
     *
     * @param id the ID of the payment.
     * @return the payment details as a DTO.
     * @throws NoPaymentFoundException if no payment is found with the given ID.
     */
    @Override
    public PaymentDTO getPaymentById(Long id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new NoPaymentFoundException(Constants.NO_PAYMENT_FOUND + id));
        return paymentMapper.toDTO(payment);
    }

    /**
     * Retrieves a list of all payments.
     *
     * @return a list of PaymentDTO objects.
     * @throws NoPaymentFoundException if there are no payments available.
     */
    @Override
    public List<PaymentDTO> getAllPayments() {
        List<Payment> payments = paymentRepository.findAll();
        if (payments.isEmpty()) {
            throw new NoPaymentFoundException(Constants.NO_PAYMENT_FOUND);
        }
        return payments.stream().map(paymentMapper::toDTO).toList();
    }

    /**
     * Creates a new payment for a given booking using Razorpay.
     *
     * @param paymentDTO the payment details.
     * @return a success message with the Razorpay order ID.
     * @throws RazorpayException if there is an error creating the payment order.
     * @throws IllegalArgumentException if the associated booking is not found.
     */
    @Override
    public String createPayment(PaymentDTO paymentDTO) throws RazorpayException {
        Booking booking = bookingRepository.findById(paymentDTO.getBookingId())
                .orElseThrow(() -> new IllegalArgumentException(Constants.BOOKING_NOT_FOUND + paymentDTO.getBookingId()));

        JSONObject options = new JSONObject();
        long amountInPaise = Math.round(paymentDTO.getAmount() * 100);
        options.put("amount", amountInPaise);
        options.put("currency", "INR");
        options.put("receipt", "txn_" + System.currentTimeMillis());

        Order razorpayOrder = razorpayClient.orders.create(options);

        if (razorpayOrder != null) {
            Payment payment = paymentMapper.toEntity(paymentDTO, booking);
            payment.setRazorPayId(razorpayOrder.get("id"));
            booking.setPaymentCompleted(true);
            booking.setStatus(BookingStatus.CONFIRMED);
            bookingRepository.save(booking);
            paymentRepository.save(payment);
            String emailContent = Constants.BOOKING_SUCCESS_EMAIL_BODY
                    .replace("{customerName}", booking.getCustomer().getName())
                    .replace("{bookingDate}", payment.getPaymentDateAndTime().toString())
                    .replace("{vehicleModel}", booking.getVehicle().getModelName())
                    .replace("{vehicleCategory}", booking.getVehicle().getCategoryType())
                    .replace("{rentalPeriod}", booking.getFromDate() + " to " + booking.getToDate())
                    .replace("{totalAmount}", String.valueOf(booking.getTotalCost()))
                    .replace("{paymentId}", payment.getRazorPayId())
            .replace("{location}", booking.getLocation() != null ? booking.getLocation() : "N/A");

            if (booking.getDriver() != null) {
                emailContent = emailContent.replace("{driverName}", booking.getDriver().getName())
                                           .replace("{driverContact}", booking.getDriver().getContactNumber());
            } else {
                emailContent = emailContent.replace("{driverName}", "N/A")
                                           .replace("{driverContact}", "");
            }
            try {
				mailService.sendHtmlEmail(booking.getCustomer().getEmail(), Constants.BOOKING_SUCCESS_EMAIL_SUBJECT, emailContent);
			} catch (MessagingException e) {
				e.printStackTrace();
			}
            return Constants.PAYMENT_CREATED_SUCCESSFULLY + razorpayOrder.get("id");
        }
        throw new RazorpayException(Constants.FAILED_TO_CREATE_RAZORPAY_ORDER);
    }

    /**
     * Updates an existing payment record.
     *
     * @param id the ID of the payment to be updated.
     * @param paymentDTO the updated payment details.
     * @return a success message indicating the payment was updated.
     * @throws NoPaymentFoundException if no payment is found with the given ID.
     */
    @Override
    public String updatePayment(Long id, PaymentDTO paymentDTO) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new NoPaymentFoundException(Constants.NO_PAYMENT_FOUND + id));

        payment.setAmount(paymentDTO.getAmount());
        payment.setPaymentDateAndTime(paymentDTO.getPaymentDateAndTime());
        paymentRepository.save(payment);

        return Constants.PAYMENT_UPDATED_SUCCESSFULLY;
    }

    /**
     * Deletes a payment by its ID.
     *
     * @param id the ID of the payment to be deleted.
     * @return a success message indicating the payment was deleted.
     * @throws NoPaymentFoundException if no payment is found with the given ID.
     */
    @Override
    public String deletePayment(Long id) {
        Payment payment = paymentRepository.findByPaymentId(id)
                .orElseThrow(() -> new NoPaymentFoundException(Constants.NO_PAYMENT_FOUND + id));

        paymentRepository.delete(payment);

        return Constants.PAYMENT_DELETED_SUCCESSFULLY;
    }
}
