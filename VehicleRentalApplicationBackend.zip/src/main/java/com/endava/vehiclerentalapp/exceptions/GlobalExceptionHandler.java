package com.endava.vehiclerentalapp.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.endava.vehiclerentalapp.util.Constants;

/**
 * GlobalExceptionHandler is a central exception handler for the application,
 * responsible for catching and managing various custom exceptions.
 * This class uses Spring's @ControllerAdvice to handle exceptions globally
 * across all controllers, providing meaningful error messages and proper HTTP status codes.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Handles the case when a UserAlreadyExistsException is thrown.
     *
     * @param ex the UserAlreadyExistsException instance
     * @return a ResponseEntity with a conflict status and the exception message
     */
    @ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<String> handleUserAlreadyExists(UserAlreadyExistsException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(ex.getMessage());
    }

    /**
     * Handles the case when a VehicleNotFoundException is thrown.
     *
     * @param ex the VehicleNotFoundException instance
     * @return a ResponseEntity with a not found status and the exception message
     */
    @ExceptionHandler(VehicleNotFoundException.class)
    public ResponseEntity<String> handleVehicleNotFound(VehicleNotFoundException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    /**
     * Handles the case when a CustomerNotFoundException is thrown.
     *
     * @param ex the CustomerNotFoundException instance
     * @return a ResponseEntity with a not found status and the exception message
     */
    @ExceptionHandler(CustomerNotFoundException.class)
    public ResponseEntity<String> handleCustomerNotFound(CustomerNotFoundException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    /**
     * Handles the case when a FavoriteNotFoundException is thrown.
     *
     * @param ex the FavoriteNotFoundException instance
     * @return a ResponseEntity with a not found status and the exception message
     */
    @ExceptionHandler(FavoriteNotFoundException.class)
    public ResponseEntity<String> handleFavoriteNotFound(FavoriteNotFoundException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    /**
     * Handles the case when a NoPaymentFoundException is thrown.
     *
     * @param ex the NoPaymentFoundException instance
     * @return a ResponseEntity with a not found status and the exception message
     */
    @ExceptionHandler(NoPaymentFoundException.class)
    public ResponseEntity<String> handleNoPaymentFound(NoPaymentFoundException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    /**
     * Handles the case when a DriverNotFoundException is thrown.
     *
     * @param ex the DriverNotFoundException instance
     * @return a ResponseEntity with a not found status and the exception message
     */
    @ExceptionHandler(DriverNotFoundException.class)
    public ResponseEntity<String> handleDriverNotFound(DriverNotFoundException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }
    
    /**
     * Handles the case when a DiscountNotFoundException is thrown.
     *
     * @param ex the DiscountNotFoundException instance
     * @return a ResponseEntity with a not found status and the exception message
     */
    @ExceptionHandler(DiscountNotFoundException.class)
    public ResponseEntity<String> handleDiscountNotFound(DiscountNotFoundException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    /**
     * Handles the case when a FavoriteAlreadyExistsException is thrown.
     *
     * @param ex the FavoriteAlreadyExistsException instance
     * @return a ResponseEntity with a conflict status and the exception message
     */
    @ExceptionHandler(FavoriteAlreadyExistsException.class)
    public ResponseEntity<String> handleFavoriteAlreadyExist(FavoriteAlreadyExistsException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.CONFLICT);
    }
    
    /**
     * Handles the case when a ExcelParsingFailedException is thrown.
     *
     * @param ex the ExcelParsingFailedException instance
     * @return a ResponseEntity with a conflict status and the exception message
     */
    @ExceptionHandler(ExcelParsingFailedException.class)
    public ResponseEntity<String> handleExcelParsingFailure(ExcelParsingFailedException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.CONFLICT);
    }

    /**
     * Handles any general exception that does not have a specific handler.
     *
     * @param ex the general Exception instance
     * @return a ResponseEntity with an internal server error status and a generic error message
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGeneralException(Exception ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Constants.AN_ERROR_OCCURRED);
    }
}
