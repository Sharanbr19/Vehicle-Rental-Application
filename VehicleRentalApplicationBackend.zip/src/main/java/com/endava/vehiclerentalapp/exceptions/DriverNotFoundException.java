package com.endava.vehiclerentalapp.exceptions;

@SuppressWarnings("serial")
public class DriverNotFoundException extends RuntimeException {
	public DriverNotFoundException(String message) {
		super(message);
	}
}
