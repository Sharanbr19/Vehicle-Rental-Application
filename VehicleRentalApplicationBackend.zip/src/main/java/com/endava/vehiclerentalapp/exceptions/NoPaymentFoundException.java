package com.endava.vehiclerentalapp.exceptions;

@SuppressWarnings("serial")
public class NoPaymentFoundException extends RuntimeException {
	public NoPaymentFoundException(String message) {
		super(message);
	}
	public NoPaymentFoundException(String message, Throwable cause) {
		super(message, cause);
	}
}
