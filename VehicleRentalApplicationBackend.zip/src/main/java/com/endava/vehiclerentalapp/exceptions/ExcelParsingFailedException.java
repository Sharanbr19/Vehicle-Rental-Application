package com.endava.vehiclerentalapp.exceptions;

import java.io.IOException;

@SuppressWarnings("serial")
public class ExcelParsingFailedException extends RuntimeException {
	public ExcelParsingFailedException(String message,IOException e) {
		super(message,e);
	}
}
