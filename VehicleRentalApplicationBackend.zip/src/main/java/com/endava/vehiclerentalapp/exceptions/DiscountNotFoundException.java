package com.endava.vehiclerentalapp.exceptions;

@SuppressWarnings("serial")
public class DiscountNotFoundException extends RuntimeException {
	public DiscountNotFoundException(String message) {
		super(message);
	}
}

