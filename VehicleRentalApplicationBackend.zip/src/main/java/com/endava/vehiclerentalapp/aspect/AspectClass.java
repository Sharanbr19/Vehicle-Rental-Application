package com.endava.vehiclerentalapp.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Aspect
@Component
public class AspectClass {

    @Pointcut("execution(* com.endava.vehiclerentalapp.controller.*.*(..))")
    public void controllerMethods() {}

    @Pointcut("execution(* com.endava.vehiclerentalapp.service.implementation.*.*(..))")
    public void serviceMethods() {}

    @Pointcut("execution(* com.endava.vehiclerentalapp.security.*.*(..))")
    public void securityMethods() {}

    @Around("controllerMethods()")
    public Object logAroundMethodExecution(ProceedingJoinPoint joinPoint) throws Throwable {
        log.info(String.format("%s:: %s() - Controller Started", 
                joinPoint.getTarget().getClass().getSimpleName(),
                joinPoint.getSignature().getName()));
        Object result = joinPoint.proceed();
        log.info(String.format("%s:: %s() - Controller Ended", 
                joinPoint.getTarget().getClass().getSimpleName(),
                joinPoint.getSignature().getName()));
        return result;
    }

    @AfterThrowing(pointcut = "controllerMethods()", throwing = "error")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable error) {
        log.error(String.format("%s:: %s() - %s - Error logged in controller layer", 
                joinPoint.getTarget().getClass().getSimpleName(),
                joinPoint.getSignature().getName(), 
                error.getMessage()), error);
    }

    @Around("serviceMethods()")
    public Object logAroundServiceMethodExecution(ProceedingJoinPoint joinPoint) throws Throwable {
        log.info(String.format("%s:: %s() - Service Method Started", 
                joinPoint.getTarget().getClass().getSimpleName(),
                joinPoint.getSignature().getName()));
        Object result = joinPoint.proceed();
        log.info(String.format("%s:: %s() - Service Method Ended", 
                joinPoint.getTarget().getClass().getSimpleName(),
                joinPoint.getSignature().getName()));
        return result;
    }

    @AfterThrowing(pointcut = "serviceMethods()", throwing = "error")
    public void logAfterServiceThrowing(JoinPoint joinPoint, Throwable error) {
        log.error(String.format("%s:: %s() - %s - Error logged in service layer", 
                joinPoint.getTarget().getClass().getSimpleName(),
                joinPoint.getSignature().getName(), 
                error.getMessage()), error);
    }

    @Around("securityMethods()")
    public Object logAroundSecurityMethodExecution(ProceedingJoinPoint joinPoint) throws Throwable {
        log.info(String.format("%s:: %s() - Security Filter Started", 
                joinPoint.getTarget().getClass().getSimpleName(),
                joinPoint.getSignature().getName()));
        Object result = joinPoint.proceed();
        log.info(String.format("%s:: %s() - Security Filter Ended", 
                joinPoint.getTarget().getClass().getSimpleName(),
                joinPoint.getSignature().getName()));
        return result;
    }

    @AfterThrowing(pointcut = "securityMethods()", throwing = "error")
    public void logAfterSecurityThrowing(JoinPoint joinPoint, Throwable error) {
        log.error(String.format("%s:: %s() - %s - Error logged in security layer", 
                joinPoint.getTarget().getClass().getSimpleName(),
                joinPoint.getSignature().getName(), 
                error.getMessage()), error);
    }
}
