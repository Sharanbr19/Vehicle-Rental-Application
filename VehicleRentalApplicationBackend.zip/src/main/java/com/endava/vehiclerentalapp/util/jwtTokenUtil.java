package com.endava.vehiclerentalapp.util;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import java.security.Key;
import java.util.Date;

/**
 * Utility class for working with JSON Web Tokens (JWT).
 * 
 * This class provides methods to generate, validate, and extract information
 * from JWT tokens. It uses the HS256 signing algorithm with a secure 256-bit
 * key to sign the tokens. The token contains user-related information such as
 * email (subject) and role (claim). Tokens are set to expire after 1 hour.
 */
public class jwtTokenUtil {

	private static final Key SECRET_KEY = Keys.secretKeyFor(SignatureAlgorithm.HS256);

	/**
	 * Generates a JWT token with the specified email (subject) and user role
	 * (claim).
	 * 
	 * @param email    the email of the user (subject) to be included in the token
	 * @param userRole the role of the user to be included as a claim in the token
	 * @return a signed JWT token as a String
	 */
	public static String generateToken(String email, String userRole) {
		long expirationTime = 1000L * 60 * 60;

		return Jwts.builder().setSubject(email).claim("role", userRole).setIssuedAt(new Date())
				.setExpiration(new Date(System.currentTimeMillis() + expirationTime)).signWith(SECRET_KEY).compact();
	}

	/**
	 * Validates a JWT token.
	 * 
	 * @param token the JWT token to validate
	 * @return true if the token is valid, false otherwise
	 */
	public static boolean validateToken(String token) {
		try {
			Jwts.parserBuilder().setSigningKey(SECRET_KEY).build().parseClaimsJws(token);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Extracts the email (subject) from a JWT token.
	 * 
	 * @param token the JWT token to extract the email from
	 * @return the email contained in the token
	 */
	public static String extractEmail(String token) {
		return Jwts.parserBuilder().setSigningKey(SECRET_KEY).build().parseClaimsJws(token).getBody().getSubject();
	}
}
