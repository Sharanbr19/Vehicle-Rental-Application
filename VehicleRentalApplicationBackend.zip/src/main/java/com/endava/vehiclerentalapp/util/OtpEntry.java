package com.endava.vehiclerentalapp.util;

import java.time.LocalDateTime;

/**
 * Represents an OTP (One-Time Password) with its value and expiration time.
 * Provides a method to check if the OTP has expired.
 */
public class OtpEntry {
	private String otp;
	private LocalDateTime expirationTime;

	/**
	 * Creates an OtpEntry with the given OTP value and expiration time.
	 *
	 * @param otp            the OTP value
	 * @param expirationTime the time when the OTP expires
	 */
	public OtpEntry(String otp, LocalDateTime expirationTime) {
		this.otp = otp;
		this.expirationTime = expirationTime;
	}

	/**
	 * Gets the OTP value.
	 * 
	 * @return the OTP value
	 */
	public String getOtp() {
		return otp;
	}

	/**
	 * Gets the expiration time of the OTP.
	 * 
	 * @return the expiration time
	 */
	public LocalDateTime getExpirationTime() {
		return expirationTime;
	}

	/**
	 * Checks if the OTP has expired.
	 * 
	 * @return true if the OTP is expired, false otherwise
	 */
	public boolean isExpired() {
		return LocalDateTime.now().isAfter(expirationTime) || LocalDateTime.now().isEqual(expirationTime);
	}
}
