package com.endava.vehiclerentalapp.util;

public class Constants {
	public static final String ADMIN_NOT_FOUND = "Admin not found with ID: ";
	public static final String VEHICLE_NOT_FOUND = "Vehicle not found with ID: ";
	public static final String VEHICLE_NOT_FOUND_CATEGORY = "Vehicle not found for given category ";
	public static final String INVALID_SORT_ATTRIBUTE = "Invalid sort attribute: ";
	public static final String TWO_VEHICLES_REQUIRED = "Exactly two vehicle IDs are required for comparison.";
	public static final String BOTH_VEHICLES_MUST_EXIST = "Both vehicles must exist for comparison.";
	public static final String UNSUPPORTED_ATTRIBUTE = "Unsupported attribute for comparison: ";
	public static final String ADMIN_DEFAULT = "Admin";
	public static final String NO_DIFFERENCE = "No Difference";
	public static final String DIFFERENT = "Different";
	public static final String EMAIL_ALREADY_TAKEN = "Email is already taken.";
	public static final String EMAIL_AVAILABLE = "Email is available.";
	public static final String MESSAGE = "message";
	public static final String USER_REGISTERED_SUCCESSFULLY = "User registered successfully";
	public static final String INVALID_CREDENTIALS = "Invalid credentials";
	public static final String USER_NOT_FOUND = "User not found";
	public static final String BOOKING_NOT_FOUND = "Booking not found";
	public static final String USER_UPDATED_SUCCESSFULLY = "User updated successfully";
	public static final String USER_DELETED_SUCCESSFULLY = "User deleted successfully";
	public static final String PASSWORD_RESET_OTP = "Password Reset OTP";
	public static final String USER_DOESNOT_EXIST = "User with the provided email does not exist.";
	public static final String OTP_SENT_TO_MAIL = "OTP sent to your email.";
	public static final String INVALID_OTP = "Invalid or expired OTP.";
	public static final String PASSWORD_REST_SUCCESSFUL = "Password reset successful.";
	public static final String OTP_VERIFIED_SUCCESSFULLY = "OTP verified successfully.";
	public static final String OTP_SENT_SUCCESSFULLY = "OTP sent successfully.";
	public static final String EMAIL_VERIFICATION_OTP = "OTP sent successfully.";
	public static final String AN_ERROR_OCCURRED = "An error occured";
	public static final String CANNOT_DELETE_DRIVER = "Cannot delete driver because it is already booked for a future date";
	public static final String CANNOT_DELETE_VEHICLE = "Cannot delete vehicle because it is already booked for a future date";
	public static final String USER_ALREADY_REVIEWED = "User has already reviewed this vehicle";
	public static final String REVIEW_NOT_FOUND = "Review not found for this user and vehicle";
	public static final String RENTAL_AGREEMENT_NOT_FOUND = "Rental Agreement not found";
	public static final String NO_PAYMENT_FOUND = "No payment found with id ";
	public static final String FAILED_TO_CREATE_RAZORPAY_ORDER = "Failed to create Razorpay order";
	public static final String PAYMENT_CREATED_SUCCESSFULLY = "Payment created successfully with order ID: ";
	public static final String PAYMENT_UPDATED_SUCCESSFULLY = "Payment updated successfully";
	public static final String PAYMENT_DELETED_SUCCESSFULLY = "Payment deleted successfully";
	public static final String ADMIN_EMAIL = "rentwheels001@gmail.com";
	public static final String INVOICE_NOT_FOUND = "Invoice not found";
	public static final String FAVORITE_NOT_FOUND = "Favorite not found for User ID: ";
	public static final String FAVORITE_ALREADY_EXIST = "Favorite already exists for User ID: ";
	public static final String DRIVER_NOT_FOUND = "Driver not found with id ";
	public static final String DRIVER_ALREADY_BOOKED = "This Driver is already booked for the selected dates.";
	public static final String VEHICLE_ALREADY_BOOKED = "This vehicle is already booked for the selected dates.";
	public static final String DISCOUNT_NOT_FOUND = "Discount not found";
	public static final String EXCEL_PARSE_FAILED = "Failed to parse excel file";

	public static final String VEHICLE_MODEL_NAME = "modelName";
	public static final String VEHICLE_CATEGORY_TYPE = "categoryType";
	public static final String VEHICLE_FUEL_TYPE = "fuelType";
	public static final String VEHICLE_COLOR = "color";
	public static final String VEHICLE_MODEL_YEAR = "modelYear";
	public static final String VEHICLE_PRICE_PER_DAY = "pricePerDay";
	public static final String VEHICLE_MILEAGE = "mileage";

	public static final String OTP_EMAIL_TEMPLATE = """
			<html>
			<body>
			<p>Dear Customer,</p>
			<p>Please use the following One-Time Password (OTP) to verify your email address and complete your registration:</p>
			<h2 style='color: #006400; font-family: Arial, sans-serif; font-size: 24px;'>{otp}</h2>
			<p>If you did not request this OTP, please ignore this email or contact our support team immediately.</p>
			<p>Best regards,<br/>
			Rent Wheels Team</p>
			</body>
			</html>
			""";

	public static final String OTP_EMAIL_FORGOT_PASSWORD = """
			<html>
			<body>
			<p>Dear Customer,</p>
			<p>Please use the following One-Time Password (OTP) to reset your password:</p>
			<h2 style='color: #006400; font-family: Arial, sans-serif; font-size: 24px;'>{otp}</h2>
			<p>If you did not request this OTP, please ignore this email or contact our support team immediately.</p>
			<p>Best regards,<br/>
			Rent Wheels Team</p>
			</body>
			</html>
			""";

	public static final String BOOKING_SUCCESS_EMAIL_SUBJECT = "Vehicle Rental Booking Successful";

	public static final String BOOKING_SUCCESS_EMAIL_BODY = """
			<html>
			<body>
			<p>Dear {customerName},</p>
			<p>Thank you for choosing Rent Wheels. We are pleased to confirm your booking. Below are your booking details:</p>
			<table border='1' cellspacing='0' cellpadding='5' style='text-align: left;'>
			  <tr>
			    <th>Booking Date</th><td>{bookingDate}</td>
			  </tr>
			  <tr>
			    <th>Vehicle</th><td>{vehicleModel} - {vehicleCategory}</td>
			  </tr>
			  <tr>
			    <th>Rental Period</th><td>{rentalPeriod}</td>
			  </tr>
			  <tr>
			    <th>Location</th><td>{location}</td>
			  </tr>
			  <tr>
			    <th>Driver</th><td>{driverName} - {driverContact}</td>
			  </tr>
			  <tr>
			    <th>Total Amount</th><td>{totalAmount}</td>
			  </tr>
			</table>
			<p>Your payment has been successfully processed with Payment ID: {paymentId}.</p>
			<p>If you have any questions or need further assistance, please contact our support team.</p>
			<p>Thank you for choosing Rent Wheels!</p>
			<p>Best regards,<br/>Rent Wheels Team</p>
			</body>
			</html>
			""";
}