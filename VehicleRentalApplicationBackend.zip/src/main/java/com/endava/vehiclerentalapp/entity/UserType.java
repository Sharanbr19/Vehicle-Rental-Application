package com.endava.vehiclerentalapp.entity;

/**
 * Enum representing the types of users in the Vehicle Rental Application.
 * 
 * This enum distinguishes between two types of users: 
 * ADMIN, who manages the system, and CUSTOMER, who rents vehicles.
 */
public enum UserType {
    ADMIN, CUSTOMER
}
