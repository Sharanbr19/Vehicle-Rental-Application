package com.endava.vehiclerentalapp.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;

/**
 * Entity class representing a booking date for a vehicle.
 */
@Entity
@Data
public class VehicleBookingDate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long vehicleBookingDateId;

    private LocalDate bookedDate;

    @ManyToOne
    @JoinColumn(name = "vehicle_id")
    private Vehicle vehicle;

    @ManyToOne
    @JoinColumn(name = "booking_id")
    private Booking booking; 
}
