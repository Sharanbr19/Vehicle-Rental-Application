package com.endava.vehiclerentalapp.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

/**
 * Entity class representing booking dates for drivers in the Vehicle Rental Application.
 */
@Entity
@Data
public class DriverBookingDate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate bookingDate;

    @ManyToOne
    @JoinColumn(name = "driver_id")
    private Driver driver; 

    @ManyToOne
    @JoinColumn(name = "booking_id")
    private Booking booking; 
}
