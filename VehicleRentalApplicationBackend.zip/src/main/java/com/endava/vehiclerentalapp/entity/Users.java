//package com.endava.vehiclerentalapp.entity;
//
//import jakarta.persistence.*;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//
///**
// * Entity class representing a user in the Vehicle Rental Application.
// * 
// * This class maps to the `users` table in the database and contains information 
// * about the user, including personal details, user type, and timestamps for creation and updates.
// * The `userType` field distinguishes between different types of users (Customer, Admin).
// */
//@Entity
//@Data
//@Table(name = "users")
//@NoArgsConstructor
//public class Users {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long userId;
//
//    @Column(unique = true, nullable = false)
//    private String email;
//
//    private String password;
//
//    private String name;
//    private LocalDate dateOfBirth;  
//    private String gender;
//    private String contactNumber;
//    private String nationality; 
//    private String address;
//
//    @Enumerated(EnumType.STRING)
//    private UserType userType;
//
//    private LocalDateTime createdAt;
//    private LocalDateTime updatedAt;
//}

package com.endava.vehiclerentalapp.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Entity class representing a user in the Vehicle Rental Application.
 * 
 * This class maps to the `users` table in the database and contains information 
 * about the user, including personal details, user type, timestamps for creation and updates.
 * The `userType` field distinguishes between different types of users (Customer, Admin).
 */
@Entity
@Data
@Table(name = "users")
@NoArgsConstructor
public class Users {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @Column(unique = true)
    private String email;

    private String password;

    private String name;
    private LocalDate dateOfBirth;
    private String gender;
    private String contactNumber;
    private String address;

    @Enumerated(EnumType.STRING)
    private UserType userType;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @Column(name = "created_by", nullable = true)
    private String createdBy;

    @Column(name = "updated_by", nullable = true)
    private String updatedBy;

    @Column(name = "is_deleted", nullable = false)
    private boolean isDeleted = false; 

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
