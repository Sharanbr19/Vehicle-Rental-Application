package com.endava.vehiclerentalapp.entity;

import jakarta.persistence.*;
import lombok.Data;

/**
 * Entity class representing a review in the Vehicle Rental Application.
 */
@Entity
@Table(
    name = "review",
    uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "vehicle_id"})
)
@Data
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reviewId;

    private String rating;
    private String comment;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private Users customer; 

    @ManyToOne
    @JoinColumn(name = "vehicle_id", nullable = false)
    private Vehicle vehicle;
}
