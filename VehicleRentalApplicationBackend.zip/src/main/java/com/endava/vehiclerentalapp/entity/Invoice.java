package com.endava.vehiclerentalapp.entity;

import jakarta.persistence.*;
import lombok.Data;

/**
 * Entity class representing an invoice in the Vehicle Rental Application.
 * 
 * This class maps to the `invoice` table in the database and contains details about 
 * the invoice, including the date, total amount, and the associated booking. 
 * Each invoice is linked to a specific booking.
 */
@Entity
@Data
public class Invoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long invoiceId;

    private String invoiceDate;
    private Double totalAmount;

    @OneToOne
    @JoinColumn(name = "booking_id")
    private Booking booking;
}

