package com.endava.vehiclerentalapp.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import lombok.Data;

/**
 * Entity class representing a payment in the Vehicle Rental Application.
 * 
 * This class maps to the `payment` table in the database and captures details about 
 * the payment, including the amount and payment date, as well as the associated booking. 
 * Each payment is linked to a specific booking.
 */
@Entity
@Data
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long paymentId;

    private Double amount;
    private LocalDateTime paymentDateAndTime;
    
    private String razorPayId;
    
    @OneToOne
    @JoinColumn(name = "booking_id")
    private Booking booking;
}

