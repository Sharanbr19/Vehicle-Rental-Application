package com.endava.vehiclerentalapp.entity;

/**
 * Enum representing the possible statuses of a booking in the vehicle rental system.
 * The statuses are as follows:
 * - PENDING: The booking has been created but not yet confirmed.
 * - CONFIRMED: The booking has been confirmed and is ready for processing.
 * - CANCELLED: The booking has been cancelled by the customer or system.
 */
public enum BookingStatus {
    PENDING, 
    CONFIRMED, 
    CANCELLED 
}
