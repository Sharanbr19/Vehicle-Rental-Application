package com.endava.vehiclerentalapp.entity;

import jakarta.persistence.*;
import lombok.Data;

/**
 * Entity class representing a rental agreement in the Vehicle Rental Application.
 * 
 * This class maps to the `rental_agreement` table in the database and contains details 
 * about the rental agreement, including the agreement date and terms & conditions, 
 * as well as the associated booking. Each rental agreement is linked to a specific booking.
 */
@Entity
@Data
public class RentalAgreement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rentalId;

    private String agreementDate;
    
    @Lob
    @Column(columnDefinition = "TEXT")
    private String termsAndConditions;

    @OneToOne
    @JoinColumn(name = "booking_id")
    private Booking booking;
}

