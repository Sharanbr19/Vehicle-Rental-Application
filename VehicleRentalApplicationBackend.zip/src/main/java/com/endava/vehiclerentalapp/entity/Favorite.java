package com.endava.vehiclerentalapp.entity;

import jakarta.persistence.*;
import lombok.Data;

/**
 * Entity class representing a favorite in the Vehicle Rental Application.
 * 
 * This class maps to the `favorite` table in the database and is used to track 
 * the vehicles marked as favorites by customers. It establishes relationships 
 * between the customer and their favorite vehicles.
 */
@Entity
@Data
public class Favorite {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long favoriteId;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private Users customer; 

    @ManyToOne
    @JoinColumn(name = "vehicle_id")
    private Vehicle vehicle;
}
