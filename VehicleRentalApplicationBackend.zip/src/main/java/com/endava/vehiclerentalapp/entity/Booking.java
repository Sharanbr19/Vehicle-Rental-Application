package com.endava.vehiclerentalapp.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * Entity representing a vehicle booking in the rental system.
 * This class stores information about a booking made by a customer,
 * including the location, rental period, vehicle, driver, and payment status.
 * It also defines relationships with other entities like `Users`, `Vehicle`, and `Driver`.
 * 
 * The `Booking` entity is mapped to a database table and is responsible for storing the
 * details of each booking in the system.
 */
@Entity
@Data
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookingId;

    private String location;
    private LocalDate fromDate;
    private LocalDate toDate;
    private Double totalCost;
    private String customerAadharNumber;
    private String customerDrivingLicenseNumber;
    private Boolean wantsDriver;

    @Enumerated(EnumType.STRING)
    private BookingStatus status;

    private Boolean paymentCompleted = false;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private Users customer;

    @ManyToOne
    @JoinColumn(name = "vehicle_id")
    private Vehicle vehicle;

    @CreationTimestamp
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
    
    @ManyToOne
    @JoinColumn(name = "driver_id", nullable = true)
    private Driver driver;

    public boolean isAvailableBetween(LocalDate fromDate, LocalDate toDate) {
        return !(this.fromDate.isBefore(toDate) && this.toDate.isAfter(fromDate));
    }
}
