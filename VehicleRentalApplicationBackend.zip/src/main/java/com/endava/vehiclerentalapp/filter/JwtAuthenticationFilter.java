package com.endava.vehiclerentalapp.filter;

import java.io.IOException;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.endava.vehiclerentalapp.util.jwtTokenUtil;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Filter class for JWT authentication in the Vehicle Rental Application.
 * 
 * This filter intercepts incoming requests to check for the presence of a valid JWT token 
 * in the `Authorization` header. If the token is valid, the filter extracts the email 
 * associated with the token and sets the authentication context in the security context 
 * of the current thread, allowing access to protected resources.
 */
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    /**
     * Method to filter requests and authenticate users based on JWT token.
     * 
     * This method checks the `Authorization` header for a valid JWT token (with "Bearer" prefix). 
     * If the token is valid, the user's email is extracted, and a new authentication token is 
     * set in the `SecurityContextHolder`, allowing the user to access protected resources.
     *
     * @param request the HTTP request
     * @param response the HTTP response
     * @param filterChain the filter chain
     * @throws ServletException if an error occurs during request processing
     * @throws IOException if an error occurs while reading the request or writing the response
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
    	String authorizationHeader = request.getHeader("Authorization");
    	if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
    	    String token = authorizationHeader.substring(7);
    	    if (jwtTokenUtil.validateToken(token)) {
    	        String email = jwtTokenUtil.extractEmail(token);  
    	        UsernamePasswordAuthenticationToken authenticationToken = 
    	                new UsernamePasswordAuthenticationToken(email, null, null);  
    	        SecurityContextHolder.getContext().setAuthentication(authenticationToken);
    	    }
    	}
        filterChain.doFilter(request, response);
    }
}
