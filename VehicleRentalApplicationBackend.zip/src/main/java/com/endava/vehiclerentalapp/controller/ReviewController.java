package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.ReviewDTO;
import com.endava.vehiclerentalapp.service.ReviewService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Controller to handle review-related requests.
 */
@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

	private final ReviewService reviewService;

	public ReviewController(ReviewService reviewService) {
		this.reviewService = reviewService;
	}

	/**
	 * Create a new review.
	 *
	 * @param reviewDTO the review data transfer object
	 * @return the created review
	 */
	@PostMapping
	public ResponseEntity<ReviewDTO> createReview(@RequestBody ReviewDTO reviewDTO) {
		ReviewDTO createdReview = reviewService.createReview(reviewDTO);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdReview);
	}

	/**
	 * Updates a review for a given user and vehicle.
	 * 
	 * @param userId    The ID of the user updating the review.
	 * @param vehicleId The ID of the vehicle being reviewed.
	 * @param reviewDTO The updated review details.
	 * @return A ResponseEntity containing the updated review or a NOT_FOUND status
	 *         if the review is not found.
	 */
	@PutMapping("/{userId}/{vehicleId}")
	public ResponseEntity<ReviewDTO> updateReview(@PathVariable Long userId, @PathVariable Long vehicleId,
			@RequestBody ReviewDTO reviewDTO) {
		try {
			ReviewDTO updatedReview = reviewService.updateReview(userId, vehicleId, reviewDTO);
			return ResponseEntity.ok(updatedReview);
		} catch (IllegalArgumentException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
	}

	/**
	 * Deletes a review for a given user and vehicle.
	 * 
	 * @param userId    The ID of the user deleting the review.
	 * @param vehicleId The ID of the vehicle whose review is to be deleted.
	 * @return A ResponseEntity with a NO_CONTENT status if the review is
	 *         successfully deleted, or a NOT_FOUND status if the review is not
	 *         found.
	 */
	@DeleteMapping("/{userId}/{vehicleId}")
	public ResponseEntity<Void> deleteReview(@PathVariable Long userId, @PathVariable Long vehicleId) {
		try {
			reviewService.deleteReview(userId, vehicleId);
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		} catch (IllegalArgumentException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
	}

	/**
	 * Get a review by its ID.
	 *
	 * @param reviewId the review ID
	 * @return the review
	 */
	@GetMapping("/{reviewId}")
	public ResponseEntity<ReviewDTO> getReview(@PathVariable Long reviewId) {
		ReviewDTO review = reviewService.getReview(reviewId);
		return ResponseEntity.ok(review);
	}

	/**
	 * Get all reviews.
	 *
	 * @return a list of all reviews
	 */
	@GetMapping
	public ResponseEntity<List<ReviewDTO>> getAllReviews() {
		List<ReviewDTO> reviews = reviewService.getAllReviews();
		return ResponseEntity.ok(reviews);
	}

	/**
	 * Retrieves a list of reviews for a given vehicle.
	 * 
	 * @param vehicleId The ID of the vehicle for which reviews are being retrieved.
	 * @return A ResponseEntity containing a list of ReviewDTO objects for the
	 *         vehicle, or an empty list if no reviews exist.
	 */
	@GetMapping("/vehicle/{vehicleId}")
	public ResponseEntity<List<ReviewDTO>> getReviewsByVehicleId(@PathVariable Long vehicleId) {
		List<ReviewDTO> reviews = reviewService.getReviewsByVehicleId(vehicleId);
		return new ResponseEntity<>(reviews, HttpStatus.OK);
	}

	/**
	 * Retrieves a list of reviews for a given customer.
	 * 
	 * @param customerId The ID of the customer whose reviews are being retrieved.
	 * @return A ResponseEntity containing a list of ReviewDTO objects for the
	 *         customer, or an empty list if no reviews exist.
	 */
	@GetMapping("/customer/{customerId}")
	public ResponseEntity<List<ReviewDTO>> getReviewsByCustomerId(@PathVariable Long customerId) {
		List<ReviewDTO> reviews = reviewService.getReviewsByCustomerId(customerId);
		return new ResponseEntity<>(reviews, HttpStatus.OK);
	}

	/**
	 * Retrieves the average rating for a given vehicle.
	 * 
	 * @param vehicleId The ID of the vehicle for which the average rating is being
	 *                  retrieved.
	 * @return The average rating of the vehicle.
	 */
	@GetMapping("/average-rating/{vehicleId}")
	public Double getAverageRating(@PathVariable Long vehicleId) {
		return reviewService.getAverageRatingByVehicleId(vehicleId);
	}

}
