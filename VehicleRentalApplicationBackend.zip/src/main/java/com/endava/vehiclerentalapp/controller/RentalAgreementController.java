package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.RentalAgreementDTO;
import com.endava.vehiclerentalapp.service.RentalAgreementService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Controller for managing rental agreements.
 */
@RestController
@RequestMapping("/api/rental-agreements")
public class RentalAgreementController {
	
    private final RentalAgreementService rentalAgreementService;

    public RentalAgreementController(RentalAgreementService rentalAgreementService) {
		this.rentalAgreementService = rentalAgreementService;
	}

	/**
     * Create a new rental agreement.
     * 
     * @param rentalAgreementDTO the rental agreement details
     * @return the created rental agreement
     */
    @PostMapping
    public ResponseEntity<RentalAgreementDTO> createRentalAgreement(@RequestBody RentalAgreementDTO rentalAgreementDTO) {
        RentalAgreementDTO createdAgreement = rentalAgreementService.createRentalAgreement(rentalAgreementDTO);
        return ResponseEntity.ok(createdAgreement);
    }

    /**
     * Get rental agreement details by ID.
     * 
     * @param rentalId the ID of the rental agreement
     * @return the rental agreement details
     */
    @GetMapping("/{rentalId}")
    public ResponseEntity<RentalAgreementDTO> getRentalAgreementById(@PathVariable Long rentalId) {
        RentalAgreementDTO rentalAgreementDTO = rentalAgreementService.getRentalAgreementById(rentalId);
        return ResponseEntity.ok(rentalAgreementDTO);
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<RentalAgreementDTO>> getRentalAgreementsByCustomerId(@PathVariable Long customerId) {
        List<RentalAgreementDTO> agreements = rentalAgreementService.getRentalAgreementByCustomerId(customerId);
        return ResponseEntity.ok(agreements);
    }
    
    /**
     * Get all rental agreements.
     * 
     * @return list of all rental agreements
     */
    @GetMapping
    public ResponseEntity<List<RentalAgreementDTO>> getAllRentalAgreements() {
        List<RentalAgreementDTO> rentalAgreements = rentalAgreementService.getAllRentalAgreements();
        return ResponseEntity.ok(rentalAgreements);
    }

    /**
     * Delete a rental agreement by ID.
     * 
     * @param rentalId the ID of the rental agreement to delete
     * @return response indicating deletion
     */
    @DeleteMapping("/{rentalId}")
    public ResponseEntity<String> deleteRentalAgreement(@PathVariable Long rentalId) {
        rentalAgreementService.deleteRentalAgreement(rentalId);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
