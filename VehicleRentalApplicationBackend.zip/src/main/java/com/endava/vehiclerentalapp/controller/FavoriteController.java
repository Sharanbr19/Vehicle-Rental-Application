package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.FavoriteDTO;
import com.endava.vehiclerentalapp.service.FavoriteService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for handling requests related to Favorite functionality.
 */
@RestController
@RequestMapping("/api/favorites")
public class FavoriteController {

    private final FavoriteService favoriteService;

    public FavoriteController(FavoriteService favoriteService) {
        this.favoriteService = favoriteService;
    }

    /**
     * Add a vehicle to the customer's favorites.
     *
     * @param favoriteDTO the FavoriteDTO containing customer and vehicle information
     * @return ResponseEntity with status and favorite data
     */
    @PostMapping
    public ResponseEntity<FavoriteDTO> addFavorite(@RequestBody FavoriteDTO favoriteDTO) {
        FavoriteDTO savedFavorite = favoriteService.addFavorite(favoriteDTO);
        return new ResponseEntity<>(savedFavorite, HttpStatus.CREATED);
    }

    /**
     * Remove a vehicle from the customer's favorites based on customerId and vehicleId.
     *
     * @param customerId the ID of the customer
     * @param vehicleId the ID of the vehicle to be removed from favorites
     * @return ResponseEntity with status OK
     */
    @DeleteMapping("/{customerId}/{vehicleId}")
    public ResponseEntity<Void> removeFavorite(
            @PathVariable Long customerId,
            @PathVariable Long vehicleId) {
        favoriteService.removeFavorite(customerId, vehicleId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * Get all favorites for a specific customer.
     *
     * @param customerId the ID of the customer
     * @return ResponseEntity with a list of FavoriteDTO
     */
    @GetMapping("/{customerId}")
    public ResponseEntity<List<FavoriteDTO>> getFavoritesByCustomer(@PathVariable Long customerId) {
        List<FavoriteDTO> favorites = favoriteService.getFavoritesByCustomer(customerId);
        return new ResponseEntity<>(favorites, HttpStatus.OK);
    }
}
