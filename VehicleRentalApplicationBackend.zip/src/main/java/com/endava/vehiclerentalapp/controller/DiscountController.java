package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.DiscountDTO;
import com.endava.vehiclerentalapp.service.DiscountService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/discounts")
public class DiscountController {

	private final DiscountService discountService;

	public DiscountController(DiscountService discountService) {
		this.discountService = discountService;
	}

	@PostMapping("/createDiscount")
	public ResponseEntity<DiscountDTO> createDiscount(@RequestBody DiscountDTO discountDTO) {
		DiscountDTO createdDiscount = discountService.createDiscount(discountDTO);
		return ResponseEntity.ok(createdDiscount);
	}

	@PutMapping("/{discountId}")
	public ResponseEntity<DiscountDTO> updateDiscount(@PathVariable Long discountId,
			@RequestBody DiscountDTO discountDTO) {
		DiscountDTO updatedDiscount = discountService.updateDiscount(discountId, discountDTO);
		return ResponseEntity.ok(updatedDiscount);
	}

	@DeleteMapping("/{discountId}")
	public ResponseEntity<String> deleteDiscount(@PathVariable Long discountId) {
		discountService.deleteDiscount(discountId);
		return ResponseEntity.ok("Discount deleted successfully");
	}

	@GetMapping("/{discountId}")
	public ResponseEntity<DiscountDTO> getDiscountById(@PathVariable Long discountId) {
		DiscountDTO discountDTO = discountService.getDiscountById(discountId);
		return ResponseEntity.ok(discountDTO);
	}

	@GetMapping("/allDiscounts")
	public ResponseEntity<List<DiscountDTO>> getAllDiscounts() {
		List<DiscountDTO> discounts = discountService.getAllDiscounts();
		return ResponseEntity.ok(discounts);
	}

	@GetMapping("/vehicle/{vehicleId}/highest")
	public ResponseEntity<DiscountDTO> getHighestDiscountForVehicle(@PathVariable Long vehicleId) {
		return discountService.getHighestDiscountForVehicle(vehicleId).map(ResponseEntity::ok)
				.orElse(ResponseEntity.noContent().build());
	}

	@DeleteMapping("/deleteExpired")
	public ResponseEntity<String> deleteExpiredDiscounts() {
		discountService.deleteExpiredDiscounts();
		return ResponseEntity.ok("Expired discounts deleted successfully");
	}

	@PostMapping("/bulk/category")
	public ResponseEntity<String> applyBulkDiscountByCategory(@RequestParam String categoryType,
			@RequestParam double discountPercentage, @RequestParam LocalDate startDate,
			@RequestParam LocalDate endDate) {
		discountService.applyBulkDiscountByCategory(categoryType, discountPercentage, startDate, endDate);
		return ResponseEntity.ok("Bulk discount applied for category: " + categoryType);
	}

	@PostMapping("/bulk/upload")
	public ResponseEntity<String> uploadDiscountsFromExcel(@RequestParam MultipartFile file) {
		discountService.applyBulkDiscountFromExcel(file);
		return ResponseEntity.ok("Bulk discounts uploaded successfully!");
	}
}
