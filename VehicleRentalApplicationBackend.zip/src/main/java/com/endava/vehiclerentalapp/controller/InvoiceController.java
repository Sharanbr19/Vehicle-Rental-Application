package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.InvoiceDTO;
import com.endava.vehiclerentalapp.service.InvoiceService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

	private final InvoiceService invoiceService;

	public InvoiceController(InvoiceService invoiceService) {
		this.invoiceService = invoiceService;
	}

	/**
	 * Create a new invoice.
	 * 
	 * @param invoiceDTO the invoice details
	 * @return the created invoice
	 */
	@PostMapping
	public ResponseEntity<InvoiceDTO> createInvoice(@RequestBody InvoiceDTO invoiceDTO) {
		InvoiceDTO createdInvoice = invoiceService.createInvoice(invoiceDTO);
		return ResponseEntity.ok(createdInvoice);
	}

	/**
	 * Get invoice details by ID.
	 * 
	 * @param invoiceId the ID of the invoice
	 * @return the invoice details
	 */
	@GetMapping("/{invoiceId}")
	public ResponseEntity<InvoiceDTO> getInvoiceById(@PathVariable Long invoiceId) {
		InvoiceDTO invoiceDTO = invoiceService.getInvoiceById(invoiceId);
		return ResponseEntity.ok(invoiceDTO);
	}

	/**
	 * Get all invoices.
	 * 
	 * @return list of all invoices
	 */
	@GetMapping
	public ResponseEntity<List<InvoiceDTO>> getAllInvoices() {
		List<InvoiceDTO> invoices = invoiceService.getAllInvoices();
		return ResponseEntity.ok(invoices);
	}

	/**
	 * Retrieves a list of invoices for a given customer.
	 * 
	 * @param customerId The ID of the customer whose invoices are being retrieved.
	 * @return A ResponseEntity containing a list of InvoiceDTO objects for the
	 *         customer, or an empty list if no invoices exist.
	 */
	@GetMapping("/customer/{customerId}")
	public ResponseEntity<List<InvoiceDTO>> getInvoicesByCustomerId(@PathVariable Long customerId) {
		List<InvoiceDTO> invoices = invoiceService.getInvoicesByCustomerId(customerId);
		return ResponseEntity.ok(invoices);
	}

	/**
	 * Delete an invoice by ID.
	 * 
	 * @param invoiceId the ID of the invoice to delete
	 * @return response indicating deletion
	 */
	@DeleteMapping("/{invoiceId}")
	public ResponseEntity<String> deleteInvoice(@PathVariable Long invoiceId) {
		invoiceService.deleteInvoice(invoiceId);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
