package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.PaymentDTO;
import com.endava.vehiclerentalapp.service.PaymentService;
import com.razorpay.RazorpayException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for managing payments in the Vehicle Rental System.
 */
@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
    	this.paymentService = paymentService;
    }
    
    /**
     * Retrieves a payment by its ID.
     *
     * @param id the payment ID
     * @return the payment details
     */
    @GetMapping("/{id}")
    public ResponseEntity<PaymentDTO> getPaymentById(@PathVariable Long id) {
        PaymentDTO paymentDTO = paymentService.getPaymentById(id);
        return ResponseEntity.ok(paymentDTO);
    }

    /**
     * Retrieves all payments.
     *
     * @return the list of all payments
     */
    @GetMapping
    public ResponseEntity<List<PaymentDTO>> getAllPayments() {
        List<PaymentDTO> payments = paymentService.getAllPayments();
        return ResponseEntity.ok(payments);
    }

    /**
     * Creates a new payment.
     *
     * @param paymentDTO the payment details
     * @return the response indicating success or failure
     */
    @PostMapping
    public ResponseEntity<String> createPayment(@RequestBody PaymentDTO paymentDTO) {
        try {
            String response = paymentService.createPayment(paymentDTO);
            return ResponseEntity.ok(response);
        } catch (RazorpayException e) {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    /**
     * Updates an existing payment.
     *
     * @param id         the payment ID
     * @param paymentDTO the updated payment details
     * @return the response indicating success
     */
    @PutMapping("/{id}")
    public ResponseEntity<String> updatePayment(@PathVariable Long id, @RequestBody PaymentDTO paymentDTO) {
        String response = paymentService.updatePayment(id, paymentDTO);
        return ResponseEntity.ok(response);
    }

    /**
     * Deletes a payment by its ID.
     *
     * @param id the payment ID
     * @return the response indicating success
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePayment(@PathVariable Long id) {
        String response = paymentService.deletePayment(id);
        return ResponseEntity.ok(response);
    }
}
