package com.endava.vehiclerentalapp.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.endava.vehiclerentalapp.dto.UserDto;
import com.endava.vehiclerentalapp.entity.Users;
import com.endava.vehiclerentalapp.service.UserService;
import com.endava.vehiclerentalapp.service.implementation.MailService;
import com.endava.vehiclerentalapp.util.Constants;
import jakarta.mail.MessagingException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

/**
 * Controller class for managing user-related operations in the Vehicle Rental Application.
 * 
 * This class handles HTTP requests related to user registration, login, email availability checks, 
 * and CRUD operations for managing user information.
 */
@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    private final MailService mailService;
    
    private final Random random = new Random();
    
    public UserController(UserService userService, MailService mailService) {
    	this.mailService = mailService;
    	this.userService = userService;
    }
    
    /**
     * Checks whether an email address is already registered in the system.
     *
     * @param email the email address to check.
     * @return a {@link ResponseEntity} indicating whether the email is available or already taken.
     */
    @GetMapping("/check-email")
    public ResponseEntity<String> checkUserEmailExists(@RequestParam String email) {
        boolean exists = userService.checkIfUserExistsByEmail(email);
        if (exists) {
            return ResponseEntity.status(409).body(Constants.EMAIL_ALREADY_TAKEN);
        } else {
            return ResponseEntity.ok(Constants.EMAIL_AVAILABLE);
        }
    }

    /**
     * Registers a new user in the system.
     *
     * @param userDto the {@link UserDto} containing user details for registration.
     * @return a {@link ResponseEntity} with a success message upon successful registration.
     */
    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> registerUser(
            @RequestBody UserDto userDto,
            @RequestHeader(required = false) String createdBy) {
        if (createdBy == null || createdBy.isBlank()) {
            createdBy = Constants.ADMIN_DEFAULT;
        }
        userService.registerUser(userDto, createdBy);
        return ResponseEntity.ok(Collections.singletonMap(Constants.MESSAGE, Constants.USER_REGISTERED_SUCCESSFULLY));
    }

    /**
     * Authenticates a user and returns a JWT token upon successful login.
     *
     * @param userDto the {@link UserDto} containing the user's email and password.
     * @return a {@link ResponseEntity} with the JWT token if login is successful, 
     * or an error message with a 401 status code if authentication fails.
     */
    @PostMapping("/login")
    public ResponseEntity<Object> loginUser(@RequestBody UserDto userDto) {
        Optional<String> token = userService.loginUser(userDto.getEmail(), userDto.getPassword());
        if (token.isPresent()) {
            return ResponseEntity.ok(token.get());  
        } else {
            return ResponseEntity.status(401).body(Constants.INVALID_CREDENTIALS);
        }
    }

    /**
     * Retrieves user details by user ID.
     *
     * @param userId the ID of the user to retrieve.
     * @return a {@link ResponseEntity} containing the user details if found.
     */
    @GetMapping("/{userId}")
    public ResponseEntity<Object> getUserById(@PathVariable Long userId) {
        Optional<Users> userOptional = userService.getUserById(userId);
        if (userOptional.isPresent()) {
            return ResponseEntity.ok(userOptional.get());
        } else {
            return ResponseEntity.status(404).body(Constants.USER_NOT_FOUND);
        }
    }
    
    /**
     * Retrieves user details by user email.
     *
     * @param email the email of the user to retrieve.
     * @return a {@link ResponseEntity} containing the user details if found.
     */
    @GetMapping("/email/{email}")
    public ResponseEntity<Object> getUserByEmail(@PathVariable String email) {
        Optional<Users> user = userService.getUserByEmail(email);

        if (user.isPresent()) {
            return ResponseEntity.ok(user.get()); 
        } else {
            return ResponseEntity.status(404).body(Constants.USER_NOT_FOUND); 
        }
    }

    /**
     * Retrieves a list of all users.
     *
     * @return a {@link ResponseEntity} containing the list of users.
     */
    @GetMapping("/all")
    public ResponseEntity<List<Users>> getAllUsers() {
        List<Users> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    /**
     * Updates the user details.
     *
     * @param userId the ID of the user to update.
     * @param userDto the {@link UserDto} containing the updated user details.
     * @return a {@link ResponseEntity} with a success message or error.
     */
    @PutMapping("/{userId}")
    public ResponseEntity<Map<String, String>> updateUser(@PathVariable Long userId, @RequestBody UserDto userDto,
                                        @RequestHeader(required = false) String updatedBy) {
        if (updatedBy == null || updatedBy.isBlank()) {
            updatedBy = Constants.ADMIN_DEFAULT;
        }
        userService.updateUser(userId, userDto, updatedBy);
        return ResponseEntity.ok(Collections.singletonMap(Constants.MESSAGE, Constants.USER_UPDATED_SUCCESSFULLY));
    }
    
    @PutMapping("/user-profile/{userId}")
    public ResponseEntity<Map<String, String>> updateProfile(@PathVariable Long userId, @RequestBody UserDto userDto,
                                        @RequestHeader(required = false) String updatedBy) {
        if (updatedBy == null || updatedBy.isBlank()) {
            updatedBy = Constants.ADMIN_DEFAULT;
        }
        userService.updateProfile(userId, userDto, updatedBy);
        return ResponseEntity.ok(Collections.singletonMap(Constants.MESSAGE, Constants.USER_UPDATED_SUCCESSFULLY));
    }

    /**
     * Deletes a user by user ID (soft delete).
     *
     * @param userId the ID of the user to delete.
     * @return a {@link ResponseEntity} indicating the result of the delete operation.
     */
    @DeleteMapping("/{userId}")
    public ResponseEntity<Map<String,String>> deleteUser(@PathVariable Long userId, @RequestHeader(required = false) String deletedBy) {
        if (deletedBy == null || deletedBy.isBlank()) {
            deletedBy = Constants.ADMIN_DEFAULT;
        }
        userService.deleteUser(userId, deletedBy);
        return ResponseEntity.ok(Collections.singletonMap(Constants.MESSAGE, Constants.USER_DELETED_SUCCESSFULLY));
    }
    
    @GetMapping("/total-customers")
    public long getTotalCustomers() {
        return userService.getTotalCustomers();
    }

    /**
     * Initiates a password reset process by generating and sending an OTP to the user's email.
     *
     * @param email the email address of the user requesting the password reset.
     * @return a {@link ResponseEntity} indicating the result of the operation.
     */
    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestParam String email) {
        boolean userExists = userService.checkIfUserExistsByEmail(email);
        if (!userExists) {
            return ResponseEntity.status(404).body(Constants.USER_DOESNOT_EXIST);
        }
        String otp = generateOtp();
        String subject = Constants.PASSWORD_RESET_OTP;
        String content = Constants.OTP_EMAIL_FORGOT_PASSWORD.replace("{otp}", otp);
        try {
			mailService.sendHtmlEmail(email, subject, content);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
        userService.saveOtp(email, otp);
        return ResponseEntity.ok(Constants.OTP_SENT_TO_MAIL);
    }

    /**
     * Resets the user's password after validating the OTP.
     *
     * @param email the email address of the user.
     * @param otp the OTP received by the user.
     * @param newPassword the new password to set.
     * @return a {@link ResponseEntity} indicating the result of the password reset operation.
     */
    @PostMapping("/reset-password")
    public ResponseEntity<String> resetPassword(@RequestParam String email, @RequestParam String otp, @RequestParam String newPassword) {
        boolean otpValid = userService.validateOtp(email, otp);
        if (!otpValid) {
            return ResponseEntity.status(400).body(Constants.INVALID_OTP);
        }
        userService.updatePassword(email, newPassword);
        return ResponseEntity.ok(Constants.PASSWORD_REST_SUCCESSFUL);
    }
    
    /**
     * Sends an OTP to the user's email for verification.
     *
     * @param email the email address to send the OTP to.
     * @return a {@link ResponseEntity} indicating the result.
     */
    @PostMapping("/send-otp")
    public ResponseEntity<String> sendOtpToEmail(@RequestParam String email) {
        String message = userService.sendOtpToEmail(email);
        return ResponseEntity.ok(message);
    }

    /**
     * Verifies the OTP entered by the user.
     *
     * @param email the email address of the user.
     * @param otp the OTP entered by the user.
     * @return a {@link ResponseEntity} indicating whether the OTP is valid.
     */
    @PostMapping("/verify-otp")
    public ResponseEntity<String> verifyOtp(@RequestParam String email, @RequestParam String otp) {
        boolean isValid = userService.verifyOtp(email, otp);
        if (isValid) {
            return ResponseEntity.ok(Constants.OTP_VERIFIED_SUCCESSFULLY);
        } else {
            return ResponseEntity.status(400).body(Constants.INVALID_OTP);
        }
    }


    /**
     * Generates a random 6-digit OTP.
     *
     * @return a 6-digit OTP as a string.
     */
    private String generateOtp() {
        int otp = 100000 + random.nextInt(900000); 
        return String.valueOf(otp);
    }
}
