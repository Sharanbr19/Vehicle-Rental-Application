package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.BookingDTO;
import com.endava.vehiclerentalapp.dto.VehicleDTO;
import com.endava.vehiclerentalapp.service.BookingService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
 
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    /**
     * Endpoint to create a new booking.
     * 
     * @param bookingDTO the booking details.
     * @return the created BookingDTO.
     */
    @PostMapping
    public ResponseEntity<BookingDTO> createBooking(@RequestBody BookingDTO bookingDTO) {
        BookingDTO createdBooking = bookingService.createBooking(bookingDTO);
        return new ResponseEntity<>(createdBooking, HttpStatus.CREATED);
    }

    /**
     * Endpoint to get a booking by its ID.
     * 
     * @param bookingId the ID of the booking.
     * @return the requested BookingDTO.
     */
    @GetMapping("/{bookingId}")
    public ResponseEntity<BookingDTO> getBookingById(@PathVariable Long bookingId) {
        BookingDTO bookingDTO = bookingService.getBookingById(bookingId);
        return new ResponseEntity<>(bookingDTO, HttpStatus.OK);
    }

    /**
     * Retrieves the total number of confirmed bookings.
     * 
     * @return the total number of confirmed bookings as a long value
     */
    @GetMapping("/total-bookings")
    public long getTotalBookings() {
        return bookingService.getTotalBookings();
    }

    /**
     * Retrieves the total earnings from bookings.
     * 
     * @return the total earnings as a long value
     */
    @GetMapping("/total-earnings")
    public long getTotalEarnings() {
        return bookingService.getTotalEarnings();
    }

    /**
     * Retrieves the earnings by category type.
     * 
     * @return a list of earnings by category type as Object arrays
     */
    @GetMapping("/earnings-by-category")
    public List<Object[]> getEarningsByCategoryType() {
        return bookingService.getEarningsByCategoryType();
    }

    /**
     * Retrieves the booking count by category type.
     * 
     * @return a list of booking counts by category type as Object arrays
     */
    @GetMapping("/booking-count-by-category")
    public List<Object[]> getBookingCountByCategoryType() {
        return bookingService.getBookingCountByCategoryType();
    }

    
    /**
     * Retrieves all bookings associated with a specific customer ID, sorted by booking date (latest to oldest).
     * 
     * @param customerId the ID of the customer for which to retrieve bookings.
     * @return a list of BookingDTOs associated with the specified customer.
     */
    @GetMapping("/customer/{customerId}")
    public List<BookingDTO> getBookingsByCustomerId(@PathVariable Long customerId) {
        return bookingService.getBookingsByCustomerId(customerId);
    }

    /**
     * Endpoint to get all bookings for a specific vehicle.
     * 
     * @param vehicleId the ID of the vehicle.
     * @return a list of BookingDTOs.
     */
    @GetMapping("/vehicle/{vehicleId}")
    public ResponseEntity<List<BookingDTO>> getBookingsByVehicleId(@PathVariable Long vehicleId) {
        List<BookingDTO> bookings = bookingService.getBookingsByVehicleId(vehicleId);
        return new ResponseEntity<>(bookings, HttpStatus.OK);
    }

    /**
     * Endpoint to get all bookings in the system.
     * 
     * @return a list of all BookingDTOs.
     */
    @GetMapping
    public ResponseEntity<List<BookingDTO>> getAllBookings() {
        List<BookingDTO> bookings = bookingService.getAllBookings();
        return new ResponseEntity<>(bookings, HttpStatus.OK);
    }

    /**
     * Endpoint to update an existing booking.
     * 
     * @param bookingId the ID of the booking to update.
     * @param bookingDTO the updated booking details.
     * @return the updated BookingDTO.
     */
    @PutMapping("/{bookingId}")
    public ResponseEntity<BookingDTO> updateBooking(@PathVariable Long bookingId, @RequestBody BookingDTO bookingDTO) {
        BookingDTO updatedBooking = bookingService.updateBooking(bookingId, bookingDTO);
        return new ResponseEntity<>(updatedBooking, HttpStatus.OK);
    }

    /**
     * Endpoint to delete a booking by its ID.
     * 
     * @param bookingId the ID of the booking to delete.
     * @return a response entity indicating success.
     */
    @DeleteMapping("/{bookingId}")
    public ResponseEntity<Void> deleteBooking(@PathVariable Long bookingId) {
        bookingService.deleteBooking(bookingId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    /**
     * Endpoint to get available vehicles between the specified dates.
     * 
     * @param fromDate the start date.
     * @param toDate the end date.
     * @return a list of VehicleDTOs for available vehicles.
     */
    @GetMapping("/available-vehicles")
    public ResponseEntity<List<VehicleDTO>> getAvailableVehiclesBetweenDates(@RequestParam LocalDate fromDate, @RequestParam LocalDate toDate) {
        List<VehicleDTO> availableVehicles = bookingService.getAvailableVehiclesBetweenDates(fromDate, toDate);
        return new ResponseEntity<>(availableVehicles, HttpStatus.OK);
    }
}
