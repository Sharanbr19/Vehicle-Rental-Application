package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.VehicleComparisonDTO;
import com.endava.vehiclerentalapp.dto.VehicleDTO;
import com.endava.vehiclerentalapp.dto.VehicleFilterCriteriaDTO;
import com.endava.vehiclerentalapp.service.VehicleService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

/**
 * Controller class for managing vehicle-related operations in the Vehicle Rental Application.
 * 
 * Provides endpoints for adding, updating, deleting, retrieving, and managing vehicle availability.
 */
@RestController
@RequestMapping("/api/vehicles")
public class VehicleController {

    private final  VehicleService vehicleService;
    
    public VehicleController(VehicleService vehicleService) {
    	this.vehicleService = vehicleService;
    }

    /**
     * Adds a new vehicle to the system.
     *
     * @param vehicleDTO the vehicle data to be added.
     * @return a {@link ResponseEntity} with a success message and HTTP status 201 (Created).
     */
    @PostMapping
    public ResponseEntity<String> addVehicle(@RequestBody VehicleDTO vehicleDTO) {
        vehicleService.addVehicle(vehicleDTO);
        return new ResponseEntity<>("Vehicle added successfully", HttpStatus.CREATED);
    }

    /**
     * Updates the details of an existing vehicle.
     *
     * @param vehicleId  the ID of the vehicle to update.
     * @param vehicleDTO the updated vehicle data.
     * @return a {@link ResponseEntity} containing the updated vehicle data and HTTP status 200 (OK), 
     *         or HTTP status 404 (Not Found) if the vehicle does not exist.
     */
    @PutMapping("/{vehicleId}")
    public ResponseEntity<VehicleDTO> updateVehicle(@PathVariable Long vehicleId, @RequestBody VehicleDTO vehicleDTO) {
        Optional<VehicleDTO> updatedVehicle = vehicleService.updateVehicle(vehicleId, vehicleDTO);
        return updatedVehicle
                .map(vehicle -> new ResponseEntity<>(vehicle, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * Deletes a vehicle by its ID.
     *
     * @param vehicleId the ID of the vehicle to delete.
     * @return a {@link ResponseEntity} with HTTP status 204 (No Content).
     */
    @DeleteMapping("/{vehicleId}")
    public ResponseEntity<Void> deleteVehicle(@PathVariable Long vehicleId) {
        vehicleService.deleteVehicle(vehicleId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    /**
     * gets total count of vehicles a vehicle by its ID.
     *
     * @return total count of vehicles.
     */
    @GetMapping("/total-vehicles")
    public long getTotalVehicles() {
        return vehicleService.getTotalVehicles();
    }
    
    /**
     * Retrieves a vehicle by its ID.
     *
     * @param vehicleId the ID of the vehicle to retrieve.
     * @return a {@link ResponseEntity} containing the vehicle data and HTTP status 200 (OK),
     *         or HTTP status 404 (Not Found) if the vehicle does not exist.
     */
    @GetMapping("/{vehicleId}")
    public ResponseEntity<VehicleDTO> getVehicleById(@PathVariable Long vehicleId) {
        Optional<VehicleDTO> vehicleDTO = vehicleService.getVehicleById(vehicleId);
        return vehicleDTO
                .map(vehicle -> new ResponseEntity<>(vehicle, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * Retrieves all vehicles in the system.
     *
     * @return a {@link ResponseEntity} containing a list of all vehicles and HTTP status 200 (OK).
     */
    @GetMapping
    public ResponseEntity<List<VehicleDTO>> getAllVehicles() {
        List<VehicleDTO> vehicles = vehicleService.getAllVehicles();
        return new ResponseEntity<>(vehicles, HttpStatus.OK);
    }

    /**
     * Searches for vehicles based on a keyword.
     *
     * @param keyword the search keyword (e.g., vehicle model, type).
     * @return a list of {@link VehicleDTO} matching the search criteria.
     */
    @GetMapping("/search")
    public List<VehicleDTO> searchVehicles(@RequestParam String keyword) {
        return vehicleService.searchVehicles(keyword);
    }

    /**
     * Filters vehicles based on the provided filter criteria.
     *
     * @param filterCriteria the filter criteria, such as vehicle type, availability, etc.
     * @return a list of {@link VehicleDTO} that match the filter criteria.
     */
    @PostMapping("/filter")
    public List<VehicleDTO> filterVehicles(@RequestBody VehicleFilterCriteriaDTO filterCriteria) {
        return vehicleService.filterVehicles(filterCriteria);
    }

    /**
     * Sorts vehicles based on a specified attribute and order (ascending or descending).
     *
     * @param sortBy    the attribute to sort by (e.g., price, model).
     * @param ascending whether the sorting should be in ascending order (true) or descending order (false).
     * @return a list of {@link VehicleDTO} sorted according to the provided parameters.
     */
    @GetMapping("/sort")
    public List<VehicleDTO> sortVehicles(@RequestParam String sortBy, @RequestParam boolean ascending) {
        return vehicleService.sortVehicles(sortBy, ascending);
    }

    /**
     * Compares two or more vehicles based on a list of vehicle IDs.
     *
     * @param vehicleIds a list of vehicle IDs to be compared.
     * @return a list of {@link VehicleComparisonDTO} containing the comparison results.
     */
    @PostMapping("/compare")
    public List<VehicleComparisonDTO> compareVehicles(@RequestBody List<Long> vehicleIds) {
        return vehicleService.compareVehicles(vehicleIds);
    }
}
