package com.endava.vehiclerentalapp.controller;

import com.endava.vehiclerentalapp.dto.DriverDTO;
import com.endava.vehiclerentalapp.service.DriverService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for managing drivers in the Vehicle Rental Application.
 */
@RestController
@RequestMapping("/api/drivers")
public class DriverController {

    private final DriverService driverService;

    public DriverController(DriverService driverService) {
        this.driverService = driverService;
    }

    /**
     * Endpoint to create a new driver.
     *
     * @param driverDTO The driver details.
     * @return The created driver.
     */
    @PostMapping
    public ResponseEntity<DriverDTO> createDriver(@RequestBody DriverDTO driverDTO) {
        DriverDTO createdDriver = driverService.createDriver(driverDTO);
        return new ResponseEntity<>(createdDriver, HttpStatus.CREATED);
    }

    /**
     * Endpoint to get a driver by ID.
     *
     * @param driverId The ID of the driver.
     * @return The driver details.
     */
    @GetMapping("/{driverId}")
    public ResponseEntity<DriverDTO> getDriverById(@PathVariable Long driverId) {
        DriverDTO driver = driverService.getDriverById(driverId);
        return new ResponseEntity<>(driver, HttpStatus.OK);
    }

    /**
     * Endpoint to get all drivers.
     *
     * @return A list of all drivers.
     */
    @GetMapping
    public ResponseEntity<List<DriverDTO>> getAllDrivers() {
        List<DriverDTO> drivers = driverService.getAllDrivers();
        return new ResponseEntity<>(drivers, HttpStatus.OK);
    }

    /**
     * Endpoint to update an existing driver.
     *
     * @param driverId  The ID of the driver to update.
     * @param driverDTO The updated driver details.
     * @return The updated driver.
     */
    @PutMapping("/{driverId}")
    public ResponseEntity<DriverDTO> updateDriver(@PathVariable Long driverId, @RequestBody DriverDTO driverDTO) {
        DriverDTO updatedDriver = driverService.updateDriver(driverId, driverDTO);
        return new ResponseEntity<>(updatedDriver, HttpStatus.OK);
    }

    /**
     * Endpoint to delete a driver by ID.
     *
     * @param driverId The ID of the driver to delete.
     * @return A success response.
     */
    @DeleteMapping("/{driverId}")
    public ResponseEntity<Void> deleteDriver(@PathVariable Long driverId) {
        driverService.deleteDriver(driverId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    /**
     * Retrieves the total number of drivers.
     * 
     * @return the total number of drivers as a long value
     */
    @GetMapping("/total-drivers")
    public long getTotalDrivers() {
        return driverService.getTotalDrivers();
    }

}
