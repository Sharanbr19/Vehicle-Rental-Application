package com.endava.vehiclerentalapp.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Data Transfer Object (DTO) for encapsulating user data.
 * This class represents the data structure for user-related operations such as registration, listing, and login.
 */
@Data
@NoArgsConstructor
public class UserDto {
    private String email;
    private String password;
    private String name;
    private LocalDate dateOfBirth;  
    private String gender;
    private String contactNumber;
    private String address;
    private String userType;
    private String createdBy;         
    private String updatedBy;         
    private LocalDateTime createdAt;  
    private LocalDateTime updatedAt;  
    private boolean isDeleted;        
}
