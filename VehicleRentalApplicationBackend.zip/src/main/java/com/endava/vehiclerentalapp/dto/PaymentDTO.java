package com.endava.vehiclerentalapp.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class PaymentDTO {
    private Long paymentId;          
    private Double amount;            
    private LocalDateTime paymentDateAndTime;  
    private String razorpayId;   
    private Long bookingId;           
}
