package com.endava.vehiclerentalapp.dto;

import lombok.Data;

/**
 * Data Transfer Object for RentalAgreement.
 */
@Data
public class RentalAgreementDTO {
    private Long rentalId;
    private String agreementDate;
    private String termsAndConditions;
    private Long bookingId;
}
