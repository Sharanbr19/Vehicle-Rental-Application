package com.endava.vehiclerentalapp.dto;

import lombok.Data;

/**
 * Data Transfer Object (DTO) for representing invoice details.
 * This object is used to transfer invoice information between layers in the application.
 */
@Data
public class InvoiceDTO {
    private Long invoiceId;
    private String invoiceDate;
    private Double totalAmount;
    private Long bookingId;  
}
