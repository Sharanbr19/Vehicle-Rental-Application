package com.endava.vehiclerentalapp.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object (DTO) for comparing two vehicles based on a specified attribute.
 * Stores the vehicle IDs, attribute being compared, their respective values, and the calculated difference.
 */
@Data
@NoArgsConstructor
public class VehicleComparisonDTO {
    private Long vehicleId1;
    private Long vehicleId2;
    private String attribute;
    private String value1;
    private String value2;
    private String difference;
}
