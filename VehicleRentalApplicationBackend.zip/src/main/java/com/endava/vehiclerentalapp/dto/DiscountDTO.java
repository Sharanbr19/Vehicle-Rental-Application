package com.endava.vehiclerentalapp.dto;

import lombok.Data;
import java.time.LocalDate;
import java.util.Set;

@Data
public class DiscountDTO {

    private Long discountId;
    private Double discountPercentage;
    private String categoryType; 
    private LocalDate startDate; 
    private LocalDate endDate;  
    private Set<Long> vehicleIds; 
}
