package com.endava.vehiclerentalapp.dto;

import com.endava.vehiclerentalapp.entity.BookingStatus;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Data Transfer Object (DTO) representing a booking in the vehicle rental system.
 * This class encapsulates all the necessary details related to a vehicle booking
 * such as customer information, vehicle information, booking status, and payment details.
 * 
 * It is used to transfer booking data between the backend and the frontend, or
 * between different layers of the application.
 */
@Data
public class BookingDTO {
    private Long bookingId;
    private String location;
    private LocalDate fromDate;
    private LocalDate toDate;
    private Double totalCost;
    private String customerAadharNumber;
    private String customerDrivingLicenseNumber;
    private BookingStatus status;
    private Boolean paymentCompleted;
    private Boolean wantsDriver;
    private Long customerId;
    private Long vehicleId; 
    private Long driverId;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}