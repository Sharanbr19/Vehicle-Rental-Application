package com.endava.vehiclerentalapp.dto;

/**
 * Data Transfer Object (DTO) for filtering vehicles based on multiple criteria.
 */
public record VehicleFilterCriteriaDTO(String categoryType, String fuelType, String priceRange, String color) {
}
