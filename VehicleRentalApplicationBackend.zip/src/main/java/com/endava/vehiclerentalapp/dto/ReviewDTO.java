package com.endava.vehiclerentalapp.dto;

import lombok.Data;

/**
 * DTO for review to send data to the client.
 */
@Data
public class ReviewDTO {
    private Long reviewId;
    private String rating;
    private String comment;
    private Long customerId;
    private Long vehicleId;
    public ReviewDTO(Long reviewId, String rating, String comment, Long customerId, Long vehicleId) {
        this.reviewId = reviewId;
        this.rating = rating;
        this.comment = comment;
        this.customerId = customerId;
        this.vehicleId = vehicleId;
    }
}
