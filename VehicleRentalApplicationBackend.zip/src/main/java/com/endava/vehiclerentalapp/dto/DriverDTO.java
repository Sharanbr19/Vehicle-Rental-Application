package com.endava.vehiclerentalapp.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * DTO class for transferring driver data.
 */
@Data
@NoArgsConstructor
public class DriverDTO {
    private Long driverId;
    private String name;
    private String licenseNumber;
    private Double driverCostPerDay;
    private String contactNumber;
    private String email;
    private Long adminId; 
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String createdBy;
    private String updatedBy;
    private Boolean isDeleted;
    private List<LocalDate> driverBookingDates = new ArrayList<>();
 }
