package com.endava.vehiclerentalapp.dto;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

/**
 * DTO class for transferring vehicle data.
 * 
 * This class is used for returning vehicle details to the client.
 */
@Data
public class VehicleDTO {
    private Long vehicleId;
    private String modelName;
    private String registrationNumber;
    private String categoryType;
    private String fuelType;
    private String color;
    private String modelYear;
    private Double pricePerDay;
    private Double mileage;
    private String featureDescription;
    private String insuranceNumber;
    private String vehicleImageURL;
    private Long adminId;
    private List<VehicleBookingDateDTO> vehicleBookingDates; 
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Boolean isDeleted = false;
    private String createdBy;
    private String updatedBy;
}
