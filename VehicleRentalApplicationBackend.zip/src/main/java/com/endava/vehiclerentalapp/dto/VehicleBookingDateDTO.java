package com.endava.vehiclerentalapp.dto;

import lombok.Data;
import java.time.LocalDate;

/**
 * DTO class for transferring vehicle booking date data.
 */
@Data
public class VehicleBookingDateDTO {
    private Long vehicleBookingDateId;
    private LocalDate bookedDate;
    private Long vehicleId;  
}
