package com.endava.vehiclerentalapp.dto;

import lombok.Data;
import java.time.LocalDate;

/**
 * DTO class for transferring driver booking date data.
 */
@Data
public class DriverBookingDateDTO {
    private Long driverBookingDateId;
    private LocalDate bookedDate; 
    private Long driverId; 
}
